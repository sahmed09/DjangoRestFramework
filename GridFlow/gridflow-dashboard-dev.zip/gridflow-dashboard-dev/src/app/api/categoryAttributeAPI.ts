import { httpRequest, REQUEST_TYPE_GET, REQUEST_TYPE_POST } from "./baseAPI";

export const getCategoryAttributeChoices = async (attributeSlug: string): Promise<any> => {
    return await httpRequest(
        REQUEST_TYPE_GET,
        `/store/category_attribute_choices_api/?category_attribute__slug=${attributeSlug}`
    )
};


export const addProductAttributeValue = async (productSlug: string, attributeValueSlug: string): Promise<any> => {

    const payload = {
        product: { slug: productSlug },
        category_attribute_choices: { slug: attributeValueSlug }
    };

    console.log(payload);

    return await httpRequest(
        REQUEST_TYPE_POST,
        '/store/product_category_attribute_choices_api/',
        payload
    )
};

export interface IAttrVal {
    attrSlug: string
    valSlug: string
}

export const addMultipleProductAttributeValues =  async(productSlug: string, attrVals: IAttrVal[]): Promise<any> => {

    /*
    example payload: 

    {
        "data": [
            {
                "category_attribute": {
                    "slug": "frostability"
                },
                "category_attribute_choices": {
                    "slug": "non-frost"
                }
            },
            {
                "category_attribute": {
                    "slug": "no-of-doors"
                },
                "category_attribute_choices": {
                    "slug": "2"
                }
            }
        ]
    }

    */

    const data = attrVals.map(attrVal => ({
        category_attribute: {slug: attrVal.attrSlug},
        category_attribute_choices: {slug: attrVal.valSlug},
    }));


    const payload = {
        data
    };

    console.log("product attribute payload: ");
    console.log(payload);

    return await httpRequest(
        REQUEST_TYPE_POST,
        `/store/product_attributes_api/?product__slug=${productSlug}`,
        payload
    )
};

