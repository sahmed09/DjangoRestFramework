import { httpRequest, REQUEST_TYPE_GET } from "./baseAPI";

export const getLocations = async (page: number = 1): Promise<any> => {
    return await httpRequest(
        REQUEST_TYPE_GET,
        `/order/location_api/?page=${page}`
    )
};
