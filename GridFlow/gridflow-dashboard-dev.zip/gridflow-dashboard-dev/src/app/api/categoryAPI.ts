import axios from "axios";
import { IAttribute, IAttributeValue, ICategoryFormState } from "../../interfaces";
import { ResponseData } from "../types";
import { apiRoot } from "./axios";


export const createCategory = async (name: string): Promise<any> => {
    const respObj = <ResponseData>{};

    try {
        const resp = await apiRoot.post('/store/category_api/', { name });
        let data = resp.data;

        respObj['status'] = resp.status;
        respObj['statusText'] = resp.statusText;
        respObj['data'] = data;

    } catch (error: any) {
        const errResp = error.response;

        respObj['status'] = errResp.status;
        respObj['statusText'] = errResp.statusText;
        respObj['errorMessage'] = errResp.data.detail || errResp.statusText || null;
    }

    return respObj;
};


export const updateCategory = async (id: number | string, name: string): Promise<any> => {
    const respObj = <ResponseData>{};

    try {
        // todo: use PATCH
        const resp = await apiRoot.put(`/store/category_api/${id}/`, { name });
        let data = resp.data;

        respObj['status'] = resp.status;
        respObj['statusText'] = resp.statusText;
        respObj['data'] = data;

    } catch (error: any) {
        const errResp = error.response;

        respObj['status'] = errResp.status;
        respObj['statusText'] = errResp.statusText;
        respObj['errorMessage'] = errResp.data.detail || errResp.statusText || null;
    }

    return respObj;
};


export const getCategories = async (page: number = 1): Promise<any> => {
    const respObj = <ResponseData>{};

    try {
        const resp = await apiRoot.get(`/store/category_api/?page=${page}`);
        let data = resp.data;

        respObj['status'] = resp.status;
        respObj['statusText'] = resp.statusText;
        respObj['data'] = data;

    } catch (error: any) {
        const errResp = error.response;

        respObj['status'] = errResp.status;
        respObj['statusText'] = errResp.statusText;
        respObj['errorMessage'] = errResp.data.detail || errResp.statusText || null;
    }

    return respObj;
};


export const deleteCategory = async (id: number | string): Promise<any> => {
    const respObj = <ResponseData>{};

    try {
        const resp = await apiRoot.delete(`/store/category_api/${id}/`);
        let data = resp.data;

        respObj['status'] = resp.status;
        respObj['statusText'] = resp.statusText;
        respObj['data'] = data;

    } catch (error: any) {
        const errResp = error.response;

        respObj['status'] = errResp.status;
        respObj['statusText'] = errResp.statusText;
        respObj['errorMessage'] = errResp.data.detail || errResp.statusText || null;
    }

    return respObj;
};

// ************************************************

export const createCategoryAttribute = async (categorySlug: string, attributeName: string): Promise<any> => {
    const respObj = <ResponseData>{};

    try {
        const resp = await apiRoot.post('/store/category_attribute_api/', { category: { slug: categorySlug }, attribute_name: attributeName });
        let data = resp.data;

        respObj['status'] = resp.status;
        respObj['statusText'] = resp.statusText;
        respObj['data'] = data;

    } catch (error: any) {
        const errResp = error.response;

        respObj['status'] = errResp.status;
        respObj['statusText'] = errResp.statusText;
        respObj['errorMessage'] = errResp.data.detail || errResp.statusText || null;
    }

    return respObj;
};


export const updateCategoryAttributeName = async (attributeId: string | number, categorySlug: string, attributeName: string): Promise<any> => {
    const respObj = <ResponseData>{};

    try {
        const resp = await apiRoot.put(`/store/category_attribute_api/${attributeId}/`, { category: { slug: categorySlug }, attribute_name: attributeName });
        let data = resp.data;

        respObj['status'] = resp.status;
        respObj['statusText'] = resp.statusText;
        respObj['data'] = data;

    } catch (error: any) {
        const errResp = error.response;

        respObj['status'] = errResp.status;
        respObj['statusText'] = errResp.statusText;
        respObj['errorMessage'] = errResp.data.detail || errResp.statusText || null;
    }

    return respObj;
};

// ************************

export const createCategoryAttributeValue = async (attributeSlug: string, attributeValue: string): Promise<any> => {
    const respObj = <ResponseData>{};

    try {
        const resp = await apiRoot.post('/store/category_attribute_choices_api/', { category_attribute: { slug: attributeSlug }, attribute_value: attributeValue });
        let data = resp.data;

        respObj['status'] = resp.status;
        respObj['statusText'] = resp.statusText;
        respObj['data'] = data;

    } catch (error: any) {
        const errResp = error.response;

        respObj['status'] = errResp.status;
        respObj['statusText'] = errResp.statusText;
        respObj['errorMessage'] = errResp.data.detail || errResp.statusText || null;
    }

    return respObj;
};


export const updateCategoryAttributeValue = async (attributeValueId: string | number, attributeSlug: string, attributeValue: string): Promise<any> => {
    const respObj = <ResponseData>{};

    try {
        const resp = await apiRoot.put(`/store/category_attribute_choices_api/${attributeValueId}/`, { category_attribute: { slug: attributeSlug }, attribute_value: attributeValue });
        let data = resp.data;

        respObj['status'] = resp.status;
        respObj['statusText'] = resp.statusText;
        respObj['data'] = data;

    } catch (error: any) {
        const errResp = error.response;

        respObj['status'] = errResp.status;
        respObj['statusText'] = errResp.statusText;
        respObj['errorMessage'] = errResp.data.detail || errResp.statusText || null;
    }

    return respObj;
};

// *****************

export const getCategoryBySlug = async (slug: string): Promise<any> => {
    const respObj = <ResponseData>{};

    try {
        const resp = await apiRoot.get(`/store/category_api/?slug=${slug}`);
        let data = resp.data;

        respObj['status'] = resp.status;
        respObj['statusText'] = resp.statusText;
        respObj['data'] = data;

    } catch (error: any) {
        const errResp = error.response;

        respObj['status'] = errResp.status;
        respObj['statusText'] = errResp.statusText;
        respObj['errorMessage'] = errResp.data.detail || errResp.statusText || null;
    }

    return respObj;
};


export const searchCategory = async (query: string): Promise<any> => {
    const respObj = <ResponseData>{};

    try {
        const resp = await apiRoot.get(`/store/category_api/?search=${query}`);
        let data = resp.data;

        respObj['status'] = resp.status;
        respObj['statusText'] = resp.statusText;
        respObj['data'] = data;

    } catch (error: any) {
        const errResp = error.response;

        respObj['status'] = errResp.status;
        respObj['statusText'] = errResp.statusText;
        respObj['errorMessage'] = errResp.data.detail || errResp.statusText || null;
    }

    return respObj;
};


export const getCategoryAttributeNames = async (categorySlug: string): Promise<any> => {
    const respObj = <ResponseData>{};

    try {
        const resp = await apiRoot.get(`/store/category_attribute_api/?category__slug=${categorySlug}`);
        let data = resp.data;

        respObj['status'] = resp.status;
        respObj['statusText'] = resp.statusText;
        respObj['data'] = data;

    } catch (error: any) {
        const errResp = error.response;

        respObj['status'] = errResp.status;
        respObj['statusText'] = errResp.statusText;
        respObj['errorMessage'] = errResp.data.detail || errResp.statusText || null;
    }

    return respObj;
};

// ***********************

export const getCategoryAttributes = async (categorySlug: string): Promise<any> => {

    // get category attribute names
    try {
        // todo: get category

        const attrListResp = await apiRoot.get(`/store/category_attribute_api/?category__slug=${categorySlug}`);
        const attrNameList = attrListResp.data;
        // @ts-ignore
        // const attributeNames = attrNameList.map(attr => ({ name: attr.attribute_name, slug: attr.slug }))
        const attributeNames = attrNameList.map(attr => ({ id: attr.id || null, name: attr.attribute_name, slug: attr.slug }))

        const allAttributes = [];

        for (const attribute of attributeNames) {
            // NOTE: backend API does not return relevant results
            const attrValuesResp = await apiRoot.get(`/store/category_attribute_choices_api/?category_attribute__slug=${attribute.slug}`);
            // const attrValuesResp = await apiRoot.get(`/store/category_attribute_choices_api/?search=${attribute.slug}`);

            const attrValueItems = attrValuesResp?.data?.results || [];

            // create array of attribute value object
            // todo: implements interface IAttributeValue
            const attrValues: IAttributeValue[] = attrValueItems.map((attr: any) => (
                {
                    // id: attr.slug,
                    // id: attr.id || attr.slug,
                    id: attr.id,
                    value: attr.attribute_value,
                    slug: attr.slug,
                    isSaved: false,
                    update: true,
                }
            ));

            const preparedAttribute: IAttribute = {
                // id: attribute.slug,
                id: attribute.id || attribute.slug,
                name: attribute.name,
                slug: attribute.slug,
                isSaved: false,
                update: true,
                values: attrValues,
            };

            allAttributes.push(preparedAttribute);

        }
        // end: attribute value fetch loop

        return allAttributes;

    } catch (error: any) {
        console.log('Error fectching category-attributes: ', error);
        return null;
    }
};


export const getCategoryWithAttributes = async (id: number): Promise<any> => {

    try {
        // get category
        const categoryResp = await apiRoot.get(`/store/category_api/${id}/`);
        // category object : {id: number, name: string, slug: string}
        const category = categoryResp.data;

        const attributes = await getCategoryAttributes(category.slug);

        const categoryAttributes: ICategoryFormState = {
            id: category.id,
            name: category.name,
            slug: category.slug,
            isSaved: false,
            update: true,
            attributes: attributes,
        }

        return categoryAttributes;

    } catch (error) {
        return null;
    }
};
