import { ResponseData } from "../types";
import { apiRoot } from "./axios";

export const getAlbums = async (page: number = 1): Promise<any> => {
    const respObj = <ResponseData>{};

    try {
        const resp = await apiRoot.get(`/gallery/album_api/?page=${page}`);
        let data = resp.data;

        respObj['status'] = resp.status;
        respObj['statusText'] = resp.statusText;
        respObj['data'] = data;

    } catch (error: any) {
        const errResp = error.response;

        respObj['status'] = errResp.status;
        respObj['statusText'] = errResp.statusText;
        respObj['errorMessage'] = errResp.data.detail || errResp.statusText || null;
    }

    return respObj;
};