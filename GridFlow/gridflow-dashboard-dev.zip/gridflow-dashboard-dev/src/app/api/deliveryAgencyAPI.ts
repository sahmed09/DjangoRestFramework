import { httpRequest, REQUEST_TYPE_DELETE, REQUEST_TYPE_GET, REQUEST_TYPE_POST, REQUEST_TYPE_PUT } from "./baseAPI";

export const getDeliveryAgencyList = async (page: number = 1): Promise<any> => {
    return await httpRequest(
        REQUEST_TYPE_GET,
        `/order/delivery_agency_api/?page=${page}`
    )
};


export const createDeliveryAgency = async (name: string, mobile: string, email: string, address: string): Promise<any> => {
    return await httpRequest(
        REQUEST_TYPE_POST,
        '/order/delivery_agency_api/',
        { name, email, mobile, address }
    )
};


export const updateDeliveryAgency = async (id: number, name: string, mobile: string, email: string, address: string): Promise<any> => {
    return await httpRequest(
        REQUEST_TYPE_PUT,
        `/order/delivery_agency_api/${id}/`,
        { name, email, mobile, address }
    )
};


export const deleteDeliveryAgency = async (id: number): Promise<any> => {
    return await httpRequest(
        REQUEST_TYPE_DELETE,
        `/order/delivery_agency_api/${id}/`
    )
};
