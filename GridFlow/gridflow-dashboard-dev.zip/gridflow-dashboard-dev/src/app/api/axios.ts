import axios from "axios";

export const apiRoot = axios.create({
    baseURL: 'http://54.251.167.179:8000/api',

    headers: {
        'Accept': 'application/json',
    }
});

export function setAxiosAuthToken(token: string) {
    apiRoot.defaults.headers['Authorization'] = `Bearer ${token}`;
}

export function unsetAxiosAuthToken() {
    delete apiRoot.defaults.headers['Authorization'];
}
