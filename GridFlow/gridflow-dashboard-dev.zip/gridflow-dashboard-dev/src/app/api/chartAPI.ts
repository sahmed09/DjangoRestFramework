import { httpRequest, REQUEST_TYPE_GET } from "./baseAPI";

export const getChartData = async (
    startDate: string,
    endDate: string,
    interval: string = 'daily',
    shop: string | null = null,
    branch: string | null = null,
    product: string | null = null,
): Promise<any> => {

    /*

    http://54.251.167.179:8000/api/shop/product_stock_log_api/?start_date=2021-10-20&end_date=2022-12-25&interval=daily&product=walton-fridge&shop=walton-store&branch=Mohammadpur
    
    start_date=2021-10-20&
    end_date=2022-12-25&
    interval=daily&
    product=walton-fridge
    &shop=walton-store&
    branch=Mohammadpur
    
    */

    let url = `/shop/product_stock_log_api/?start_date=${startDate}&end_date=${endDate}&interval=${interval}&`
    if (shop) url = url + "shop=" + shop + "&";
    if (branch) url = url + "branch=" + branch + "&";
    if (product) url = url + "product=" + product;


    console.log("url:: ");
    console.log(url);
    

    return await httpRequest(
        REQUEST_TYPE_GET,
        url
    )
};