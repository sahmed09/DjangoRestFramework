import { ResponseData } from "../types";
import { apiRoot } from "./axios";


export const createBrand = async (name: string, albumName: string | null = null): Promise<any> => {
    const respObj = <ResponseData>{};

    const payload = {
        name,
        // album: { name: albumName },
    }

    try {
        const resp = await apiRoot.post('/store/brand_api/', payload);
        let data = resp.data;

        respObj['status'] = resp.status;
        respObj['statusText'] = resp.statusText;
        respObj['data'] = data;

    } catch (error: any) {
        const errResp = error.response;

        respObj['status'] = errResp.status;
        respObj['statusText'] = errResp.statusText;
        respObj['errorMessage'] = errResp.data.detail || errResp.statusText || null;
    }

    return respObj;
};


export const updateBrand = async (id: number, name: string, albumName: string | null = null): Promise<any> => {
    const respObj = <ResponseData>{};

    const payload = {
        name,
        // album: { name: albumName },
    }


    console.log("payload :: ");
    console.log(payload);


    try {
        // todo: use PATCH
        const resp = await apiRoot.put(`/store/brand_api/${id}/`, payload);
        let data = resp.data;

        respObj['status'] = resp.status;
        respObj['statusText'] = resp.statusText;
        respObj['data'] = data;

    } catch (error: any) {
        const errResp = error.response;

        respObj['status'] = errResp.status;
        respObj['statusText'] = errResp.statusText;
        respObj['errorMessage'] = errResp.data.detail || errResp.statusText || null;
    }

    return respObj;
};


export const deleteBrand = async (id: number | string): Promise<any> => {
    const respObj = <ResponseData>{};

    try {
        const resp = await apiRoot.delete(`/store/brand_api/${id}/`);
        let data = resp.data;

        respObj['status'] = resp.status;
        respObj['statusText'] = resp.statusText;
        respObj['data'] = data;

    } catch (error: any) {
        const errResp = error.response;

        respObj['status'] = errResp.status;
        respObj['statusText'] = errResp.statusText;
        respObj['errorMessage'] = errResp.data.detail || errResp.statusText || null;
    }

    return respObj;
};


export const getBrands = async (page: number = 1): Promise<any> => {
    const respObj = <ResponseData>{};

    try {
        const resp = await apiRoot.get(`/store/brand_api/?page=${page}`);
        let data = resp.data;

        respObj['status'] = resp.status;
        respObj['statusText'] = resp.statusText;
        respObj['data'] = data;

    } catch (error: any) {
        const errResp = error.response;

        respObj['status'] = errResp.status;
        respObj['statusText'] = errResp.statusText;
        respObj['errorMessage'] = errResp.data.detail || errResp.statusText || null;
    }

    return respObj;
};


export const searchBrand = async (query: string): Promise<any> => {
    const respObj = <ResponseData>{};

    try {
        const resp = await apiRoot.get(`/store/brand_api/?search=${query}`);
        let data = resp.data;

        respObj['status'] = resp.status;
        respObj['statusText'] = resp.statusText;
        respObj['data'] = data;

    } catch (error: any) {
        const errResp = error.response;

        respObj['status'] = errResp.status;
        respObj['statusText'] = errResp.statusText;
        respObj['errorMessage'] = errResp.data.detail || errResp.statusText || null;
    }

    return respObj;
};
