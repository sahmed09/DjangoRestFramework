import { ResponseData } from "../types";
import { apiRoot } from "./axios";
import { httpRequest, REQUEST_TYPE_GET, REQUEST_TYPE_POST } from "./baseAPI";


export const createProduct = async (productName: string, brandSlug: string, categorySlug: string): Promise<any> => {
    const respObj = <ResponseData>{};

    const payload = {
        name: productName,
        brand: { slug: brandSlug },
        category: { slug: categorySlug },
    }

    try {
        const resp = await apiRoot.post('/store/product_api/', payload);
        let data = resp.data;

        respObj['status'] = resp.status;
        respObj['statusText'] = resp.statusText;
        respObj['data'] = data;

    } catch (error: any) {
        const errResp = error.response;

        respObj['status'] = errResp.status;
        respObj['statusText'] = errResp.statusText;
        respObj['errorMessage'] = errResp.data.detail || errResp.statusText || null;
    }

    return respObj;
};


export const updateProduct = async (id: number, productName: string, brandSlug: string, categorySlug: string): Promise<any> => {
    const respObj = <ResponseData>{};

    const payload = {
        name: productName,
        brand: { slug: brandSlug },
        category: { slug: categorySlug },
    }

    try {
        const resp = await apiRoot.put(`/store/product_api/${id}/`, payload);
        let data = resp.data;

        respObj['status'] = resp.status;
        respObj['statusText'] = resp.statusText;
        respObj['data'] = data;

    } catch (error: any) {
        const errResp = error.response;

        respObj['status'] = errResp.status;
        respObj['statusText'] = errResp.statusText;
        respObj['errorMessage'] = errResp.data.detail || errResp.statusText || null;
    }

    return respObj;
};



export const deleteProduct = async (id: number | string): Promise<any> => {
    const respObj = <ResponseData>{};

    try {
        const resp = await apiRoot.delete(`/store/product_api/${id}/`);
        let data = resp.data;

        respObj['status'] = resp.status;
        respObj['statusText'] = resp.statusText;
        respObj['data'] = data;

    } catch (error: any) {
        const errResp = error.response;

        respObj['status'] = errResp.status;
        respObj['statusText'] = errResp.statusText;
        respObj['errorMessage'] = errResp.data.detail || errResp.statusText || null;
    }

    return respObj;
};


export const getProducts = async (page: number = 1): Promise<any> => {
    const respObj = <ResponseData>{};

    try {
        const resp = await apiRoot.get(`/store/product_api/?page=${page}`);
        let data = resp.data;

        respObj['status'] = resp.status;
        respObj['statusText'] = resp.statusText;
        respObj['data'] = data;

    } catch (error: any) {
        const errResp = error.response;

        respObj['status'] = errResp.status;
        respObj['statusText'] = errResp.statusText;
        respObj['errorMessage'] = errResp.data.detail || errResp.statusText || null;
    }

    return respObj;
};


export const getProductAttributes = async (productSlug: string, page: number = 1): Promise<any> => {
    return await httpRequest(
        REQUEST_TYPE_GET,
        `/store/product_category_attribute_choices_api/?product__slug=${productSlug}&page=${page}`
    )
};


export const getProductDetails = async (productId: number): Promise<any> => {
    return await httpRequest(
        REQUEST_TYPE_GET,
        `/store/product_api/${productId}/`
    )
};


export const addProductStockQuantity = async (productSlug: string, quantity: number, shopSlug: string, branchSlug: string | null = null): Promise<any> => {

    const payload = {
        product: { slug: productSlug },
        quantity,
        shop: { slug: shopSlug },
    }

    // append branch if exists
    // @ts-ignore
    if (branchSlug && branchSlug.length > 0) payload['branch'] = { slug: branchSlug }

    console.log("payload :: ");
    console.log(payload);


    return await httpRequest(
        REQUEST_TYPE_POST,
        '/shop/stock_api/',
        payload
    )
};


