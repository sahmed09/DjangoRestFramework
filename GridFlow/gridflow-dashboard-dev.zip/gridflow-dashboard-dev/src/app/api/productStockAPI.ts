import { httpRequest, REQUEST_TYPE_GET, REQUEST_TYPE_POST } from "./baseAPI";

export const updateProductStock = async (shopSlug: string, productSlug: string, name: string, description: string, stockAbove: number, stockBelow: number): Promise<any> => {

    const payload = {
        shop: { slug: shopSlug },
        product: { slug: productSlug },
        name,
        description,
        stock_below: stockBelow,
        stock_above: stockAbove,
    }

    console.log("payload :: ");
    console.log(payload);


    return await httpRequest(
        REQUEST_TYPE_POST,
        // '/shop/stock_alert_api/',
        '/shop/stock_alerts_api/',
        payload
    )
};

export const getProductStockInfo = async (productSlug: string): Promise<any> => {


    return await httpRequest(
        REQUEST_TYPE_GET,
        `/shop/stock_alerts_api/?product__slug=${productSlug}`
    )
};

