// orderAPI.ts

import { httpRequest, REQUEST_TYPE_DELETE, REQUEST_TYPE_GET, REQUEST_TYPE_PATCH, REQUEST_TYPE_POST } from "./baseAPI";

export const getOrders = async (page: number = 1): Promise<any> => {
    return await httpRequest(
        REQUEST_TYPE_GET,
        `/order/order_api/?page=${page}`
    )
};


export const getShopOrderDetails = async (txnId: string): Promise<any> => {
    return await httpRequest(
        REQUEST_TYPE_GET,
        `/order/order_api/?transaction_id=${txnId}`
    )
};


export const getOrderDetails = async (id: number): Promise<any> => {
    return await httpRequest(
        REQUEST_TYPE_GET,
        `/order/order_api/${id}/`
    )
};


export const createOrder = async (username: string, phone: string, email: string, address: string, location: string): Promise<any> => {
    const payload = {
        customer: { user: { username } },
        mobile: phone,
        email,
        address,
        // location: { name: location },
        area: { name: location },
    };

    return await httpRequest(
        REQUEST_TYPE_POST,
        '/order/order_api/',
        payload
    )
};

// todo: add delivery agent
export const createNewOrder = async (customerPhone: string, phone: string, email: string, address: string, location: string): Promise<any> => {
    const payload = {
        customer: { mobile: customerPhone },
        mobile: phone,
        email,
        address,
        // location: { name: location },
        area: { slug: location.toLocaleLowerCase() },
        // deliver_agent: { name: "Redex" },
        // order_status: { status: "Pending" },
    };

    console.log("payload: ");
    console.log(payload);


    return await httpRequest(
        REQUEST_TYPE_POST,
        '/order/order_api/',
        payload
    )
};

export const deleteOrder = async (id: number): Promise<any> => {
    return await httpRequest(
        REQUEST_TYPE_DELETE,
        `/order/order_api/${id}/`
    )
};

export const getOrderStatusList = async (page: number = 1): Promise<any> => {
    return await httpRequest(
        REQUEST_TYPE_GET,
        `/order/order_status_api/?page=${page}`
    )
};

export const getShopOrderStatusList = async (shopSlug: string, page: number = 1): Promise<any> => {
    return await httpRequest(
        REQUEST_TYPE_GET,
        `/order/order_status_api/?shop_order_status__shop__slug=${shopSlug}&page=${page}`
    )
};


export const updateOrderStatus = async (id: number, status: string): Promise<any> => {
    return await httpRequest(
        REQUEST_TYPE_PATCH,
        `/order/order_api/${id}/`,
        // { order_status: { status } }
        { order_status: { shop_order_status: { status } } }
    )
};


export const getOrderProducts = async (txnID: string): Promise<any> => {
    return await httpRequest(
        REQUEST_TYPE_GET,
        `/order/order_item_api/?order__transaction_id=${txnID}`
    )
};


