import { httpRequest, REQUEST_TYPE_DELETE, REQUEST_TYPE_GET, REQUEST_TYPE_POST, REQUEST_TYPE_PUT } from "./baseAPI";

export const getProductStockAlerts = async (productSlug: string, shopSlug: string, branchSlug: string | null = null): Promise<any> => {

    // /shop/stock_alerts_api/?shop__slug=rayans&branch__slug=idb&product__slug=singer-non-frost-fridge

    let url = `/shop/stock_alerts_api/?product__slug=${productSlug}&shop__slug=${shopSlug}`
    if (branchSlug) url = url + `&branch__slug=${branchSlug}`;

    console.log(url);

    return await httpRequest(
        REQUEST_TYPE_GET,
        url
    )
};

export const createProductStockAlert = async (name: string, description: string, productSlug: string,
    stockAbove: number, stockBelow: number,
    shopSlug: string, branchSlug: string | null = null): Promise<any> => {

    const payload = {
        name, description,
        product: { slug: productSlug },

        stock_below: stockBelow,
        stock_above: stockAbove,

        shop: { slug: shopSlug },
        // branch: { slug: branchSlug },
    };

    // append branch if exists
    // @ts-ignore
    if (branchSlug && branchSlug.length > 0) payload['branch'] = { slug: branchSlug }

    // console.log(payload);


    return await httpRequest(
        REQUEST_TYPE_POST,
        '/shop/stock_alerts_api/',
        payload
    )
};


export const updateProductStockAlert = async (id: number, name: string, description: string, productSlug: string,
    stockAbove: number, stockBelow: number,
    shopSlug: string, branchSlug: string | null = null): Promise<any> => {

    const payload = {
        name, description,
        product: { slug: productSlug },

        stock_below: stockBelow,
        stock_above: stockAbove,

        shop: { slug: shopSlug },
        // branch: { slug: branchSlug },
    };

    // append branch if exists
    // @ts-ignore
    if (branchSlug && branchSlug.length > 0) payload['branch'] = { slug: branchSlug }

    // console.log(payload);


    return await httpRequest(
        REQUEST_TYPE_PUT,
        `/shop/stock_alerts_api/${id}/`,
        payload
    )
};


export const deleteProductStockAlert = async (id: number): Promise<any> => {
    return await httpRequest(
        REQUEST_TYPE_DELETE,
        `/shop/stock_alerts_api/${id}/`
    )
};