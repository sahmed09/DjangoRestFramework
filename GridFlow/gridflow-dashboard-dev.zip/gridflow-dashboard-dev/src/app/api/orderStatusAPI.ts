import { httpRequest, REQUEST_TYPE_DELETE, REQUEST_TYPE_POST } from "./baseAPI";


export const createOrderStatus = async (shopSlug: string, status: string): Promise<any> => {
    const payload = {
        shop: { slug: shopSlug },
        status,
    };

    console.log(payload);

    return await httpRequest(
        REQUEST_TYPE_POST,
        '/order/shop_order_status_api/',
        payload
    )
};


export const createShopOrderStatus = async (status: string, message: string): Promise<any> => {
    const payload = {
        shop_order_status: { status },
        msg: message,
    };

    console.log(payload);

    return await httpRequest(
        REQUEST_TYPE_POST,
        '/order/order_status_api/',
        payload
    )
};

export const deleteShopOrderStatus = async (id: number): Promise<any> => {

    return await httpRequest(
        REQUEST_TYPE_DELETE,
        `/order/order_status_api/${id}/`
    )
};
