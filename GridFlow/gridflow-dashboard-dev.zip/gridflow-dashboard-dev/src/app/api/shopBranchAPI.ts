import { ResponseData } from "../types";
import { apiRoot } from "./axios";
import { httpRequest, REQUEST_TYPE_DELETE, REQUEST_TYPE_GET, REQUEST_TYPE_POST } from "./baseAPI";

// get all branches of a specific shop
export const getShopBranches = async (shopSlug: string): Promise<any> => {

    const respObj = <ResponseData>{};

    try {
        const resp = await apiRoot.get(`/shop/shop_branch_api/?shop__slug=${shopSlug}`);
        let data = resp.data;

        respObj['status'] = resp.status;
        respObj['statusText'] = resp.statusText;
        respObj['data'] = data;

    } catch (error: any) {
        const errResp = error.response;

        respObj['status'] = errResp.status;
        respObj['statusText'] = errResp.statusText;
        respObj['errorMessage'] = errResp.data.detail || errResp.statusText || null;
    }

    return respObj;
};


// get a specific shop branch
export const getShopBranch = async (id: number): Promise<any> => {
    return await httpRequest(REQUEST_TYPE_GET, `/shop/shop_branch_api/${id}/`)
};



export const createShopBranch = async (shopSlug: string, branchName: string): Promise<any> => {

    const respObj = <ResponseData>{};

    try {
        const resp = await apiRoot.post('/shop/shop_branch_api/', { shop: { slug: shopSlug }, name: branchName });
        let data = resp.data;

        respObj['status'] = resp.status;
        respObj['statusText'] = resp.statusText;
        respObj['data'] = data;

    } catch (error: any) {
        const errResp = error.response;

        respObj['status'] = errResp.status;
        respObj['statusText'] = errResp.statusText;
        respObj['errorMessage'] = errResp.data.detail || errResp.statusText || null;
    }

    return respObj;
};



export const updateShopBranch = async (branchId: number, shopSlug: string, branchName: string): Promise<any> => {

    const respObj = <ResponseData>{};

    try {
        const resp = await apiRoot.put(`/shop/shop_branch_api/${branchId}/`, { shop: { slug: shopSlug }, name: branchName });
        let data = resp.data;

        respObj['status'] = resp.status;
        respObj['statusText'] = resp.statusText;
        respObj['data'] = data;

    } catch (error: any) {
        const errResp = error.response;

        respObj['status'] = errResp.status;
        respObj['statusText'] = errResp.statusText;
        respObj['errorMessage'] = errResp.data.detail || errResp.statusText || null;
    }

    return respObj;
};


export const deleteShopBranch = async (branchId: number): Promise<any> => {

    const respObj = <ResponseData>{};

    try {
        const resp = await apiRoot.delete(`/shop/shop_branch_api/${branchId}/`);
        let data = resp.data;

        respObj['status'] = resp.status;
        respObj['statusText'] = resp.statusText;
        respObj['data'] = data;

    } catch (error: any) {
        const errResp = error.response;

        respObj['status'] = errResp.status;
        respObj['statusText'] = errResp.statusText;
        respObj['errorMessage'] = errResp.data.detail || errResp.statusText || null;
    }

    return respObj;
};



// get product list from shop branch

export const getShopProducts = async (shopSlug: string, branchSlug: string | null = null): Promise<any> => {

    return await httpRequest(
        REQUEST_TYPE_GET,
        // `/shop/shop_branch_product_api/?shop__slug=${shopSlug}&branch__slug=${branchSlug}`
        branchSlug ?
            `/shop/shop_branch_product_api/?shop__slug=${shopSlug}&branch__slug=${branchSlug}` :
            `/shop/shop_branch_product_api/?shop__slug=${shopSlug}`
    )
};


export const addProductToShopBranch = async (productSlug: string, price: number, shopSlug: string, branchSlug: string | null = null): Promise<any> => {

    const payload = {
        product: { slug: productSlug },
        price,
        shop: { slug: shopSlug },
    }

    // append branch if exists
    // @ts-ignore
    if (branchSlug && branchSlug.length > 0) payload['branch'] = { slug: branchSlug }

    console.log("payload :: ");
    console.log(payload);


    return await httpRequest(
        REQUEST_TYPE_POST,
        '/shop/shop_branch_product_api/',
        payload
    )
};


export const deleteProductFromoShopBranch = async (productId: number): Promise<any> => {
    return await httpRequest(REQUEST_TYPE_DELETE, `/shop/shop_branch_product_api/${productId}/`)
};


export const getShopBranchProductDetails = async (productId: number): Promise<any> => {
    return await httpRequest(REQUEST_TYPE_GET, `/shop/shop_branch_product_api/${productId}/`)
};


