import ShopsPage from "../modules/shops/ShopsPage";
import { httpRequest, REQUEST_TYPE_DELETE, REQUEST_TYPE_GET, REQUEST_TYPE_POST } from "./baseAPI";


export const createCustomer = async (shopSlug: string, firstName: string, lastName: string, email: string, mobile: string): Promise<any> => {

    const payload = {
        shop: { slug: shopSlug },
        first_name: firstName,
        last_name: lastName,
        email,
        mobile,
    }

    return await httpRequest(
        REQUEST_TYPE_POST,
        '/order/customer_api/',
        payload
    )
};


export const getCustomerList = async (page: number = 1): Promise<any> => {
    return await httpRequest(
        REQUEST_TYPE_GET,
        `/order/customer_api/?page=${page}`
    )
};

export const getCustomerByPhone = async (phoneNumber: string, shopSlug: string | null = null): Promise<any> => {

    let url = `/order/customer_api/?mobile=${phoneNumber}`;
    if (shopSlug) url = url + "&shop__slug=" + shopSlug;

    console.log('getCustomerByPhone url: ');
    console.log(url);
    

    return await httpRequest(
        REQUEST_TYPE_GET,
        // `/order/customer_api/?mobile=${phoneNumber}`
        url
    )
};


export const getShopCustomerList = async (shop: string, page: number = 1): Promise<any> => {
    return await httpRequest(
        REQUEST_TYPE_GET,
        `/order/customer_api/?shop__slug=${shop}&page=${page}`
    )
};


export const filterCustomer = async (email: string | null = null, mobile: string | null = null, shopSlug: string | null = null, page: number = 1): Promise<any> => {

    // let url = "/order/customer_api/?email=admin@gmail.com&mobile=12345607891&shop__slug=rayans"
    let url = "/order/customer_api/?page=" + page + "&";
    if (email) url = url + "email=" + email + "&";
    if (mobile) url = url + "mobile=" + mobile + "&";
    if (shopSlug) url = url + "shop__slug=" + shopSlug;

    return await httpRequest(
        REQUEST_TYPE_GET,
        url
    )
};


export const deleteCustomer = async (customerId: number): Promise<any> => {
    return await httpRequest(
        REQUEST_TYPE_DELETE,
        `/order/customer_api/${customerId}/`
    )
};



