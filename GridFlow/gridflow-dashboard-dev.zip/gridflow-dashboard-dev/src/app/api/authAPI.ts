import { ResponseData } from "../types";
import { apiRoot } from "./axios";

export const getAccessToken = async (username: string, password: string): Promise<any> => {
    const respObj = <ResponseData>{};

    try {
        const resp = await apiRoot.post('/token/', { username, password });
        let data = resp.data;

        respObj['status'] = resp.status;
        respObj['statusText'] = resp.statusText;
        respObj['data'] = data;

    } catch (error: any) {
        const errResp = error.response;

        respObj['status'] = errResp.status;
        respObj['statusText'] = errResp.statusText;
        respObj['errorMessage'] = errResp.data.detail || errResp.statusText || null;
    }

    console.log('auth respObj: ');
    console.log(respObj);

    return respObj;
};

