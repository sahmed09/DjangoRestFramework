import { httpRequest, REQUEST_TYPE_POST } from "./baseAPI";

/**
 * Documentation: https://gitlab.com/gridflow/gridflow-api/-/blob/shop/EXAMPLE.md#orderitem-api
 * @param username 
 * @param phone 
 * @param email 
 * @param address 
 * @param location 
 * @returns 
 */
export const addItemToOrder = async (productSlug: string, quantity: number, orderTxnId: string): Promise<any> => {
    const payload = {
        product: { product: { slug: productSlug } },
        quantity,
        order: { transaction_id: orderTxnId }
    }

    console.log("payload: ");
    console.log(payload);
    


    return await httpRequest(
        REQUEST_TYPE_POST,
        '/order/order_item_api/',
        payload
    )
};