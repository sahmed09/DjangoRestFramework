import { httpRequest, REQUEST_TYPE_GET, REQUEST_TYPE_POST } from "./baseAPI";

export const getShopUserRoles = async (shopSlug: string, page: number = 1): Promise<any> => {

    return await httpRequest(
        REQUEST_TYPE_GET,
        `/shop/shop_role_api/?shop__slug=${shopSlug}&page=${page}`
    )
};


export const setShopUserRole = async (username: string, shopSlug: string, role: string): Promise<any> => {

    return await httpRequest(
        REQUEST_TYPE_POST,
        '/shop/shop_role_api/',
        {
            user: { username },
            shop: { slug: shopSlug },
            role
        }
    )
};
