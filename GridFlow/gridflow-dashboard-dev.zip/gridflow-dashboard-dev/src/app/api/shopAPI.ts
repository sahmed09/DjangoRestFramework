import { ResponseData } from "../types";
import { apiRoot } from "./axios";
import { httpRequest, REQUEST_TYPE_GET } from "./baseAPI";

export const getShops = async (page: number = 1): Promise<any> => {

    const respObj = <ResponseData>{};

    try {
        const resp = await apiRoot.get(`/shop/shop_api/?page=${page}`);
        let data = resp.data;

        respObj['status'] = resp.status;
        respObj['statusText'] = resp.statusText;
        respObj['data'] = data;

    } catch (error: any) {
        const errResp = error.response;

        respObj['status'] = errResp.status;
        respObj['statusText'] = errResp.statusText;
        respObj['errorMessage'] = errResp.data.detail || errResp.statusText || null;
    }

    return respObj;
};


// get specific shop (details)
export const getShop = async (id: number): Promise<any> => {
    return await httpRequest(
        REQUEST_TYPE_GET,
        `/shop/shop_api/${id}/`
    )
};


export const createShop = async (name: string): Promise<any> => {
    const respObj = <ResponseData>{};

    const payload = { name, }

    try {
        const resp = await apiRoot.post('/shop/shop_api/', payload);
        let data = resp.data;

        respObj['status'] = resp.status;
        respObj['statusText'] = resp.statusText;
        respObj['data'] = data;

    } catch (error: any) {
        const errResp = error.response;

        respObj['status'] = errResp.status;
        respObj['statusText'] = errResp.statusText;
        respObj['errorMessage'] = errResp.data.detail || errResp.statusText || null;
    }

    return respObj;
};


export const deleteShop = async (id: number | string): Promise<any> => {
    const respObj = <ResponseData>{};

    try {
        const resp = await apiRoot.delete(`/shop/shop_api/${id}/`);
        let data = resp.data;

        respObj['status'] = resp.status;
        respObj['statusText'] = resp.statusText;
        respObj['data'] = data;

    } catch (error: any) {
        const errResp = error.response;

        respObj['status'] = errResp.status;
        respObj['statusText'] = errResp.statusText;
        respObj['errorMessage'] = errResp.data.detail || errResp.statusText || null;
    }

    return respObj;
};


export const updateShop = async (id: number, name: string): Promise<any> => {
    const respObj = <ResponseData>{};

    const payload = { name }

    try {
        const resp = await apiRoot.put(`/shop/shop_api/${id}/`, payload);
        let data = resp.data;

        respObj['status'] = resp.status;
        respObj['statusText'] = resp.statusText;
        respObj['data'] = data;

    } catch (error: any) {
        const errResp = error.response;

        respObj['status'] = errResp.status;
        respObj['statusText'] = errResp.statusText;
        respObj['errorMessage'] = errResp.data.detail || errResp.statusText || null;
    }

    return respObj;
};
