import { ResponseData } from "../types"
import { apiRoot } from "./axios"

export const REQUEST_TYPE_GET = 'GET'
export const REQUEST_TYPE_POST = 'POST'
export const REQUEST_TYPE_DELETE = 'DELETE'
export const REQUEST_TYPE_PUT = 'PUT'
export const REQUEST_TYPE_PATCH = 'PATCH'

export const httpRequest = async (requestType: string, url: string, payload: any = null) => {

    const respObj = <ResponseData>{};

    try {
        let resp;

        switch (requestType) {
            case REQUEST_TYPE_POST:
                resp = await apiRoot.post(url, payload);
                break;

            case REQUEST_TYPE_PUT:
                resp = await apiRoot.put(url, payload);
                break;

            case REQUEST_TYPE_PATCH:
                resp = await apiRoot.patch(url, payload);
                break;

            case REQUEST_TYPE_DELETE:
                resp = await apiRoot.delete(url);
                break;

            case REQUEST_TYPE_GET:
            default:
                resp = await apiRoot.get(url);
                break;
        }

        let data = resp.data;

        respObj['status'] = resp.status;
        respObj['statusText'] = resp.statusText;
        respObj['data'] = data;

    } catch (error: any) {
        const errResp = error.response;

        respObj['status'] = errResp.status;
        respObj['statusText'] = errResp.statusText;
        respObj['errorMessage'] = errResp.data.detail || errResp.statusText || null;
    }

    return respObj;
}