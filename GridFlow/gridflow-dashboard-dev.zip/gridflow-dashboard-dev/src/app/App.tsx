import React, { Suspense, useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { BrowserRouter } from 'react-router-dom'
import { I18nProvider } from '../_metronic/i18n/i18nProvider'
import { LayoutProvider, LayoutSplashScreen } from '../_metronic/layout/core'
import AuthInit from './modules/auth/redux/AuthInit'
import { Routes } from './routing/Routes'

import { setToken } from "../app/redux/slices/authSlice";
import { AppState } from './redux/store'
import { setAxiosAuthToken, unsetAxiosAuthToken } from './api/axios'

type Props = {
  basename: string
}

const App: React.FC<Props> = ({ basename }) => {

  const dispatch = useDispatch();



  // *****************************
  // todo: refactor

  const { token, error } = useSelector((state: AppState) => state.auth);

  // check if token exists in localStorage
  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) dispatch(setToken(token));
  }, []);

  // todo: use middleware
  useEffect(() => {
    console.log('add token to header');
    if (token && !error) {
      localStorage.setItem('token', token);
      setAxiosAuthToken(token);
    }
    else {
      // remove token from Axios Header and localStorage
      unsetAxiosAuthToken();
      localStorage.removeItem('token');
    }
  }, [token])
  // *****************************


  return (
    <Suspense fallback={<LayoutSplashScreen />}>
      <BrowserRouter basename={basename}>
        <I18nProvider>
          <LayoutProvider>
            <AuthInit>
              <Routes />
            </AuthInit>
          </LayoutProvider>
        </I18nProvider>
      </BrowserRouter>
    </Suspense>
  )
}

export { App }
