/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { useEffect, useState } from 'react'
import { useSelector, useDispatch } from 'react-redux'
import * as Yup from 'yup'
import clsx from 'clsx'
import { Link } from 'react-router-dom'
import { useFormik } from 'formik'
import * as auth from '../redux/AuthRedux'
import { login } from '../redux/AuthCRUD'
import { toAbsoluteUrl } from '../../../../_metronic/helpers'
import { getAccessToken } from '../../../api/authAPI'
import { setAxiosAuthToken } from '../../../api/axios'
import { getToken } from '../../../redux/slices/authSlice'
import { AppState } from '../../../redux/store'

// const loginSchema = Yup.object().shape({
//   email: Yup.string()
//     .email('Wrong email format')
//     .min(3, 'Minimum 3 symbols')
//     .max(50, 'Maximum 50 symbols')
//     .required('Email is required'),
//   password: Yup.string()
//     .min(3, 'Minimum 3 symbols')
//     .max(50, 'Maximum 50 symbols')
//     .required('Password is required'),
// })

// const initialValues = {
//   email: 'admin@demo.com',
//   password: 'demo',
// }






/*
  Formik+YUP+Typescript:
  https://jaredpalmer.com/formik/docs/tutorial#getfieldprops
  https://medium.com/@maurice.de.beijer/yup-validation-and-typescript-and-formik-6c342578a20e
*/

export function Login() {
  const [loading, setLoading] = useState(false)
  const dispatch = useDispatch()

  const { token, error } = useSelector((state: AppState) => state.auth);





  const [isValid, setIsValid] = useState(false)

  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')


  // useEffect(() => {
  //   const _token = localStorage.getItem('token');
  //   localStorage.setItem('foo', 'bar');
  //   console.log({ _token });

  // }, [token])

  // const _token = localStorage.getItem('token');
  // console.log({ _token });


  const loginHandler = async (e: React.FormEvent<any>) => {
    e.preventDefault();

    if (!username || !password) return;

    dispatch(getToken({ username, password }))


    // const { status, statusText, message, errorMessage, data } = await getAccessToken(username, password);
    // // console.log({ status, statusText, message, errorMessage, data });

    // // todo: use interceptor
    // if (data?.access) {
    //   console.log(data.access);
    //   setAxiosAuthToken(data.access);

    //   dispatch(getToken({username, password}))
    // } else {
    //   console.log('no data.access [data]: ');
    //   console.log(data);
    // }


    // try {
    //   const resp = await getAccessToken(username, password);
    //   console.log('resp: ');
    //   console.log(resp);


    // } catch (error:any) {
    //   console.log('resp error : ');
    //   console.log(error);
    //   console.log('error.response : ');
    //   console.log(error.response);

    // }


    // getAccessToken(username, password)
    //   .then(resp => {
    //     console.log('resp from getAccessToken : ');
    //     console.log(resp);
    //     setLoading(false);
    //   })

    //   .catch(err => {
    //     console.log('sonething went wrong while logging in : ');
    //     console.log(err);

    //     setLoading(false);
    //     // setSubmitting(false);
    //     // setStatus('Something went wrong while logging in')
    //   })

  };


  useEffect(() => {
    if (username && password) setIsValid(true)
    else setIsValid(false);
  }, [username, password])

  // const formik = useFormik({
  //   initialValues,
  //   validationSchema: loginSchema,
  //   onSubmit: (values, { setStatus, setSubmitting }) => {
  //     setLoading(true)
  //     setTimeout(() => {
  //       login(values.email, values.password)
  //         .then(({ data: { accessToken } }) => {
  //           setLoading(false)
  //           dispatch(auth.actions.login(accessToken))
  //         })
  //         .catch(() => {
  //           setLoading(false)
  //           setSubmitting(false)
  //           setStatus('The login detail is incorrect')
  //         })
  //     }, 1000)

  //   },
  // })


  // custom formik validator

  // const customFormik = useFormik({
  //   initialValues: {
  //     email: '',
  //     password: ''
  //   }
  // });



  /*
  
  getAccessToken(values.email, values.password)
        .then(resp => {
          console.log('resp from getAccessToken : ');
          console.log(resp);
          setLoading(false);
        })
        
        .catch(err => {
          console.log('sonething went wrong while logging in : ');
          console.log(err);

          setLoading(false);
          setSubmitting(false);
          setStatus('Something went wrong while logging in')
        })
  */

  useEffect(() => {
    if (error) setPassword('');
  }, [error]);

  return (
    <form
      className='form w-100'
      // onSubmit={formik.handleSubmit}
      onSubmit={loginHandler}
      noValidate
      id='kt_login_signin_form'
    >
      {/* begin::Heading */}
      <div className='text-center mb-10'>
        <h1 className='text-dark mb-3'>Sign In to Metronic</h1>
        <div className='text-gray-400 fw-bold fs-4'>
          New Here?{' '}
          <Link to='/auth/registration' className='link-primary fw-bolder'>
            Create an Account
          </Link>
        </div>
      </div>
      {/* begin::Heading */}

      {/* {formik.status ? (
        <div className='mb-lg-15 alert alert-danger'>
          <div className='alert-text font-weight-bold'>{formik.status}</div>
        </div>
      ) : (
        <div className='mb-10 bg-light-info p-8 rounded'>
          <div className='text-info'>
            Use account <strong>admin@demo.com</strong> and password <strong>demo</strong> to
            continue.
          </div>
        </div>
      )} */}

      {/* begin::Form group */}
      <div className='fv-row mb-10'>
        <label className='form-label fs-6 fw-bolder text-dark'>Username</label>
        <input
          placeholder='Username'
          // {...formik.getFieldProps('email')}
          className={clsx(
            'form-control form-control-lg form-control-solid',
            // { 'is-invalid': formik.touched.email && formik.errors.email },
            // { 'is-valid': formik.touched.email && !formik.errors.email }
          )}

          // onChange={customFormik.handleChange}
          type='text'
          name='username'
          autoComplete='off'
          value={username}
          onChange={e => setUsername(e.target.value)}
        />
        {/* {formik.touched.email && formik.errors.email && (
          <div className='fv-plugins-message-container'>
            <span role='alert'>{formik.errors.email}</span>
          </div>
        )} */}
      </div>
      {/* end::Form group */}

      {/* begin::Form group */}
      <div className='fv-row mb-10'>
        <div className='d-flex justify-content-between mt-n5'>
          <div className='d-flex flex-stack mb-2'>
            {/* begin::Label */}
            <label className='form-label fw-bolder text-dark fs-6 mb-0'>Password</label>
            {/* end::Label */}
            {/* begin::Link */}
            <Link
              to='/auth/forgot-password'
              className='link-primary fs-6 fw-bolder'
              style={{ marginLeft: '5px' }}
            >
              Forgot Password ?
            </Link>
            {/* end::Link */}
          </div>
        </div>
        <input
          type='password'
          autoComplete='off'
          placeholder='Password'
          // {...formik.getFieldProps('password')}
          className={clsx(
            'form-control form-control-lg form-control-solid',
            // { 'is-invalid': formik.touched.password && formik.errors.password },
            // { 'is-valid': formik.touched.password && !formik.errors.password }
          )}
          value={password}
          onChange={e => setPassword(e.target.value)}
        />
        {/* {formik.touched.password && formik.errors.password && (
          <div className='fv-plugins-message-container'>
            <div className='fv-help-block'>
              <span role='alert'>{formik.errors.password}</span>
            </div>
          </div>
        )} */}


        {/* auth error message */}
        {/* <div className='alert alert-danger mt-5' role='alert'>
          Invalid credentials
        </div> */}

        {error && (<div className='mt-5 text-danger fw-bold' role='alert'>
          {error}
        </div>)}
        {/* end: auth error message */}

      </div>
      {/* end::Form group */}



      {/* begin::Action */}
      <div className='text-center'>
        <button
          type='submit'
          id='kt_sign_in_submit'
          className='btn btn-lg btn-primary w-100 mb-5'
          // disabled={formik.isSubmitting || !formik.isValid}
          disabled={!isValid}
          onClick={loginHandler}
        >
          {!loading && <span className='indicator-label'>Continue</span>}
          {loading && (
            <span className='indicator-progress' style={{ display: 'block' }}>
              Please wait...
              <span className='spinner-border spinner-border-sm align-middle ms-2'></span>
            </span>
          )}
        </button>

        {/* begin::Separator */}
        {/* <div className='text-center text-muted text-uppercase fw-bolder mb-5'>or</div> */}
        {/* end::Separator */}

        {/* begin::Google link */}
        {/* <a href='#' className='btn btn-flex flex-center btn-light btn-lg w-100 mb-5'>
          <img
            alt='Logo'
            src={toAbsoluteUrl('/media/svg/brand-logos/google-icon.svg')}
            className='h-20px me-3'
          />
          Continue with Google
        </a> */}
        {/* end::Google link */}

        {/* begin::Google link */}
        {/* <a href='#' className='btn btn-flex flex-center btn-light btn-lg w-100 mb-5'>
          <img
            alt='Logo'
            src={toAbsoluteUrl('/media/svg/brand-logos/facebook-4.svg')}
            className='h-20px me-3'
          />
          Continue with Facebook
        </a> */}
        {/* end::Google link */}

        {/* begin::Google link */}
        {/* <a href='#' className='btn btn-flex flex-center btn-light btn-lg w-100'>
          <img
            alt='Logo'
            src={toAbsoluteUrl('/media/svg/brand-logos/apple-black.svg')}
            className='h-20px me-3'
          />
          Continue with Apple
        </a> */}
        {/* end::Google link */}
      </div>
      {/* end::Action */}
    </form>
  )
}
