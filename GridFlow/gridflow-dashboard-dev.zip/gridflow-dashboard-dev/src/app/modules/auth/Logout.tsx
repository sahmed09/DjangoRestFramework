import React, {useEffect} from 'react'
import {useDispatch, useSelector} from 'react-redux'
import {Redirect, Switch} from 'react-router-dom'
import { resetToken } from '../../redux/slices/authSlice'
import { AppState } from '../../redux/store'
import * as auth from './redux/AuthRedux'

export function Logout() {
  const dispatch = useDispatch()

  const { token, error } = useSelector((state: AppState) => state.auth);
  


  useEffect(() => {
    dispatch(auth.actions.logout())
    document.location.reload()
  }, [dispatch])



  useEffect(() => {
    localStorage.removeItem('token');
    // dispatch(resetToken());
    // remove token from Axios Header and localStorage
    // unsetAxiosAuthToken();
    document.location.reload()
  }, [])

  return (
    <Switch>
      <Redirect to='/auth/login' />
    </Switch>
  )
}
