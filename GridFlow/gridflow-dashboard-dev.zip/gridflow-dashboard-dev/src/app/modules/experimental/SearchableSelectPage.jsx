import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Redirect, Route, Switch } from 'react-router-dom'

import { AppState } from '../../redux/store';


// see: https://www.npmjs.com/package/react-select-search
import SelectSearch, { useSelect } from 'react-select-search';
import { getCategories } from '../../redux/slices/categorySlice';
import { getCategoryBySlug, searchCategory } from '../../api/categoryAPI';
import { select } from '@redux-saga/core/effects';

const SearchableSelectPage = () => {

    const { categories, error, hasNext, hasPrevious, page } = useSelector((state) => state.category);
    const dispatch = useDispatch();


    const [selectOptions, setSelectOptions] = useState([])




    // useEffect(() => {
    //     console.log('selectOptions: ');
    //     console.log(selectOptions);
    // }, [selectOptions])



    const [fetchedResults, setFetchedResults] = useState([])
    // const [isSearching, setIsSearching] = useState(false)

    const [selectedValue, setSelectedValue] = useState("")
    // const [selectedValueObj, setSelectedValueObj] = useState(null)


    // fetch categories
    useEffect(() => {
        dispatch(getCategories())
    }, [])

    // map fetched data to use with select 
    useEffect(() => {
        const x = categories.map(cat => ({ name: cat.name, value: cat.slug }));

        setSelectOptions(x)
    }, [categories])




    // useEffect(() => {
    //     console.log('fetched results : ');
    //     console.log(fetchedResults);
    // }, [fetchedResults])




    // const options = [
    //     { name: 'Swedish', value: 'sv' },
    //     { name: 'English', value: 'en' },
    //     // {
    //     //     type: 'group',
    //     //     name: 'Group name',
    //     //     items: [
    //     //         { name: 'Spanish', value: 'es' },
    //     //     ]
    //     // },
    // ];

    // const handleSearch = (q) => {
    //     console.log({ q });

    //     // find in local state
    //     let _data = categories.filter(category => category.name === q);

    //     console.log("_data: ");
    //     console.log(_data);

    //     // query API
    // }


    // onchange handler returns the 'value'
    const handleOnChange = (value) => {
        console.log('handleOnChange');
        console.log(value);
    }


    // search handler
    const getOptions = async (query) => {
        console.log('getOptions()');

        console.log('query: ');
        console.log(query);

        if (query.length < 3) return;


        const { status, data } = await searchCategory(query);

        console.log(':: getCategoryBySlug ::');

        console.log(data);

        if (data.count > 0) {
            // setIsSearching(false);

            setFetchedResults(data.results)

            // prepare results
            const x = data.results.map(cat => ({ name: cat.name, value: cat.slug }))

            // set select options
            // setSelectOptions(data.results)
            setSelectOptions(x)

            setSelectedValue(data.results[0].slug)
        }

        console.log('query results: ');
        console.log(data.results);


    }




    return (
        <div>
            <h2>Select search</h2>

            {/* <button {...valueProps}>{snapshot.displayValue}</button>
            {snapshot.focus && (
                <ul>
                    {snapshot.options.map((option) => (
                        <li key={option.value}>
                            <button {...optionProps} value={option.value}>{option.name}</button>
                        </li>
                    ))}
                </ul>
            )} */}


            {/* <SelectSearch
                options={[
                    { value: 's', name: 'Small' },
                    { value: 'm', name: 'Medium' },
                    { value: 'l', name: 'Large' },
                ]}
                placeholder="Choose a size"
            /> */}

            {/* <SelectSearch
                // getOptions={handleSearch}
                // getOptions={getOptions}
                // options={options}
                // value="sv"
                options={selectOptions}
                value={selectOptions[0]?.value}
                // options={categories}
                // search={true}
                // value="fridge"
                // value={selectedValue}
                name="language"
                placeholder="Choose your language" /> */}


            {/* use this, otherwise default value won't work  */}
            {selectOptions.length > 0 && (
                <SelectSearch
                    // getOptions={handleSearch}
                    getOptions={getOptions}
                    // options={options}
                    // value="sv"
                    options={selectOptions}
                    value={selectOptions[0]?.value}
                    onChange={handleOnChange}
                    // options={categories}
                    search={true}
                    // value="fridge"
                    // value={selectedValue}
                    name="language"
                    placeholder="Choose your language" />
            )}


        </div>
    );

}

export default SearchableSelectPage
