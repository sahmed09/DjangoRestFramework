import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { deleteDeliveryAgency, getDeliveryAgencyList } from '../../../api/deliveryAgencyAPI';
import Card from '../../../components/Card'
import { getDeliveryAgencies } from '../../../redux/slices/deliveryAgencySlice';
import { setModalData, showModal } from '../../../redux/slices/modalSlice';
import { AppState } from '../../../redux/store';


interface IAgency {
    id: number
    name: string
    address: string
    email: string
    mobile: string
    logo?: number
}

interface IAgencyProps extends IAgency {
    // button/checkbox click handlers
    checkHandler?: (e: React.FormEvent<HTMLButtonElement>, id: number) => void
    editHandler?: (e: React.FormEvent<HTMLButtonElement>, id: number) => void
    deleteHandler?: (e: React.FormEvent<HTMLButtonElement>, id: number) => void
}


const AgencyListItem: React.FC<IAgencyProps> = ({ id, name, address, email, mobile, logo = null, checkHandler = null, editHandler = null, deleteHandler = null }) => (
    <div className="row border-bottom /*border-dark*/ cursor-pointer mt-2 p-2" style={{ backgroundColor: '', height: 50 }}>
        <div className="d-flex align-items-center h-100 p-0" style={{ backgroundColor: '' }}>
            {/* checkbox */}
            <div style={{ width: 30, backgroundColor: '', marginRight: 10 }}>
                <input className="form-check-input" type="checkbox" />
            </div>

            {/* shop name */}
            <div style={{ flex: 1, backgroundColor: '', marginRight: 10 }}>{name}</div>
            <div style={{ flex: 1, backgroundColor: '', marginRight: 10 }}>{address}</div>
            <div style={{ flex: 1, backgroundColor: '', marginRight: 10 }}>{mobile}</div>

            {/* control buttons */}
            <div className="d-flex justify-content-end" style={{ width: 85, backgroundColor: '' }}>

                {/* edit button */}
                <button
                    onClick={e => editHandler ? editHandler(e, id) : e.preventDefault()}
                    className="btn btn-sm me-2 px-3"
                    style={{ backgroundColor: '' }}>
                    < i className="bi bi-pencil"></i>
                </button>

                {/* delete button */}
                <button
                    onClick={e => deleteHandler ? deleteHandler(e, id) : e.preventDefault()}
                    className="btn btn-sm px-3"
                    style={{ backgroundColor: '' }}>
                    < i className="bi bi-trash"></i>
                </button>

            </div>
            {/* end: control buttons */}

        </div>
    </div>
);






export default function AgencyList() {

    const dispatch = useDispatch();
    const { agencies, page, hasNext, hasPrevious } = useSelector((state: AppState) => state.deliveryAgency)

    useEffect(() => {
        // fetchAgencies()
        dispatch(getDeliveryAgencies(page))
    }, [])


    const editClickHandler = async (e: React.FormEvent<HTMLButtonElement>, id: number) => {
        e.preventDefault()

        const filteredAgency = agencies.find(item => item.id === id);

        dispatch(setModalData(filteredAgency))
        dispatch(showModal())
    };



    const deleteClickHandler = async (e: React.FormEvent<HTMLButtonElement>, id: number) => {
        e.preventDefault();

        const confirmDelete = window.confirm('Delete delivery agency?');
        if (!confirmDelete) return;

        const { status } = await deleteDeliveryAgency(id)

        if (status === 204) {
            // reload delivery agency list
            dispatch(getDeliveryAgencies(page))
        }
        else alert(`Something went wrong [status: ${status}]`)

    };


    return (
        <Card cardHeading="Customer List">
            {/* <pre>{JSON.stringify(customers, null, 4)}</pre> */}

            {/* list heading */}
            <div className="row p-2" style={{ backgroundColor: '', borderBottom: '1px solid #cfcfcf', height: 50 }}>
                <div className="d-flex align-items-center h-100 p-0" style={{ backgroundColor: '' }}>

                    {/* todo: add checkbox to select all items */}
                    <div style={{ width: 30, backgroundColor: '', marginRight: 10 }}>
                    </div>

                    <div
                        style={{ flex: 1, backgroundColor: '', marginRight: 10, fontWeight: 600 }}>
                        Name
                    </div>

                    <div
                        style={{ flex: 1, backgroundColor: '', marginRight: 10, fontWeight: 600 }}>
                        Address
                    </div>

                    <div
                        style={{ flex: 1, backgroundColor: '', marginRight: 10, fontWeight: 600 }}>
                        Phone
                    </div>

                    <div
                        className="d-flex justify-content-end"
                        style={{ width: 85, backgroundColor: '' }}>
                    </div>

                </div>
            </div>
            {/* end: list heading */}


            {/* render agency list */}
            {agencies.length > 0 && agencies.map(agency => (
                <AgencyListItem
                    // @ts-ignore
                    id={agency.id}
                    // @ts-ignore
                    key={agency.id}
                    // @ts-ignore
                    name={agency.name}
                    // @ts-ignore
                    address={agency.address}
                    // @ts-ignore
                    email={agency.email}
                    // @ts-ignore
                    mobile={agency.mobile}

                    editHandler={editClickHandler}
                    deleteHandler={deleteClickHandler}
                />
            ))}
            {/* end: render agency list */}


        </Card>
    )
}
