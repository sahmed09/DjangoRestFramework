import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { useHistory } from 'react-router';
import { createDeliveryAgency, updateDeliveryAgency } from '../../../api/deliveryAgencyAPI';
import { getDeliveryAgencies } from '../../../redux/slices/deliveryAgencySlice';
import { hideModal, resetModal, resetModalData } from '../../../redux/slices/modalSlice';
import { AppState } from '../../../redux/store';

export default function AgencyForm() {

    const history = useHistory();

    const dispatch = useDispatch();
    // const { page } = useSelector((state: AppState) => state.deliveryAgency);
    // const { visible, modalData } = useSelector((state: AppState) => state.modal);

    const { page, visible, modalData } = useSelector((state: AppState) => ({
        ...state.deliveryAgency,
        ...state.modal,
    }))






    // form input state
    const [name, setName] = useState('')
    const [email, setEmail] = useState('')
    const [mobile, setMobile] = useState('')
    const [address, setAddress] = useState('')

    // form control
    const [submitButtonEnabled, setSubmitButtonEnabled] = useState(false);


    // for update operation, populate form fields with existing values
    useEffect(() => {
        if (!modalData) return;
        setName(modalData.name);
        setEmail(modalData.email);
        setMobile(modalData.mobile);
        setAddress(modalData.address);

        return () => { dispatch(resetModalData()) }
    }, [modalData])

    // const resetForm = () => {
    //     setName('');
    //     setEmail('');
    //     setMobile('');
    //     setAddress('');
    // };

    // useEffect(() => {
    //     if (!visible) resetForm()
    // }, [visible])



    // enable submit button when all fields are valid
    // todo: replace with formik validator
    useEffect(() => {
        if (name === "" || email === "" || mobile === "" || address === "") {
            setSubmitButtonEnabled(false)
            return
        }
        setSubmitButtonEnabled(true)
    }, [name, email, mobile, address])


    const formSaveHandler = async (e: React.FormEvent<any>) => {
        e.preventDefault();

        console.log('submitted');

        // update operation
        if (modalData) {
            const { status, errorMessage } = await updateDeliveryAgency(modalData.id, name, mobile, email, address);

            if (status === 200) {
                // reset modal data & state
                dispatch(resetModal())
                // reset form data
                // resetForm()
                // reload brands
                dispatch(getDeliveryAgencies(page))
            }
            else if (errorMessage) alert(errorMessage);
            else alert(`[update] Something wrong happened [status: ${status}]`);

            return
        }

        // create operation
        const { data, status } = await createDeliveryAgency(name, mobile, email, address);

        console.log({ data, status });


        if (status === 201) {
            // close modal
            dispatch(hideModal())

            // reload delivery agency list
            dispatch(getDeliveryAgencies(page))
        }

        else alert(`Something went wrong [status: ${status}]`)

    };


    return (
        <form
            onSubmit={formSaveHandler}
            noValidate className='form'>

            {/* name input area */}
            <div className='row mb-6' style={{ backgroundColor: '' }}>
                <label className='col-md-2 col-form-label required fw-bold fs-6' style={{ backgroundColor: '' }}>Name</label>
                <div className='col-md-10'>
                    <div className='row'>
                        <div className='col-md-12 fv-row'>
                            <input
                                type='text'
                                className='form-control form-control-md form-control-solid mb-3 mb-lg-0'
                                placeholder='Delivery Agency Name'
                                value={name}
                                autoFocus
                                onChange={e => setName(e.target.value)}
                            />
                        </div>
                    </div>
                </div>
            </div>
            {/* end: name input area */}


            {/* email input area */}
            <div className='row mb-6' style={{ backgroundColor: '' }}>
                <label className='col-md-2 col-form-label required fw-bold fs-6' style={{ backgroundColor: '' }}>Email</label>
                <div className='col-md-10'>
                    <div className='row'>
                        <div className='col-md-12 fv-row'>
                            <input
                                type='email'
                                className='form-control form-control-md form-control-solid mb-3 mb-lg-0'
                                placeholder='Email'
                                value={email}
                                autoFocus
                                onChange={e => setEmail(e.target.value)}
                            />
                        </div>
                    </div>
                </div>
            </div>
            {/* end: email input area */}


            {/* phone input area */}
            <div className='row mb-6' style={{ backgroundColor: '' }}>
                <label className='col-md-2 col-form-label required fw-bold fs-6' style={{ backgroundColor: '' }}>Phone</label>
                <div className='col-md-10'>
                    <div className='row'>
                        <div className='col-md-12 fv-row'>
                            <input
                                type='text'
                                className='form-control form-control-md form-control-solid mb-3 mb-lg-0'
                                placeholder='Phone Number'
                                value={mobile}
                                autoFocus
                                onChange={e => setMobile(e.target.value)}
                            />
                        </div>
                    </div>
                </div>
            </div>
            {/* end: phone input area */}


            {/* address input area */}
            <div className='row mb-6' style={{ backgroundColor: '' }}>
                <label className='col-md-2 col-form-label required fw-bold fs-6' style={{ backgroundColor: '' }}>Address</label>
                <div className='col-md-10'>
                    <div className='row'>
                        <div className='col-md-12 fv-row'>
                            <input
                                type='text'
                                className='form-control form-control-md form-control-solid mb-3 mb-lg-0'
                                placeholder='Address'
                                value={address}
                                autoFocus
                                onChange={e => setAddress(e.target.value)}
                            />
                        </div>
                    </div>
                </div>
            </div>
            {/* end: address input area */}




            {/* submit button */}
            <div className="row m-0 mt-10 border-top pt-9" style={{ backgroundColor: '' }}>
                <div className='col-sm-2 offset-sm-10 d-flex justify-content-end p-0' style={{ backgroundColor: '' }}>
                    <button
                        className='btn btn-sm btn-primary px-12'
                        disabled={!submitButtonEnabled}
                        type="submit">
                        Save
                    </button>
                </div>
            </div>
            {/* end: submit button */}

        </form>
    )
}
