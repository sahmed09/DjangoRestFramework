import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Redirect, Route, Switch } from 'react-router-dom'
import { PageLink, PageTitle } from '../../../_metronic/layout/core'
import ModalWrapper from '../../components/ModalWrapper'
import { hideModal } from '../../redux/slices/modalSlice'
import { AppState } from '../../redux/store'
import AgencyForm from './sections/AgencyForm'
import AgencyList from './sections/AgencyList'


const pageBreadCrumbs: Array<PageLink> = [
    // Boilerplate root
    {
        title: 'Delivery Agencies',
        path: '/delivery-agencies',
        isSeparator: false,
        isActive: false,
    },

    // separator (-)
    {
        title: '',
        path: '',
        isSeparator: true,
        isActive: false,
    },
]

const ProductsPage: React.FC = () => {

    const { visible, modalData } = useSelector((state: AppState) => state.modal)
    const dispatch = useDispatch();


    const handleClose = () => {
        dispatch(hideModal());
    };

    return (
        <>
            <ModalWrapper modalTitle="Create Delivery Agency" handleClose={handleClose} show={visible}>
                <AgencyForm />
            </ModalWrapper>

            {/* page header tabs (sections) */}
            {/* <PageHeader /> */}

            <Switch>
                <Route path='/delivery-agencies'>
                    <PageTitle breadcrumbs={pageBreadCrumbs}>List</PageTitle>
                    {/* <ListSection /> */}
                    <AgencyList />
                </Route>

            </Switch>

        </>
    )
}

export default ProductsPage
