import React from 'react'


export default function Chatbox() {

    const onEnterPress = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
        if (e.keyCode === 13 && e.shiftKey === false) {
            e.preventDefault()
            // sendMessage()
        }
    }


    return (
        <div
            className='card-body'>
            <div
                className='scroll-y me-n5 pe-5 h-300px h-lg-auto'
                data-kt-element='messages'
                data-kt-scroll='true'
                data-kt-scroll-activate='{default: false, lg: true}'
                data-kt-scroll-max-height='auto'
                data-kt-scroll-dependencies='#kt_header, #kt_toolbar, #kt_footer, #kt_chat_messenger_header, #kt_chat_messenger_footer'
                data-kt-scroll-wrappers='#kt_content, #kt_chat_messenger_body'
                data-kt-scroll-offset='-2px'>


                {/* ******************* */}


                {/* msg area */}
                <div
                    className='d-flex mb-10' style={{ backgroundColor: '' }}>
                    <div
                        // align-items-start
                        // align-items-end
                        className="d-flex flex-column align-items align-items-start">

                        {/* last msg time */}
                        <div className='d-flex align-items-center mb-2'>

                            <div className='ms-3'>
                                {/* <a
                                    href='#'
                                    className='fs-5 fw-bolder text-gray-900 text-hover-primary me-1'>
                                    username
                                </a> */}
                                <span className='fs-5 fw-bolder text-gray-900 me-1'>
                                    username
                                </span>
                                <span className='text-muted fs-7 mb-1 ms-5'>
                                    2 min ago
                                </span>
                            </div>

                        </div>
                        {/* last msg time */}


                        {/* msg text */}
                        <div
                            // bg-light-primary
                            // text-end
                            className="p-5 rounded bg-light-info text-dark fw-bold mw-lg-400px text-start mb-2">
                            This is a test message
                        </div>
                        {/* end: msg text */}



                    </div>
                </div>
                {/* end: msg area */}

                {/* ******************* */}

            </div>

            <div
                className='card-footer pt-4'>
                {/* message text input */}
                <textarea
                    className='form-control form-control-flush mb-3'
                    rows={1}
                    data-kt-element='input'
                    placeholder='Type a message'
                    onKeyDown={onEnterPress}></textarea>
                {/* message text input */}

                <div className='d-flex justify-content-end' style={{ backgroundColor: '' }}>

                    <button
                        className='btn btn-primary'
                        type='button'
                        data-kt-element='send'
                        // onClick={sendMessage}
                        onClick={e => e.preventDefault()}>
                        Send
                    </button>
                </div>
            </div>
        </div >
    )
}
