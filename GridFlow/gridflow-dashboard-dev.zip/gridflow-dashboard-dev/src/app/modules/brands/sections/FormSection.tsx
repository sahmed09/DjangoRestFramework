import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { useHistory, useLocation } from 'react-router';

// @ts-ignore
import { createBrand, updateBrand } from '../../../api/brandAPI';
import { getBrands } from '../../../redux/slices/brandSlice';
import { hideModal, resetModal, resetModalData } from '../../../redux/slices/modalSlice';
import { disableCreateButton, enableCreateButton } from '../../../redux/slices/uiSlice';
import { AppState } from '../../../redux/store';
const FormSection: React.FC = () => {

    const dispatch = useDispatch();

    const { visible, modalData } = useSelector((state: AppState) => state.modal);
    const { page } = useSelector((state: AppState) => state.brand);

    //form state
    const [brandName, setBrandName] = useState('');


    // util funcs

    const resetForm = () => {
        setBrandName('');
    };


    // update form values for update operation
    useEffect(() => {
        if (!modalData) return;
        setBrandName(modalData.name);
    }, [])

    // todo: reset form when component dismounts


    // event handlers
    const saveClickHandler = async (e: React.FormEvent<any>) => {
        e.preventDefault();

        if (!brandName) {
            alert("Band name cannot be empty");
            return;
        }

        // update
        if (modalData) {
            // todo: remove hardcoded album_name
            // const { status, errorMessage } = await updateBrand(modalData.id, brandName, "album_name");
            const { status, errorMessage } = await updateBrand(modalData.id, brandName);

            if (status === 200) {
                // close modal
                dispatch(hideModal());
                // reset modal data & state
                dispatch(resetModalData())
                // reload brands
                dispatch(getBrands(page))
            }
            // else if (errorMessage) createError(errorMessage);
            else if (errorMessage) {
                alert(errorMessage);
                console.log({ status, errorMessage });
            }

            return;
        }

        // create operation
        // todo: remove hardcoded album_name
        // const { status, errorMessage } = await createBrand(brandName, "album_name");
        const { status, errorMessage } = await createBrand(brandName);

        if (status === 201) {
            // close modal
            // dispatch(hideModal());
            // reset modal data & state
            // dispatch(resetModalData())
            // reset full modal state
            dispatch(resetModal())
            // reload brands
            dispatch(getBrands(page))
        }
        else if (errorMessage) alert(errorMessage);
        else alert(`Something went wrong: [status: ${status}]`);

    };


    return (
        <div className='row' style={{ backgroundColor: '' }}>
            <div className="col-lg-12">
                <div className='card mb-5 mb-xl-10' style={{ backgroundColor: '' }}>
                    <div
                        className='card-header border-0'>
                        <div className='card-title m-0'>
                            <h3 className='fw-bolder m-0'>Create Brand</h3>
                        </div>
                    </div>

                    <div className='row' style={{ backgroundColor: '' }}>
                        <form
                            onSubmit={saveClickHandler}
                            noValidate className='form'>
                            <div className='card-body border-top p-9' style={{ backgroundColor: '' }}>

                                {/* brand name area */}
                                <div className='row mb-6'>
                                    <label className='col-lg-2 col-form-label required fw-bold fs-6'>Brand Name</label>

                                    <div className='col-lg-10'>
                                        <div className='row'>
                                            <div className='col-lg-12 fv-row'>
                                                <input
                                                    type='text'
                                                    className='form-control form-control-lg form-control-solid mb-3 mb-lg-0'
                                                    placeholder='Brand Name'
                                                    value={brandName}
                                                    onChange={e => setBrandName(e.target.value)}
                                                />
                                            </div>


                                        </div>
                                    </div>
                                </div>
                                {/* end: brand name area */}

                                {/* submit form btn */}
                                <div className="row mt-10 border-top pt-9" style={{ backgroundColor: '' }}>
                                    <div className='col-lg-4'>
                                        <button
                                            type="submit"
                                            disabled={brandName.length === 0}
                                            className='btn btn-sm btn-primary me-3 px-12'
                                        // onClick={e => e.preventDefault()}
                                        // onClick={saveClickHandler}
                                        >
                                            Save
                                        </button>
                                    </div>
                                </div>
                                {/* end: submit form btn */}





                            </div>


                        </form>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default FormSection;
