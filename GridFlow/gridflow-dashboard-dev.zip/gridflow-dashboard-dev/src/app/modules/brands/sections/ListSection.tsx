import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { Route, useHistory } from 'react-router';
import FilterWrapper from '../../../components/FilterWrapper'
import ListFilter from '../../../components/ListFilter'
import ListItem from '../../../components/ListItem';
import { getBrands, setBrandPage } from '../../../redux/slices/brandSlice';
import { AppState } from '../../../redux/store';

import Pagination from "../../../components/Pagination";
import FormSection from './FormSection';
import { deleteBrand } from '../../../api/brandAPI';
import { setModalData, showModal } from '../../../redux/slices/modalSlice';

export default function ListSection() {


  const { brands, error, hasNext, hasPrevious, page } = useSelector((state: AppState) => state.brand);
  const dispatch = useDispatch();

  const history = useHistory();

  useEffect(() => {
    console.log('Category > useEffect()');

    // if (categories.length > 0) return;

    console.log('fetching categories | page : ', page);
    dispatch(getBrands(page))

  }, [page]);

  const { search } = history.location;


  useEffect(() => {
    const queryString = new URLSearchParams(search);
    const pageNumber = queryString.get('page');
    if (!pageNumber) return;

    const pn = parseInt(pageNumber);
    if (isNaN(pn)) return;

    dispatch(setBrandPage(pn));
  }, [search]);

  const previousClickHandler = (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
    e.preventDefault();

    if (page > 1) {
      dispatch(setBrandPage(page - 1));
      history.push({ search: `?page=${page - 1}` })
    }
  };

  const nextClickHandler = (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
    e.preventDefault();

    dispatch(setBrandPage(page + 1));
    history.push({ search: `?page=${page + 1}` })
  };




  const filterResetClickHandler = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();
    console.log('filter reset');
  }

  const filterApplyClickHandler = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();
    console.log('filter applied');
  }


  const editClickHandler = (e: React.FormEvent<HTMLButtonElement>, id: string | number) => {
    e.preventDefault();

    console.log('edit clicked : ', id);

    // const filteredBrand = brands.filter(brand => brand.id === id)[0];
    const filteredBrand = brands.find(brand => brand.id === id);

    console.log("filteredBrand: ");
    console.log(filteredBrand);
    

    // history.push({
    //   pathname: "/brands/" + id + "/update",
    //   state: {
    //     update: true,
    //     // passedData: id,
    //     passedData: brands.filter(brand => brand.id === id)[0],
    //   }
    // });

    dispatch(setModalData(filteredBrand))
    dispatch(showModal())


    // open modal with data
  }


  const deleteClickHandler = async (e: React.FormEvent<HTMLButtonElement>, id: string | number) => {
    e.preventDefault();

    console.log('delete clicked : ', id);

    // todo: replace with modal
    const confirmDelete = window.confirm(`Delete Brand '${brands.filter(brand => brand.id === id)[0].name}'?`);
    if (!confirmDelete) return;

    const { status, errorMessage } = await deleteBrand(id);

    if (status === 204) history.push("/brands");
    // else if (errorMessage) createError(errorMessage);
    else if (errorMessage) alert(errorMessage);


  }







  const filterContent = (
    <div style={{ backgroundColor: 'skyblue' }}>
      <p>Filter content</p>
    </div>
  );

  // return (
  //   <div className="row">

  //     {/* filter area */}

  //     {/* <ListFilter /> */}

  //     {/* <FilterWrapper
  //       header="Page Filter">
  //       {filterContent}
  //     </FilterWrapper> */}

  //     {/* end: filter area */}


  //     <div className="col-md-12" style={{ backgroundColor: '' }}>

  //       <div className="panel panel-default panel-table">

  //         <div className="panel-heading">
  //           <div className="row">
  //             <div className="col col-xs-6">
  //               <h3 className="panel-title">Brands</h3>
  //             </div>
  //             {/* <div className="col col-xs-6 text-right">
  //               <button type="button" className="btn btn-sm btn-primary btn-create">Create New</button>
  //             </div> */}
  //           </div>
  //         </div>

  //         <div className="panel-body">


  // {brands.length && brands.map(brand => (
  //   <ListItem
  //     key={brand.slug}
  //     id={brand.id}
  //     columnOneValue={brand.name}
  //     columnOneWidth="100%"

  //     editButtonHandler={editClickHandler}
  //     deleteButtonHandler={deleteClickHandler}
  //   />
  // ))}

  //           {/* <ListItem
  //             columnOneValue='Brand One'
  //             columnOneWidth="100%"
  //           /> */}



  //           {/* pagination */}
  //           <Pagination
  //             infoText="Pagination"
  //             previous={hasPrevious}
  //             next={hasNext}

  //             previousClickHandler={previousClickHandler}
  //             nextClickHandler={nextClickHandler}
  //           />




  //         </div>

  //       </div>

  //     </div>
  //   </div>
  // )

  return (
    <div className='card mb-5 mb-xl-10' style={{ backgroundColor: '' }}>

      {/* card heading */}
      <div
        className='card-header border-0'>
        <div className='card-title m-0'>
          <h3 className='fw-bolder m-0'>Brands</h3>
        </div>
      </div>
      {/* end: card heading */}


      {/* card body */}
      <div className="card-body border-top px-9 py-5">

        {/* todo: add list heading */}

        {/* brand list */}
        {brands.length > 0 && brands.map(brand => (
          <ListItem
            key={brand.slug}
            id={brand.id}
            columnOneValue={brand.name}
            columnOneWidth="100%"

            editButtonHandler={editClickHandler}
            deleteButtonHandler={deleteClickHandler}
          />
        ))}
        {/* end: brand list */}

        {/* pagination */}
        <Pagination
          infoText="Pagination"
          previous={hasPrevious}
          next={hasNext}

          previousClickHandler={previousClickHandler}
          nextClickHandler={nextClickHandler}
        />



      </div>
      {/* end: card body */}
    </div>
  )
}
