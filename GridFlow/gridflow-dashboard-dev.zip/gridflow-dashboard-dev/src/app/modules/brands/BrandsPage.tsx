import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Redirect, Route, Switch } from 'react-router-dom'
import { PageLink, PageTitle } from '../../../_metronic/layout/core'
import ModalWrapper from '../../components/ModalWrapper'
import { hideModal } from '../../redux/slices/modalSlice'
import { AppState } from '../../redux/store'
import { PageHeader } from './PageHeader'
import FormSection from './sections/FormSection'
import ListSection from './sections/ListSection'
// import { Overview } from './components/Overview'
// import { Projects } from './components/Projects'
// import { Campaigns } from './components/Campaigns'
// import { Documents } from './components/Documents'
// import { Connections } from './components/Connections'
// import { BoilerplateHeader } from './BoilerplateHeader'

const pageBreadCrumbs: Array<PageLink> = [
    // Boilerplate root
    {
        title: 'Brands',
        path: '/brands/list',
        isSeparator: false,
        isActive: false,
    },

    // separator (-)
    {
        title: '',
        path: '',
        isSeparator: true,
        isActive: false,
    },
]

const ProductsPage: React.FC = () => {

    const { visible, modalData } = useSelector((state: AppState) => state.modal)
    const dispatch = useDispatch();


    const handleClose = () => {
        dispatch(hideModal());
    };

    return (
        <>

            <ModalWrapper modalTitle="Create Brand" handleClose={handleClose} show={visible}>
                <FormSection />
            </ModalWrapper>



            {/* page header tabs (sections) */}
            {/* <PageHeader /> */}

            {/* page sections (tabs) as route */}
            <Switch>
                <Route path='/brands/list'>
                    <PageTitle breadcrumbs={pageBreadCrumbs}>List</PageTitle>
                    <ListSection />
                </Route>

                <Route path='/brands/add'>
                    <PageTitle breadcrumbs={pageBreadCrumbs}>Add Brand</PageTitle>
                    <FormSection />
                </Route>

                {/* experimental */}
                <Route path='/brands/:id/update'>
                    <PageTitle breadcrumbs={pageBreadCrumbs}>Update Brand</PageTitle>
                    <FormSection />
                </Route>
                {/* end: experimental */}



                {/* redirects for this page */}
                <Redirect from='/brands' exact={true} to='/brands/list' />
                <Redirect to='/brands/list' />
            </Switch>
            {/* end: page sections (tabs) as route */}

        </>
    )
}

export default ProductsPage
