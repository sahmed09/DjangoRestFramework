import React, { useState } from 'react'
import SelectSearch from 'react-select-search'
import { IProduct } from "../../../interfaces";
import { addItemToOrder } from '../../api/orderItemAPI';

interface IProductSelectOption {
    name: string
    value: string
}

export interface IOrderProduct {
    name: string
    orderID: string
    productList: IProductSelectOption[]
}

const OrderProduct: React.FC<IOrderProduct> = ({ name, orderID, productList }) => {

    const [selectedProduct, setSelectedProduct] = useState('');
    const [quantity, setQuantity] = useState('');

    const [itemAdded, setItemAdded] = useState(false);

    const orderProductSaveHandler = async (e: React.MouseEvent<any>) => {
        e.preventDefault();

        console.log('saving order product: ');
        console.log(selectedProduct, quantity);

        // convert product quantity to int
        const _q = parseInt(quantity);
        if (isNaN(_q)) return;



        const { data, status, errorMessage } = await addItemToOrder(selectedProduct, _q, orderID);

        console.log({ data, status, errorMessage });


        if (status === 201) {
            console.log('item added to order');
            setItemAdded(true);
        }
        else alert(`Something went wrong [status: ${status}]`)
    };


    // console.log(product);


    return (
        <div>
            <div className="row mb-5 w-100" style={{ backgroundColor: "" }}>
                {/* <label
                    style={{ backgroundColor: "" }}
                    htmlFor="customer"
                    className='col-md-2 col-form-label required fw-bold fs-6'>
                    Product
                </label> */}

                <div className='col-md-9' style={{ backgroundColor: '' }}>
                    <div className='row'>
                        <div className='col-lg-12' style={{}}>

                            <SelectSearch
                                options={productList}
                                value={selectedProduct}
                                // @ts-ignore
                                name={name}
                                // @ts-ignore
                                onChange={v => setSelectedProduct(v)}
                                // search={true}
                                placeholder='Select Product' />

                        </div>
                    </div>
                </div>


                {/* quantity */}
                <div className='col-md-2' style={{ backgroundColor: '' }}>
                    <input
                        type='text'
                        className='form-control form-control-lg form-control-solid mb-3 mb-lg-0'
                        placeholder='Quantity'
                        value={quantity}
                        autoFocus
                        onChange={e => setQuantity(e.target.value)}
                    />
                </div>

                <div className='col-md-1' style={{ backgroundColor: '' }}>
                    {/* todo: use same button to remove item from order */}
                    <button
                        onClick={orderProductSaveHandler}
                        disabled={itemAdded}
                        className="btn btn-sm btn-primary">
                        {/* Add */}
                        {itemAdded ? "Added" : "Add"}
                    </button>
                </div>
                {/* end: quantity */}
            </div>
        </div>
    )
}

export default OrderProduct;
