// OrderForm.tsx

import React, { useEffect, useState } from 'react';
import SelectSearch from 'react-select-search';
import { getCustomerByPhone } from '../../../api/customerAPI';
import { getAreas, getLocations } from '../../../api/locationAPI';
import { getProducts } from '../../../api/productAPI';

import Card from "../../../components/Card";
import OrderProduct from '../OrderProduct';

// @ts-ignore
import { v4 as uuidv4 } from 'uuid'
import { createNewOrder } from '../../../api/orderAPI';
import { getShops } from '../../../api/shopAPI';
import { getShopProducts } from '../../../api/shopBranchAPI';

export default function OrderForm() {


    // form data
    const [formStep, setFormStep] = useState(1);
    const [nextBtnEnabled, setNextBtnEnabled] = useState(false);

    const [shopList, setShopList] = useState([]);
    const [selectedShop, setSelectedShop] = useState('');

    const fetchShopList = async (page: number) => {
        const { data, status } = await getShops(page);

        console.log({ data, status });

        if (status !== 200) {
            alert(`[fetchShopList] Something went wrong [status: ${status}]`)
            return;
        }

        // @ts-ignore
        const preparedData = data.results.map(item => ({ name: item.name, value: item.slug }))
        setShopList(preparedData)
    };

    useEffect(() => {
        fetchShopList(1)
    }, [])


    useEffect(() => {
        console.log({ selectedShop });

    }, [selectedShop])

    // step 1
    const [phoneNumber, setPhoneNumber] = useState('');
    const [customer, setCustomer] = useState(null);
    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [customerSearching, setCustomerSearching] = useState(false);

    const searchCustomerByPhone = async (number: string, shopSlug: string) => {
        // const { status, data, errorMessage } = await getCustomerByPhone(number);
        const { status, data, errorMessage } = await getCustomerByPhone(number, shopSlug);
        console.log({ status, data, errorMessage });
        setCustomerSearching(false);

        if (status !== 200) {
            console.log('Error searching customer');
            console.log(status);
            console.log(errorMessage);
            return
        }
        // @ts-ignore
        setCustomer(data.results[0]);
    };

    // useEffect(() => {
    //     if (phoneNumber.length < 11) return;
    //     setCustomerSearching(true)
    //     searchCustomerByPhone(phoneNumber);
    // }, [phoneNumber])

    useEffect(() => {
        if (phoneNumber.length < 11 || !selectedShop || selectedShop === '') return;
        setCustomerSearching(true)
        searchCustomerByPhone(phoneNumber, selectedShop);
    }, [phoneNumber, selectedShop])



    useEffect(() => {
        if (!customer || customer === undefined) return;
        // @ts-ignore
        setFirstName(customer.first_name);
        // @ts-ignore
        setLastName(customer.last_name);

        // enable form next button
        setNextBtnEnabled(true);
    }, [customer])

    // end: step - 1 



    // step - 2
    const [email, setEmail] = useState('')
    const [address, setAddress] = useState('')
    const [locationList, setLocationList] = useState([]);
    const [selectedLocation, setSelectedLocation] = useState('');


    const fetchLocations = async (page: number) => {
        // const { status, data, errorMessage } = await getLocations(1);
        const { status, data, errorMessage } = await getAreas(1);

        if (status !== 200) {
            console.log('Error while fetching location list');
            console.log(status);
            console.log(errorMessage);
            return
        }

        // prepare payload
        // @ts-ignore
        const preparedLocations = data.results.map(item => ({ name: item.name, value: item.name }))
        setLocationList(preparedLocations)
    };




    useEffect(() => {
        console.log('locationList');
        console.log(locationList);

    }, [locationList])


    // fetch locations when customer is found

    useEffect(() => {
        if (!customer || customer === undefined) return
        fetchLocations(1);
    }, [customer])



    // order object {necessary field: transaction_id}
    const [order, setOrder] = useState();

    const saveOrder = async (e: React.MouseEvent<any>) => {
        console.log('saveOrder()');

        const { status, data, errorMessage } = await createNewOrder(phoneNumber, phoneNumber, email, address, selectedLocation);

        console.log({ status, data, errorMessage });

        if (status === 201) {
            // save order order transaction_id
            setOrder(data)
        }

        else alert(`Something went wrong [status: ${status}]`)

    };



    // end: step - 2



    // step - 3 : product search and enlist

    const [productList, setProductList] = useState([])

    const fetchProductList = async (page: number) => {

        console.log('fetchProductList()');

        // todo: replace with getShopProducts()
        // const { status, data, errorMessage } = await getProducts(1);
        const { status, data, errorMessage } = await getShopProducts(selectedShop);

        console.log({ status, data, errorMessage });


        if (status !== 200) {
            console.log('Error while fetching customer list');
            console.log(status);
            console.log(errorMessage);
            return
        }

        console.log(data.results);
        

        // prepare payload
        // @ts-ignore
        const preparedProducts = data.results.map(item => ({ name: item.product.name, value: item.product.slug }))
        setProductList(preparedProducts)
    };


    useEffect(() => {
        console.log("productList : ");
        console.log(productList);
        
    }, [productList])

    const [orderProductList, setOrderProductList] = useState([
        {
            id: uuidv4(),
            name: '',
        },
    ])


    const addNewProduct = () => {
        setOrderProductList(prlist => ([
            ...prlist,
            {
                id: uuidv4(),
                name: '',
            },
        ]))
    };

    // fetch product list when customer loads
    // useEffect(() => {
    //     if (!customer || customer === undefined) return
    //     fetchProductList(1);


    //     console.log({ customer });

    // }, [customer])


    // fetch shop product list when shop is selected
    useEffect(() => {
        console.log({ selectedShop });
        if (!selectedShop || selectedShop === '') return

        fetchProductList(1);
    }, [selectedShop])
    // end: step - 3




    return (
        <Card cardHeading="Create new order">

            <form onSubmit={e => e.preventDefault()}>

                {/* select shop */}
                {shopList.length > 0 && (
                    <div className='row'>
                        <label className='col-lg-2 col-form-label required fw-bold fs-6'>Select Shop</label>
                        <div className='col-lg-10'>
                            <div className='row'>
                                <div className='col-lg-12 fv-row'>
                                    <SelectSearch
                                        options={shopList}
                                        value={selectedShop}
                                        // @ts-ignore
                                        name="shop"
                                        // @ts-ignore
                                        onChange={v => setSelectedShop(v)}
                                        // search={true}
                                        placeholder='Select Shop' />
                                </div>
                            </div>
                        </div>
                    </div>
                )}
                {/* end: select shop */}

                {/* step - 1 : find user by phone number | create new user */}
                {selectedShop.length > 0 && (
                    <>
                        <div className='row'>
                            <label className='col-lg-2 col-form-label required fw-bold fs-6'>Phone Number</label>
                            <div className='col-lg-10'>
                                <div className='row'>
                                    <div className='col-lg-12 fv-row'>
                                        <input
                                            type='text'
                                            className='form-control form-control-lg form-control-solid mb-3 mb-lg-0'
                                            placeholder='Phone Number'
                                            value={phoneNumber}
                                            autoFocus
                                            onChange={e => setPhoneNumber(e.target.value)}
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className='row mb-6'>
                            {customerSearching && (<p className="">Searching customer...</p>)}
                            {/* {foundCustomer === undefined && (<p className="text-danger">No customer found with this phone number</p>)} */}
                            {customer === undefined && (
                                <>
                                    <p className="text-danger">No shop customer found with this phone number</p>

                                    <div className="d-flex">
                                        <button className="btn btn-primary btn-sm w-100">
                                            Create New Customer
                                        </button>
                                    </div>
                                </>
                            )}

                            {customer && (<p>Customer found: {firstName} {lastName}</p>)}
                        </div>

                    </>
                )}
                {/* end: step - 1 */}


                {/* step - 2 : customer address */}
                {customer && (
                    <>
                        {/* email area */}
                        <div className='row mb-6'>
                            <label className='col-lg-2 col-form-label required fw-bold fs-6'>Email</label>
                            <div className='col-lg-10'>
                                <div className='row'>
                                    <div className='col-lg-12 fv-row'>
                                        <input
                                            type='text'
                                            className='form-control form-control-lg form-control-solid mb-3 mb-lg-0'
                                            placeholder='Email'
                                            value={email}
                                            autoFocus
                                            onChange={e => setEmail(e.target.value)}
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>
                        {/* end: email area */}

                        {/* address area */}
                        {/* todo: replace with <textfield> */}
                        <div className='row mb-6'>
                            <label className='col-lg-2 col-form-label required fw-bold fs-6'>Address</label>
                            <div className='col-lg-10'>
                                <div className='row'>
                                    <div className='col-lg-12 fv-row'>
                                        <input
                                            type='text'
                                            className='form-control form-control-lg form-control-solid mb-3 mb-lg-0'
                                            placeholder='Address'
                                            value={address}
                                            autoFocus
                                            onChange={e => setAddress(e.target.value)}
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>
                        {/* end: address area */}

                        {/* location select area */}
                        {locationList.length > 0 && (
                            <div className="row mb-5 w-100" style={{ backgroundColor: "" }}>
                                <label
                                    style={{ backgroundColor: "" }}
                                    htmlFor="customer"
                                    className='col-md-2 col-form-label required fw-bold fs-6'>
                                    Location
                                </label>

                                <div className='col-md-10' style={{ backgroundColor: '' }}>
                                    <div className='row'>
                                        <div className='col-lg-12' style={{}}>

                                            <SelectSearch
                                                options={locationList}
                                                value={selectedLocation}
                                                // @ts-ignore
                                                name="location"
                                                // @ts-ignore
                                                onChange={v => setSelectedLocation(v)}
                                                // search={true}
                                                placeholder='Select Location' />


                                        </div>
                                    </div>
                                </div>
                            </div>
                        )}
                        {/* end: location select area */}

                        {/* create order button area */}
                        {(!order || order === undefined) && (
                            < div className="row mb-6" >
                                <div className="d-flex">
                                    <button
                                        onClick={saveOrder}
                                        className="btn btn-primary btn-sm w-100">
                                        Create
                                    </button>
                                </div>
                            </div>
                        )}
                        {/* end: create order button area */}
                    </>
                )}
                {/* end: step - 2 */}


                {/* {customer && ( */}
                {order && (
                    <>

                        {/* products select area */}
                        {orderProductList.map(opItem => (
                            <OrderProduct
                                key={opItem.id}
                                name={"product_" + opItem.id}
                                //@ts-ignore
                                orderID={order.transaction_id}
                                productList={productList} />
                        ))}

                        {/* add product button */}

                        < div className="row mb-6">
                            <div className="d-flex p-0">
                                <button
                                    onClick={addNewProduct}
                                    className="btn btn-primary btn-sm w-100">
                                    Add Product
                                </button>
                            </div>
                        </div>
                        {/* end: add product button */}
                    </>
                )}

                {/* end: products select area */}


                {/* buttons */}
                {/* <div className="row mb-5 w-100 m-0" style={{ backgroundColor: "" }}>
                    <div className="col-md-3 offset-md-9 d-flex justify-content-end p-0" style={{ backgroundColor: "" }}>


                        <button
                            className="btn btn-primary btn-sm px-10"
                            // onClick={formNextStepHandler}
                            onClick={e => e.preventDefault()}
                            disabled={!nextBtnEnabled}
                            type="button">
                            Save
                        </button>

                    </div>
                </div> */}
                {/* end: buttons */}

            </form>

        </Card >
    )
}


