import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom';
import { deleteOrder, getOrders } from '../../api/orderAPI'


interface IOrderListItem {
    id: number
    index: number
    datetime: string
    email: string
    phone: string

    deleteHandler?: (e: React.FormEvent<HTMLButtonElement>, id: number) => void
}


const OrderListItem: React.FC<IOrderListItem> = ({ index, id, datetime, email, phone, deleteHandler = null }) => (
    <div className="d-flex align-items-center mt-2 p-2" style={{ backgroundColor: '', height: 40, border: '1px solid #ececec', cursor: 'pointer' }}>
        {/* sl. */}
        <div className="d-flex justify-content-end" style={{ width: 30, backgroundColor: '', marginRight: 15 }}>{index}</div>
        {/* date time */}
        <div style={{ flex: 1, backgroundColor: '', marginRight: 10 }}>{email}</div>
        {/* email */}
        <div style={{ width: 150, backgroundColor: '', marginRight: 10 }}>{phone}</div>
        {/* phone number */}
        <div style={{ width: 180, backgroundColor: '', marginRight: 10 }}>{datetime}</div>
        {/* delete button */}
        <div className="d-flex justify-content-end" style={{ width: 80, backgroundColor: '' }}>
            <button
                // onClick={e => e.preventDefault()}
                onClick={e => deleteHandler ? deleteHandler(e, id) : e.preventDefault()}
                className="btn btn-sm">
                <i className="bi bi-trash"></i>
            </button>
        </div>
    </div>
);



export default function OrderList() {

    const [orders, setOrders] = useState([])

    const fetchOrders = async (page: number) => {
        const { status, data, errorMessage } = await getOrders(page);

        if (status !== 200) {
            console.log('Error while fetching orders');
            console.log(status);
            console.log(errorMessage);
            return
        }

        setOrders(data.results)
    }


    useEffect(() => {
        fetchOrders(1)
    }, [])



    const deleteHandler = async (e: React.FormEvent<HTMLButtonElement>, id: number) => {
        e.preventDefault();

        const confirmDelete = window.confirm('Delete Order?');
        if (!confirmDelete) return;

        const { status, errorMessage } = await deleteOrder(id);

        console.log({ status, errorMessage });


        if (status === 204) fetchOrders(1);
        else if (errorMessage) alert(errorMessage);
        else alert("Something wrong happened");

    };


    return (
        <div className="card p-10" style={{}}>

            {/* list heading */}
            <div className="d-flex align-items-center mt-2 p-2" style={{ backgroundColor: '', height: 40, borderBottom: '1px solid #cecece' }}>
                <div className="d-flex justify-content-end" style={{ width: 30, backgroundColor: '', marginRight: 15 }}>#</div>
                <div style={{ flex: 1, backgroundColor: '', marginRight: 10 }}>Email</div>
                <div style={{ width: 150, backgroundColor: '', marginRight: 10 }}>Phone</div>
                <div style={{ width: 180, backgroundColor: '', marginRight: 10 }}>Date Time</div>
                <div className="d-flex justify-content-end" style={{ width: 80, backgroundColor: '' }}></div>
            </div>
            {/* end: list heading */}

            {/* list items */}
            {orders.map((order, index) => (
                <Link
                    // @ts-ignore
                    key={order.id}
                    // @ts-ignore
                    to={'/orders/' + order.id}
                    style={{color: 'inherit'}}>
                    <OrderListItem
                        // @ts-ignore
                        // key={order.id}
                        index={index + 1}
                        // @ts-ignore
                        // id={order.transaction_id}
                        id={order.id}
                        // @ts-ignore
                        email={order.email}
                        // @ts-ignore
                        phone={order.mobile}
                        // @ts-ignore
                        datetime={order.date_ordered}

                        deleteHandler={deleteHandler}
                    />
                </Link>
            ))}


            {/* end: list items */}









        </div>
    )
}
