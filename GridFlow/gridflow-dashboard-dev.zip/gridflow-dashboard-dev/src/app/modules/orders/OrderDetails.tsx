import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router'
import SelectSearch from 'react-select-search';
import { getOrderDetails, getOrderStatusList, updateOrderStatus } from '../../api/orderAPI';
import Card from '../../components/Card'
import Timeline, { ITimelineProps } from '../../components/Timeline';

/*
sample order details: 

"id": 6,
"transaction_id": "0x1187bfc445340c6d6",
"mobile": "01712345678",
"email": "dfdf@dfdf.fd",
"address": "fjdfld",
"date_ordered": "2021-10-25T18:31:39.962566",
"customer": 4,
"order_status": 2,
"location": 2

*/


interface IOrderDetails {
    id: number
    transaction_id: string
    mobile: string
    email: string
    address: string
    date_ordered: string
    customer: number
    order_status: number
    location: number
}

interface IOrderStatus {
    name: string
    value: string
}


const demoTimelineData: ITimelineProps = {
    title: "Package Delivered",
    subtitle: "Status changed 3 times",
    timelineContent: [
        {
            label: "28 Oct  3:57 PM",
            children: <div>Package <strong style={{ color: 'green' }}>Delivered</strong></div>
        },
        {
            label: "12:27 PM",
            content: "Shipping init"
        },
        {
            label: "27 Oct",
            content: "Pending"
        },

    ]
};


export default function OrderDetails() {

    // @ts-ignore
    const { orderID } = useParams()

    const [orderDetails, setOrderDetails] = useState<IOrderDetails>()
    const [orderStatusList, setOrderStatusList] = useState<IOrderStatus[]>([])
    const [selectedOrderStatus, setSelectedOrderStatus] = useState('')

    const fetchOrderDetails = async () => {
        const { data, status } = await getOrderDetails(orderID)

        console.log({ data, status });

        if (status !== 200) return;

        setOrderDetails(data)

    };


    const fetchOrderStatusList = async () => {
        const { data, status } = await getOrderStatusList(1)
        if (status !== 200) return;

        // @ts-ignore
        const preparedData = data.results.map(item => ({ name: item.status, value: item.status }))

        // setOrderStatusList(data.results)
        setOrderStatusList(preparedData)
    };


    useEffect(() => {
        console.log(orderID);
        fetchOrderDetails();
        fetchOrderStatusList()
    }, [orderID])


    useEffect(() => {
        console.log({ orderDetails, orderStatusList });
    }, [orderDetails, orderStatusList])


    const orderStatusUpdateHandler = async (e: React.FormEvent<HTMLButtonElement>) => {
        e.preventDefault();

        const { data, status } = await updateOrderStatus(orderID, selectedOrderStatus)

        // if (status !== 200) alert(`Order status update error [status: ${status}]`)
        if (status === 200) {
            // reload details
            fetchOrderDetails()
        }
    };


    return (
        <div className="row" style={{ backgroundColor: '' }}>

            {/* order status change history (timeline) */}
            <div className="col-md-6">
                <Card cardHeading="Order Status History">
                    <Timeline
                        title={demoTimelineData.title}
                        subtitle={demoTimelineData.subtitle}
                        timelineContent={demoTimelineData.timelineContent}
                    />
                </Card>
            </div>
            {/* end: order status change history (timeline) */}

            {/* order summary */}
            <div className="col-md-6">
                <Card cardHeading="Order Summary">

                    {orderDetails && (
                        <div className="row" style={{ backgroundColor: '' }}>
                            <div className="col-sm-12 pb-5 mb-5" style={{ borderBottom: '1px solid #c1c1c1' }}>
                                <p><strong>Transaction ID: </strong>{orderDetails.transaction_id}</p>
                                <p><strong>Customer Email: </strong>{orderDetails.email}</p>
                                <p><strong>Customer Address: </strong>{orderDetails.address}</p>
                                <p><strong>Customer Phone: </strong>{orderDetails.mobile}</p>
                                <p><strong>Date: </strong>{orderDetails.date_ordered}</p>
                            </div>
                        </div>
                    )}

                    <div className="row d-flex align-items-center" style={{ backgroundColor: '' }}>
                        <div className="col-md-3">
                            Update Order status
                        </div>
                        <div className="col-md-7">
                            <SelectSearch
                                options={orderStatusList}
                                value={selectedOrderStatus}
                                // @ts-ignore
                                name='status'
                                // @ts-ignore
                                onChange={v => setSelectedOrderStatus(v)}
                                placeholder='Select Status' />
                        </div>

                        <div className="col-md-2">
                            <button
                                onClick={orderStatusUpdateHandler}
                                className="btn btn-sm btn-primary w-100">
                                Save
                            </button>
                        </div>
                    </div>
                </Card>
            </div>
            {/* end: order summary */}

        </div>

    )
}
