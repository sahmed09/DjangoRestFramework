import React, { useEffect } from 'react'
import { useDispatch } from 'react-redux'
import { Redirect, Route, Switch } from 'react-router-dom'
import { PageLink, PageTitle } from '../../../_metronic/layout/core'
import { disableCreateButton, disableCreateButtonLink, enableCreateButton, enableCreateButtonLink } from '../../redux/slices/uiSlice'
import OrderForm from './components/OrderForm'
import OrderDetails from './OrderDetails'
import OrderList from './OrderList'

const productsBreadCrumbs: Array<PageLink> = [
    // Boilerplate root
    {
        title: 'Products',
        path: '/orders/overview',
        isSeparator: false,
        isActive: false,
    },

    // separator (-)
    {
        title: '',
        path: '',
        isSeparator: true,
        isActive: false,
    },
]

const OrdersPage: React.FC = () => {

    const dispatch = useDispatch();

    // ******************************* end: ORDER FORM *******************************

    // disable create button in this page
    useEffect(() => {
        dispatch(enableCreateButtonLink('/orders/add'))
        dispatch(disableCreateButton())
        return () => {
            dispatch(enableCreateButton())
            dispatch(disableCreateButtonLink())
        }
    }, []);
    // end: disable create button in this page




    return (
        <Switch>
            <Route path='/orders/overview'>
                <PageTitle breadcrumbs={productsBreadCrumbs}>Order List</PageTitle>
                <OrderList />
            </Route>

            <Route path='/orders/add'>
                <PageTitle breadcrumbs={productsBreadCrumbs}>Order List</PageTitle>
                <OrderForm />
            </Route>

            <Route path='/orders/:orderID'>
                <PageTitle breadcrumbs={productsBreadCrumbs}>Order Details</PageTitle>
                <OrderDetails />
            </Route>

            {/* redirects for this page */}
            <Redirect from='/orders' exact={true} to='/orders/overview' />
            <Redirect to='/orders/overview' />
        </Switch>
    )
}

export default OrdersPage
