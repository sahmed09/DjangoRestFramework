import clsx from 'clsx';
import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { useHistory } from 'react-router';
import { IAttribute, IAttributeValue } from '../../../../interfaces';
import { createCategory, createCategoryAttribute, createCategoryAttributeValue, updateCategory, updateCategoryAttributeName, updateCategoryAttributeValue } from '../../../api/categoryAPI';
import {
    // category
    setCategoryName, setCategorySlug, setCategorySaved,
    // category attribute name
    createNewAttribute, setCategoryAttributeName, setCategoryAttributeSlug, setCategoryAttributeNameSaved,
    // category attribute value
    createAttributeValue, setAttributeValue, setAttributeValueSlug, setAttributeValueSaved,
    // utility
    resetCategoryForm

} from '../../../redux/slices/categoryFormSlice';
import { AppState } from '../../../redux/store';

const CategoryForm: React.FC = () => {

    const dispatch = useDispatch();

    const { id, name, slug, isSaved, update, attributes } = useSelector((state: AppState) => state.categoryForm);

    // reset form state when component dismounts
    useEffect(() => {
        return () => { dispatch(resetCategoryForm()) }
    }, [])


    // category save handler
    const categorySaveHandler = async (e: React.MouseEvent<any>) => {
        e.preventDefault();

        // todo: show error message
        if (!name) {
            alert("Category name cannot be empty");
            return
        }

        // category update operation (required state/fields:: id -> category id)
        if (update && id) {
            const { status } = await updateCategory(id, name);

            // update category saved flag
            if (status === 200) dispatch(setCategorySaved());
            // todo: replace with error message
            else alert(`Something went wrong [status: ${status}]`)

            return
        }

        // create new category
        const { data, status } = await createCategory(name);

        // change state depending on status
        if (status === 201) {
            // update category saved flag
            dispatch(setCategorySaved());
            // save category slug
            dispatch(setCategorySlug(data.slug));
        }
        else {
            alert(`Something went wrong [status: ${status}]`)
        }
    };
    // end: category save handler


    // attribute name save handler
    const attributeNameSaveHandler = async (e: React.MouseEvent<any>, attribute: IAttribute) => {
        e.preventDefault();

        // todo: show error message
        if (!attribute.name) {
            alert("Attribute name cannot be empty");
            return
        }

        // check category slug
        if (!slug) {
            alert(`Invalid category slug [${slug}]`);
            return
        }

        // update operation
        if (attribute.update) {
            const { status, errorMessage } = await updateCategoryAttributeName(attribute.id, slug, attribute.name)

            if (status === 200) dispatch(setCategoryAttributeNameSaved(attribute.id))
            else if (errorMessage) alert(errorMessage)
            else alert(`Something went wrong [status: ${status}]`)

            return
        }

        // call API to save category
        const { data, status } = await createCategoryAttribute(slug, attribute.name);

        // change state depending on status
        if (status === 201) {
            // todo: update 'saved' status in redux state
            // update slug (only for create operation)
            dispatch(setCategoryAttributeSlug({ id: attribute.id, value: data.slug }))

            // set isSaved status of attribute (name)
            dispatch(setCategoryAttributeNameSaved(attribute.id))
        } else {
            // todo: show error msg
            alert(`Something went wrong [status: ${status}]`)
        }

    };
    // end: attribute name save handler


    // attribute value save handler
    const attributeValueSaveHandler = async (e: React.MouseEvent<any>, attribute: IAttribute, attributeValue: IAttributeValue) => {
        e.preventDefault();

        // todo: show error message
        if (!attributeValue.value) {
            alert("Attribute value cannot be empty");
            return
        }

        if (!attribute.slug) {
            alert(`Invalid attribute slug [${attribute.slug}]`);
            return
        }

        // attribute value update operation 
        if (attributeValue.update) {
            const { status, errorMessage } = await updateCategoryAttributeValue(attributeValue.id, attribute.slug, attributeValue.value);

            if (status === 200) {
                dispatch(setAttributeValueSaved({ attrId: attribute.id, valueId: attributeValue.id }))
            }
            else if (errorMessage) alert(errorMessage)
            else alert(`Something went wrong [HTTP status: ${status}]`)

            return
        }

        // create new category attribute value
        const { data, status } = await createCategoryAttributeValue(attribute.slug, attributeValue.value);

        if (status === 201) {
            // save status
            dispatch(setAttributeValueSlug({ attrId: attribute.id, valueId: attributeValue.id, slug: data.slug }))

            // update attribute value save flag
            dispatch(setAttributeValueSaved({ attrId: attribute.id, valueId: attributeValue.id }))

            // add new attribute value field
            dispatch(createAttributeValue({ id: attribute.id }))
        }
        else {
            alert(`Something went wrong [status: ${status}]`)
        }
    };
    // end: attribute value save handler


    const categoryNameSection = (
        <>
            {/* heading area */}
            <div className="row mb-5">
                <div className="col-md-12">
                    <h3>Create New Category</h3>
                </div>
            </div>
            {/* end: heading area */}


            {/* category name input row */}
            <div className='row mb-6 d-flex align-items-center' style={{ backgroundColor: '' }}>
                <label className='col-md-2 col-form-label required fw-bold fs-6'>Category Name</label>

                <div className='col-md-10'>
                    <div className='row' style={{ backgroundColor: '' }}>
                        <div className='col-md-10 fv-row' style={{ backgroundColor: '' }}>
                            <input
                                type='text'
                                className='form-control form-control-lg form-control-solid mb-3 mb-lg-0'
                                placeholder='Category Name'
                                value={name}
                                onChange={e => dispatch(setCategoryName(e.target.value))}
                                disabled={isSaved}
                            />
                        </div>

                        {/* inline save button */}
                        <div className='col-md-2 d-flex justify-content-end' style={{ backgroundColor: '' }}>
                            <button
                                className={clsx(
                                    'btn px-5 btn-primary',
                                    name.length === 0 && 'disabled',
                                    isSaved && 'btn-success disabled'
                                )}
                                style={{ width: 90, height: 45 }}
                                onClick={categorySaveHandler}
                            >
                                {isSaved ? "Saved" : "Save"}
                            </button>
                        </div>
                        {/* end: inline save button */}

                        {/* todo: add inline delete button */}

                    </div>
                </div>
            </div>
            {/* end: category name input row */}

        </>
    )
    // end: categoryNameSection


    // category attribute (name & value) section
    const categoryAttributeNameSection = attributes.map(attr => {
        return (
            <div className="row my-10" style={{ backgroundColor: '' }}>

                {/* attribute name input */}
                <div className="row m-0" style={{ backgroundColor: '' }}>
                    <div className="p-0" style={{ backgroundColor: '' }}>
                        <div className='row mb-6' style={{ backgroundColor: '' }}>
                            <label className='col-md-2 col-form-label required fw-bold fs-6'>Attribute Name</label>

                            <div className='col-md-10' style={{ backgroundColor: '' }}>
                                <div className='row'>
                                    <div className='col-md-10 fv-row' style={{ backgroundColor: '' }}>
                                        <input
                                            type='text'
                                            className='form-control form-control-lg form-control-solid mb-3 mb-lg-0'
                                            placeholder='Attribute Name'
                                            value={attr.name}
                                            disabled={attr.isSaved}
                                            // onChange={e => dispatch(setCategoryAttributeName({ id: attr.id, value: e.target.value }))}
                                            onChange={e => dispatch(setCategoryAttributeName({ id: attr.id, value: e.target.value ? e.target.value : "" }))}
                                        />
                                    </div>


                                    {/* inline save button */}
                                    <div className='col-md-2 d-flex justify-content-end' style={{ backgroundColor: '' }}>
                                        <button
                                            style={{ width: 90, height: 45 }}
                                            // className={clsx('btn btn-primary px-3', attr.name.length === 0 && 'disabled')}
                                            className={clsx(
                                                'btn px-5 btn-primary',
                                                attr.name.length === 0 && 'disabled',
                                                attr.isSaved && 'btn-success disabled'
                                            )}
                                            onClick={e => attributeNameSaveHandler(e, attr)}
                                        >
                                            {attr.isSaved ? "Saved" : "Save"}
                                        </button>
                                    </div>
                                    {/* end: inline save button */}

                                    {/* todo: add inline delete button */}

                                </div>
                            </div>
                        </div>

                    </div>

                </div>
                {/* end: attribute name input */}


                {/* attribute value area */}

                {/* show value field if attribute slug exists (which means attribute is saved) */}
                {attr.slug.length > 0 && attr.values.map(attrVal => {
                    return (
                        <div className="row mx-0 my-3 px-0" style={{ backgroundColor: "" }}>
                            <div className="col-sm-10 offset-sm-2">

                                {/* value input area */}
                                <div className="row" style={{ backgroundColor: "" }}>
                                    <label className='col-sm-2 col-form-label fw-bold fs-6' style={{ backgroundColor: "" }}>Value</label>
                                    <span className="col-sm-8" style={{ backgroundColor: "" }}>
                                        <input
                                            type='text'
                                            className='form-control form-control-lg form-control-solid mb-3 mb-lg-0'
                                            placeholder='Attribute Value'
                                            disabled={attrVal.isSaved}
                                            value={attrVal.value}
                                            onChange={e => dispatch(setAttributeValue({ attrId: attr.id, valueId: attrVal.id, value: e.target.value }))}
                                        />
                                    </span>

                                    <span className='col-sm-2 d-flex justify-content-end' style={{ backgroundColor: '' }}>
                                        <button
                                            style={{ width: 90, height: 45 }}
                                            className={clsx(
                                                'btn btn-primary px-3',
                                                attrVal.value.length === 0 && 'disabled',
                                                attrVal.isSaved && 'btn-success disabled'
                                            )}
                                            onClick={e => attributeValueSaveHandler(e, attr, attrVal)}
                                        >
                                            {attrVal.isSaved ? "Saved" : "Save"}
                                        </button>
                                    </span>
                                </div>
                                {/* end: value input area */}

                            </div>
                        </div>

                    )
                })}

                {/* end: attribute value area */}


                {/* add value button - only show in update operation */}
                {update && (<div className="row my-8 mx-0" style={{ backgroundColor: "" }}>
                    <div className="col-sm-2 offset-sm-10 d-flex justify-content-end p-0" style={{ backgroundColor: "" }}>
                        <button
                            style={{ width: 120, height: 45 }}
                            onClick={e => { e.preventDefault(); dispatch(createAttributeValue({ id: attr.id })) }}
                            className="btn btn-primary btn-sm px-6">
                            Add Value
                        </button>
                    </div>
                </div>)}
                {/* end: add value button */}

            </div>
        )
    })


    return (
        <div className='row' style={{ backgroundColor: '', overflowY: 'auto' }}>
            <div className="col-lg-12">
                <div className='card mb-5 mb-xl-10 p-6' style={{ backgroundColor: '' }}>

                    <form noValidate className='form'>

                        {/* category name section */}
                        {categoryNameSection}

                        {/* category attribute name section */}
                        {/* show section heading if category slug exists */}
                        {slug && <h4 className='col-md-6 col-form-label fw-bold fs-6' style={{ backgroundColor: '' }}>Category Attributes</h4>}

                        {/* show attribute value only when category slug exists (which means category is saved) */}
                        {slug && categoryAttributeNameSection}

                        {/* 'add another attribute' button */}
                        {slug && (
                            <div className="row my-8" style={{ backgroundColor: "" }}>
                                <div className="col-md-2 offset-md-10 d-flex justify-content-end" style={{ backgroundColor: "" }}>
                                    <button
                                        style={{ width: 120, height: 45 }}
                                        onClick={e => { e.preventDefault(); dispatch(createNewAttribute()) }}
                                        className="btn btn-primary btn-sm">
                                        Add Attribute
                                    </button>
                                </div>
                            </div>
                        )}
                        {/* end: 'add another attribute' button */}

                    </form>

                </div>
            </div>
        </div>
    )
}


export { CategoryForm }
