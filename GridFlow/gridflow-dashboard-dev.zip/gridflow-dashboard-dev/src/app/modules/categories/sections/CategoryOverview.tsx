import React, { useEffect } from 'react'
import Pagination from '../../../components/Pagination';
import { useDispatch, useSelector } from 'react-redux';
import ListItem from '../../../components/ListItem'
import { getCategories, setCategoryPage } from '../../../redux/slices/categorySlice';
import { AppState } from '../../../redux/store';
import { useHistory } from 'react-router';
import { deleteCategory, getCategoryWithAttributes } from '../../../api/categoryAPI';
import { replaceCategoryFormState } from '../../../redux/slices/categoryFormSlice';

export default function CategoryOverview() {

    const { categories, error, hasNext, hasPrevious, page } = useSelector((state: AppState) => state.category);
    const dispatch = useDispatch();

    const history = useHistory();

    useEffect(() => {
        console.log('Category > useEffect()');

        // if (categories.length > 0) return;

        console.log('fetching categories | page : ', page);
        dispatch(getCategories(page))

    }, [page]);

    const { search } = history.location;

    useEffect(() => {

        const queryString = new URLSearchParams(search);

        // console.log('search changed: ');
        // console.log(search);
        // console.log(queryString.get('page'));

        // const p = queryString.get('page');

        // let x;
        // if (p) {
        //     x = parseInt(p);
        //     // isNaN(parseInt(p))
        //     console.log(isNaN(parseInt(p)));
        // }

        // console.log({ p, x });

        const pageNumber = queryString.get('page');
        if (!pageNumber) return;

        const pn = parseInt(pageNumber);
        if (isNaN(pn)) return;

        dispatch(setCategoryPage(pn));

    }, [search])


    // useEffect(() => {

    //     // console.log({ history });
    //     console.log("history.location.search: ");
    //     console.log(history.location.search);

    //     if(history.location.search) console.log('has search');
    //     else console.log('does not have search');

    // }, [history])

    // if (history.location.search) console.log('has search');
    // else console.log('does not have search');


    // pagination handlers
    // todo: solve double click issue
    const previousClickHandler = (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
        e.preventDefault();

        console.log('previous clicked');

        // if (page > 1) dispatch(setCategoryPage(page - 1));

        // if (page > 1) history.push({pathname: '/dresses',search: '?color=blue'})
        // if (page > 1) history.push({ search: `?page=${page - 1}` })
        if (page > 1) {
            dispatch(setCategoryPage(page - 1));
            history.push({ search: `?page=${page - 1}` })
        }
    };

    const nextClickHandler = (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
        e.preventDefault();

        console.log('next clicked');

        dispatch(setCategoryPage(page + 1));
        history.push({ search: `?page=${page + 1}` })
    };




    const editClickHandler = async (e: React.FormEvent<HTMLButtonElement>, id: string | number) => {
        e.preventDefault();

        console.log('edit clicked : ', id);

        // fetch category details
        //@ts-ignore
        const categoryFormData = await getCategoryWithAttributes(id);


        console.log('categoryFormData : ');
        console.log(categoryFormData);

        // set category form state
        dispatch(replaceCategoryFormState(categoryFormData));


        history.push({
            pathname: "/categories/" + id + "/update",
            // state: {
            //     update: true,
            //     passedData: categories.filter(cat => cat.id === id)[0],
            // }
        });
    }


    const deleteClickHandler = async (e: React.FormEvent<HTMLButtonElement>, id: string | number) => {
        e.preventDefault();

        console.log('delete clicked : ', id);

        // todo: replace with modal
        const confirmDelete = window.confirm(`Delete category '${categories.filter(cat => cat.id === id)[0].name}'?`);
        if (!confirmDelete) return;

        const { status, errorMessage } = await deleteCategory(id);

        if (status === 204) history.push("/categories");
        // else if (errorMessage) createError(errorMessage);
        else if (status === 404) alert("Category Not Found");
        else if (errorMessage) alert(errorMessage);
        else alert("Something wrong happened");


    }





    return (
        <div className='card mb-5 mb-xl-10' style={{ backgroundColor: '' }}>

            {/* card heading */}
            <div
                className='card-header border-0'>
                <div className='card-title m-0'>
                    <h3 className='fw-bolder m-0'>Categories</h3>
                </div>
            </div>
            {/* end: card heading */}


            {/* card body */}
            <div className="card-body border-top px-9 py-5">

                {/* todo: add list heading */}

                {/* list items */}
                {categories.length > 0 && categories.map(cat => (
                    <ListItem
                        key={cat.slug}
                        id={cat.id}
                        columnOneValue={cat.name}
                        columnOneWidth="100%"
                        editButtonHandler={editClickHandler}
                        deleteButtonHandler={deleteClickHandler}
                    />
                ))}
                {error && <div className="alert alert-danger" role="alert">{error}</div>}
                {/* end: list items */}

                {/* pagination */}
                <Pagination
                    infoText="Pagination"
                    previous={hasPrevious}
                    next={hasNext}

                    previousClickHandler={previousClickHandler}
                    nextClickHandler={nextClickHandler}
                />



            </div>
            {/* end: card body */}
        </div>
    )
}
