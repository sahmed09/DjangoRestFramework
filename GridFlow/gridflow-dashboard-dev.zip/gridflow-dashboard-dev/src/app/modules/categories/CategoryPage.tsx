import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Redirect, Route, Switch } from 'react-router-dom'
import { PageLink, PageTitle } from '../../../_metronic/layout/core'
import ModalWrapper from '../../components/ModalWrapper'
import { getCategories } from '../../redux/slices/categorySlice'
import { hideModal } from '../../redux/slices/modalSlice'
import { resetCategoryForm } from '../../redux/slices/categoryFormSlice'
import { AppState } from '../../redux/store'
import { CategoryForm } from './components/CategoryForm'
import CategoryOverview from './sections/CategoryOverview'


const categoryBreadCrumbs: Array<PageLink> = [
    {
        title: 'Categories',
        path: '/categories/overview',
        isSeparator: false,
        isActive: false,
    },

    // separator (-)
    {
        title: '',
        path: '',
        isSeparator: true,
        isActive: false,
    },
]




const CategoryPage: React.FC = () => {

    const dispatch = useDispatch();

    const { visible } = useSelector((state: AppState) => state.modal)

    const { page } = useSelector((state: AppState) => state.category);

    const handleClose = () => {
        dispatch(hideModal());

        // reset category create form
        dispatch(resetCategoryForm());

        // refetch categories
        dispatch(getCategories(page))

    };



    return (
        <>
            {/* create category modal */}
            <ModalWrapper
                modalTitle="Create Category"
                handleClose={handleClose}
                show={visible}>

                <div style={{ height: 400, overflowX: 'hidden', overflowY: 'scroll' }}>
                    <CategoryForm />
                </div>

            </ModalWrapper>
            {/* end: create category modal */}


            {/* page sections (tabs) as route */}
            <Switch>
                <Route path='/categories/overview'>
                    <PageTitle breadcrumbs={categoryBreadCrumbs}>Overview</PageTitle>
                    <CategoryOverview />
                </Route>

                <Route path='/categories/add'>
                    <PageTitle breadcrumbs={categoryBreadCrumbs}>Add Category</PageTitle>
                    <CategoryForm />
                </Route>

                <Route path='/categories/:id/update'>
                    <PageTitle breadcrumbs={categoryBreadCrumbs}>Update Category</PageTitle>
                    <CategoryForm />
                </Route>

                {/* redirects for this page */}
                <Redirect from='/categories' exact={true} to='/categories/overview' />
                <Redirect to='/categories/overview' />
            </Switch>

            {/* end: page sections (tabs) as route */}
        </>
    )
}

export default CategoryPage
