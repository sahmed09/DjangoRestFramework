import React from 'react'
import { Redirect, Route, Switch } from 'react-router-dom'
import { PageLink, PageTitle } from '../../../_metronic/layout/core'
import ShopDetails from './ShopDetails/ShopDetails'
import ShopList from './ShopList'


const shopBreadCrumbs: Array<PageLink> = [
    // Boilerplate root
    {
        title: 'Shops',
        path: '/shops',
        isSeparator: false,
        isActive: false,
    },

    // separator (-)
    {
        title: '',
        path: '',
        isSeparator: true,
        isActive: false,
    },
]


const ShopsPage: React.FC = () => {

    return (
        <>
            {/* todo: add shop create modal */}

            <Switch>
                <Route exact path='/shops'>
                    <PageTitle breadcrumbs={shopBreadCrumbs}>Shop List</PageTitle>
                    <ShopList />
                </Route>

                {/* shop details page */}
                <Redirect from='/shops/:shopID' exact={true} to='/shops/:shopID/overview' />
                {/* note: don't use 'exact' here */}
                <Route path='/shops/:shopID'>
                    <PageTitle breadcrumbs={shopBreadCrumbs}>Shop Details</PageTitle>
                    <ShopDetails />
                </Route>

            </Switch>
            {/* end: page sections (tabs) as route */}

        </>
    )
}

export default ShopsPage
