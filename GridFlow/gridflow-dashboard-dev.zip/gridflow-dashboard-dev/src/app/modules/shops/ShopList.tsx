import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { Link } from 'react-router-dom';
import { deleteShop } from '../../api/shopAPI';
import Card from '../../components/Card';
import ModalWrapper from '../../components/ModalWrapper';
import { hideModal, setModalData, showModal } from '../../redux/slices/modalSlice';
import { getShops } from '../../redux/slices/shopSlice';
import { AppState } from '../../redux/store';
import ListItem from './components/ListItem';
import ShopForm from './components/ShopForm';

export default function ShopList() {

    const dispatch = useDispatch();
    const { shops, hasPrevious, hasNext, error, page } = useSelector((state: AppState) => state.shop);
    const { visible } = useSelector((state: AppState) => state.modal);


    // fetch shop list when component mounts
    useEffect(() => {
        dispatch(getShops(page))
    }, [page]);


    // modal 
    const handleClose = () => {
        // hide modal
        dispatch(hideModal());
        // refetch shop list
        dispatch(getShops(page))

    };


    // shop list item event handlers
    const shopEditHandler = async (e: React.FormEvent<HTMLButtonElement>, id: number) => {
        e.preventDefault();

        // todo: replace with modal
        const filteredShop = shops.find(item => item.id === id);

        dispatch(setModalData(filteredShop))
        dispatch(showModal())

    };


    const shopDeleteHandler = async (e: React.FormEvent<HTMLButtonElement>, id: number) => {
        e.preventDefault();

        // todo: replace with modal
        const confirmDelete = window.confirm(`Delete Product '${shops.filter(item => item.id === id)[0].name}'?`);
        // const confirmDelete = window.confirm('Delete Product?');
        if (!confirmDelete) return;

        const { status, errorMessage } = await deleteShop(id);

        // reload shop list
        if (status === 204) dispatch(getShops(page));
        else if (errorMessage) alert(errorMessage);
        else alert("Something wrong happened");

    };


    // ***** debug **********************************************

    // useEffect(() => {
    //     console.log('shops');
    //     console.log(shops);
    // }, [shops])

    // ***** end: debug *****************************************

    return (
        <>
            {/* shop create/update modal */}
            <ModalWrapper
                modalTitle="Create Shop"
                handleClose={handleClose}
                show={visible}>

                <ShopForm />

            </ModalWrapper>
            {/* end: shop create/update modal */}


            {/* shop list area */}
            <Card cardHeading="Shop List">

                {/* list item */}
                {shops.map(shop => (
                    <Link
                        key={shop.id}
                        to={"/shops/" + shop.id}
                        style={{ color: "inherit" }}>

                        <ListItem
                            id={shop.id}
                            name={shop.name}

                            editHandler={shopEditHandler}
                            deleteHandler={shopDeleteHandler} />

                    </Link>
                ))}
                {/* end: list item */}

                {/* todo: add pagination */}

            </Card>
        </>
    )
}
