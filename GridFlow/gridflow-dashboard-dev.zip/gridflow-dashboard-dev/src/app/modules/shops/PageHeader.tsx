/* eslint-disable jsx-a11y/anchor-is-valid */
import React from 'react'
import { Link } from 'react-router-dom'
import { useLocation } from 'react-router-dom'
import clsx from 'clsx'

export interface IHeaderTab {
    path: string
    title: string
    visible?: boolean
    matchPattern?: boolean
}


export interface IShopPageHeader {
    sections: IHeaderTab[]
}

const PageHeader: React.FC<IShopPageHeader> = ({ sections }) => {
    const location = useLocation()

    return (
        <div className='card mb-5 mb-xl-10'>
            <div className='card-body pt-5 pb-0'>

                {/* page section tabs */}
                <div className='d-flex overflow-auto h-55px'>
                    <ul className='nav nav-stretch nav-line-tabs nav-line-tabs-2x border-transparent fs-5 fw-bolder flex-nowrap'>

                        {/* render page sections (tabs) */}
                        {sections.map(section => (
                            <li className='nav-item'>
                                <Link
                                    className={`nav-link text-active-primary me-6 ` + (location.pathname === section.path && 'active')}
                                    // className={clsx(`nav-link text-active-primary me-6 `, (location.pathname === section.path && 'active', section.matchPattern && location.pathname.match(section.path) && 'active'))}
                                    to={section.path}>
                                    {section.title}
                                </Link>
                            </li>
                        ))}

                    </ul>
                </div>
                {/* end: page section tabs */}
            </div>
        </div>
    )
}

export { PageHeader }
