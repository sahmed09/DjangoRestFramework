import React from 'react'
import { Link, useLocation } from 'react-router-dom';

interface IShopListItemProps {
    isChecked?: boolean
    id: number
    name: string
    // todo: convert to number
    price: string

    // controls
    showEditButton?: boolean
    showDeleteButton?: boolean

    // button/checkbox click handlers
    checkHandler?: (e: React.FormEvent<HTMLButtonElement>, id: number) => void
    editHandler?: (e: React.FormEvent<HTMLButtonElement>, id: number) => void
    deleteHandler?: (e: React.FormEvent<HTMLButtonElement>, id: number) => void
}


export const ProductListHeading: React.FC = () => {
    return (
        <div className="row p-2" style={{ backgroundColor: '', borderBottom: '1px solid #cfcfcf', height: 50 }}>
            <div className="d-flex align-items-center h-100 p-0" style={{ backgroundColor: '' }}>

                {/* todo: add checkbox to select all items */}
                <div style={{ width: 30, backgroundColor: '', marginRight: 10 }}>
                </div>

                <div
                    style={{ flex: 1, backgroundColor: '', marginRight: 10 }}>
                    Product Name
                </div>

                <div
                    className="d-flex justify-content-end"
                    style={{ width: 100, backgroundColor: '', marginRight: 10 }}>
                    Price
                </div>

                <div
                    className="d-flex justify-content-end"
                    style={{ width: 185, backgroundColor: '' }}>
                </div>

            </div>
        </div>
    );
};

const ProductListItem: React.FC<IShopListItemProps> = ({ id, name, price, showEditButton = true, showDeleteButton = true, checkHandler = null, editHandler = null, deleteHandler = null }) => {
    const location = useLocation()
    
    return (
        <div className="row border-bottom /*border-dark*/ cursor-pointer mt-2 p-2" style={{ backgroundColor: '', height: 50 }}>
            <div className="d-flex align-items-center h-100 p-0" style={{ backgroundColor: '' }}>
                {/* checkbox */}
                <div style={{ width: 30, backgroundColor: '', marginRight: 10 }}>
                    <input className="form-check-input" type="checkbox" />
                </div>

                {/* name */}
                <div style={{ flex: 1, backgroundColor: '', marginRight: 10 }}>{name}</div>

                {/* price */}
                <div className="d-flex justify-content-end" style={{ width: 100, backgroundColor: '', marginRight: 10 }}>{price}</div>


                {/* control buttons */}
                {/* <div className="d-flex justify-content-end" style={{ width: 85, backgroundColor: '' }}> */}
                <div className="d-flex justify-content-end" style={{ width: 185, backgroundColor: '' }}>

                    {/* stock alert page link */}
                    <Link
                        // todo: remove hardcoded values
                        to={`${location.pathname}/${id}/stockalerts`}
                        className="btn btn-outline-primary btn-sm me-2 px-3"
                        style={{ backgroundColor: '', width: 100 }}>
                        Stock Alerts
                    </Link>


                    {/* edit button */}
                    {showEditButton && (<button
                        onClick={e => editHandler ? editHandler(e, id) : e.preventDefault()}
                        className="btn btn-sm me-2 px-3"
                        style={{ backgroundColor: '' }}>
                        < i className="bi bi-pencil"></i>
                    </button>)}

                    {/* delete button */}
                    {showDeleteButton && (<button
                        onClick={e => deleteHandler ? deleteHandler(e, id) : e.preventDefault()}
                        className="btn btn-sm px-3"
                        style={{ backgroundColor: '' }}>
                        < i className="bi bi-trash"></i>
                    </button>)}

                </div>
                {/* end: control buttons */}

            </div>
        </div>
    )
};

export default ProductListItem;