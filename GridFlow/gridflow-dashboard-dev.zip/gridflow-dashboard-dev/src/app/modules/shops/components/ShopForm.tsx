import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { createShop, updateShop } from '../../../api/shopAPI';
import { hideModal, resetModal } from '../../../redux/slices/modalSlice';
import { getShops } from '../../../redux/slices/shopSlice';
import { AppState } from '../../../redux/store';

const ShopForm: React.FC = () => {
    const dispatch = useDispatch();
    const { page } = useSelector((state: AppState) => state.shop);
    const { visible, modalData } = useSelector((state: AppState) => state.modal);

    // form data
    const [shopName, setShopName] = useState("");

    const resetForm = () => {
        setShopName('');
    };

    useEffect(() => {
        if (!visible) resetForm()
    }, [visible])


    // for update operation, populate form fields with existing values
    useEffect(() => {
        if (!modalData) return;
        setShopName(modalData.name);
    }, [])


    // event handlers
    const formSaveHandler = async (e: React.FormEvent<any>) => {
        e.preventDefault();

        // todo: implement update operation
        if (modalData) {
            const { status, errorMessage } = await updateShop(modalData.id, shopName);

            if (status === 200) {
                // reset modal data & state
                dispatch(resetModal())
                // reset form data
                resetForm()
                // reload brands
                dispatch(getShops(page))
            }
            else if (errorMessage) alert(errorMessage);
            else alert(`[update] Something wrong happened [status: ${status}]`);

            return
        }

        // create operation
        const { status, errorMessage } = await createShop(shopName);
        if (status === 201) {
            // dispatch(hideModal())
            dispatch(resetModal())
            // reset form data
            resetForm()
            // reload shop list
            dispatch(getShops(page));
        }
        // todo: show error message
        else if (errorMessage) alert(errorMessage);
        else alert(`[create] Something wrong happened [status: ${status}]`);
    };


    return (
        <div className='row' style={{ backgroundColor: '' }}>
            <div className="col-lg-12">
                <div className='card mb-5 mb-xl-10' style={{ backgroundColor: '' }}>

                    {/* card body */}
                    <div className='row' style={{ backgroundColor: '' }}>
                        <form
                            onSubmit={formSaveHandler}
                            noValidate className='form'>

                            <div className='card-body border-top p-9' style={{ backgroundColor: '' }}>

                                {/* shop name input area */}
                                <div className='row mb-6'>
                                    <label className='col-lg-2 col-form-label required fw-bold fs-6'>Shop Name</label>
                                    <div className='col-lg-10'>
                                        <div className='row'>
                                            <div className='col-lg-12 fv-row'>
                                                <input
                                                    type='text'
                                                    className='form-control form-control-lg form-control-solid mb-3 mb-lg-0'
                                                    placeholder='Shop Name'
                                                    value={shopName}
                                                    autoFocus
                                                    onChange={e => setShopName(e.target.value)}
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                {/* end: shop name input area */}

                                {/* todo: show error message */}

                                {/* submit button */}
                                <div className="row m-0 mt-10 border-top pt-9" style={{ backgroundColor: '' }}>
                                    <div className='col-sm-2 offset-sm-10' style={{ backgroundColor: '' }}>
                                        <button
                                            className='btn btn-sm btn-primary me-3 px-12'
                                            disabled={shopName.length === 0}
                                            type="submit">
                                            Save
                                        </button>
                                    </div>
                                </div>
                                {/* end: submit button */}
                            </div>

                        </form>
                    </div>
                    {/* end: card body */}

                </div>
            </div>

        </div>
    )
}


export default ShopForm
