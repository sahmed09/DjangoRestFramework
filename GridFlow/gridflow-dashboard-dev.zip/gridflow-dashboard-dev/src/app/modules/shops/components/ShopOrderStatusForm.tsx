import React, { useState } from 'react'
import { useDispatch } from 'react-redux';
import { IShop } from '../../../../interfaces';
import { createOrderStatus, createShopOrderStatus } from '../../../api/orderStatusAPI';
import { hideModal } from '../../../redux/slices/modalSlice';
import { getShopStatusList } from '../../../redux/slices/shopOrderStatusSlice';

interface IOrderStatusFormProps {
    shop: IShop
}

export const ShopOrderStatusForm: React.FC<IOrderStatusFormProps> = ({ shop }) => {

    const dispatch = useDispatch()

    const [statusName, setStatusName] = useState('')
    const [statusMessage, setStatusMessage] = useState('')


    const formSubmitHandler = async (e: React.FormEvent<any>) => {
        e.preventDefault();

        if (statusName === '' || statusMessage === '') return;
        // if (statusName === '') return;
        if (!shop.slug) return;

        const { data, status } = await createOrderStatus(shop.slug, statusName);

        console.log('createOrderStatus: ');

        console.log({ data, status });


        if (status === 201) {
            // create shop order status msg
            const { data: msgData, status: msgStatus } = await createShopOrderStatus(statusName, statusMessage)

            console.log({ msgData, msgStatus });


            if (msgStatus === 201) {
                // hide modal
                dispatch(hideModal());

                // reload order status list
                dispatch(getShopStatusList({ slug: shop.slug }))
            }

        }
    };


    return (
        <form
            onSubmit={formSubmitHandler}
            noValidate className='form'>

            <div className='card-body border-top p-9' style={{ backgroundColor: '' }}>

                {/* shop order status name input area */}
                <div className='row mb-6'>
                    <label className='col-lg-2 col-form-label required fw-bold fs-6'>Status</label>
                    <div className='col-lg-10'>
                        <div className='row'>
                            <div className='col-lg-12 fv-row'>
                                <input
                                    type='text'
                                    className='form-control form-control-lg form-control-solid mb-3 mb-lg-0'
                                    placeholder='Status Name'
                                    value={statusName}
                                    autoFocus
                                    onChange={e => setStatusName(e.target.value)}
                                />
                            </div>
                        </div>
                    </div>
                </div>
                {/* end: shop order status name input area */}

                {/* shop order status message input area */}
                <div className='row mb-6'>
                    <label className='col-lg-2 col-form-label required fw-bold fs-6'>Message</label>
                    <div className='col-lg-10'>
                        <div className='row'>
                            <div className='col-lg-12 fv-row'>
                                <input
                                    type='text'
                                    className='form-control form-control-lg form-control-solid mb-3 mb-lg-0'
                                    placeholder='Status Message'
                                    value={statusMessage}
                                    autoFocus
                                    onChange={e => setStatusMessage(e.target.value)}
                                />
                            </div>
                        </div>
                    </div>
                </div>
                {/* end: shop order status message input area */}

                {/* todo: show error message */}

                {/* submit button */}
                <div className="row m-0 mt-10 border-top pt-9" style={{ backgroundColor: '' }}>
                    <div className='col-sm-2 offset-sm-10' style={{ backgroundColor: '' }}>
                        <button
                            className='btn btn-sm btn-primary me-3 px-12'
                            // disabled={shopName.length === 0}
                            type="submit">
                            Save
                        </button>
                    </div>
                </div>
                {/* end: submit button */}
            </div>

        </form>
    )
}
