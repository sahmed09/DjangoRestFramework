import React from 'react'

interface IShopListItemProps {
    isChecked?: boolean
    id: number
    name: string

    // button/checkbox click handlers
    checkHandler?: (e: React.FormEvent<HTMLButtonElement>, id: number) => void
    editHandler?: (e: React.FormEvent<HTMLButtonElement>, id: number) => void
    deleteHandler?: (e: React.FormEvent<HTMLButtonElement>, id: number) => void
}

const ListItem: React.FC<IShopListItemProps> = ({ id, name, checkHandler = null, editHandler = null, deleteHandler = null }) => {
    return (
        <div className="row border-bottom /*border-dark*/ cursor-pointer mt-2 p-2" style={{ backgroundColor: '', height: 50 }}>
            <div className="d-flex align-items-center h-100 p-0" style={{ backgroundColor: '' }}>
                {/* checkbox */}
                <div style={{ width: 30, backgroundColor: '', marginRight: 10 }}>
                    <input className="form-check-input" type="checkbox" />
                </div>

                {/* shop name */}
                <div style={{ flex: 1, backgroundColor: '', marginRight: 10 }}>{name}</div>

                {/* control buttons */}
                <div className="d-flex justify-content-end" style={{ width: 85, backgroundColor: '' }}>

                    {/* edit button */}
                    <button
                        onClick={e => editHandler ? editHandler(e, id) : e.preventDefault()}
                        className="btn btn-sm me-2 px-3"
                        style={{ backgroundColor: '' }}>
                        < i className="bi bi-pencil"></i>
                    </button>

                    {/* delete button */}
                    <button
                        onClick={e => deleteHandler ? deleteHandler(e, id) : e.preventDefault()}
                        className="btn btn-sm px-3"
                        style={{ backgroundColor: '' }}>
                        < i className="bi bi-trash"></i>
                    </button>

                </div>
                {/* end: control buttons */}

            </div>
        </div>
    )
};

export default ListItem;