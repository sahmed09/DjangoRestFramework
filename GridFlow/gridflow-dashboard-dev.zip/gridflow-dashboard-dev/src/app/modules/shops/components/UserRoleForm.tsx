import React, { useEffect, useState } from 'react'
import { useDispatch } from 'react-redux';
import SelectSearch from 'react-select-search';
import { setShopUserRole } from '../../../api/shopUserRoleAPI';
import { hideModal } from '../../../redux/slices/modalSlice';
import { getShopUsers } from '../../../redux/slices/userRoleSlice';


interface IUserRoleFormProps {
    shopSlug: string
}

const UserRoleForm: React.FC<IUserRoleFormProps> = ({ shopSlug }) => {

    const dispatch = useDispatch();

    const [selectedRole, setSelectedRole] = useState('')
    const [selectedUser, setSelectedUser] = useState('')

    const formSaveHandler = async (e: React.FormEvent<any>) => {
        e.preventDefault()

        // todo: remove hardcoded username
        // const { data, status } = await setShopUserRole('admin', shopSlug, selectedRole);
        const { data, status } = await setShopUserRole(selectedUser, shopSlug, selectedRole);

        console.log({ data, status });

        if (status === 201) {
            dispatch(hideModal())
            dispatch(getShopUsers({ shopSlug, page: 1 }))
        }
        else {
            console.log('User Role Error');

        }


    };

    useEffect(() => {
        console.log("shopSlug ::: ");
        console.log(shopSlug);

    }, [])


    // todo: replace with actual user list
    const demoUserOptions = [
        { name: 'Admin', value: 'admin' },
        { name: 'Sakib', value: 'Sakib' },
        { name: 'Jahid', value: 'Jahid' },
    ]

    const roleOptions = [
        { name: 'Shop Owner', value: 'SO' },
        { name: 'Delivery Agent', value: 'DA' },
        { name: 'Customer', value: 'C' },
    ]



    return (
        <form
            onSubmit={formSaveHandler}
            noValidate className='form'>

            <div className='row mb-6' style={{ backgroundColor: '' }}>
                <label className='col-md-2 col-form-label required fw-bold fs-6' style={{ backgroundColor: '' }}>User</label>
                <div className='col-md-10'>
                    <div className='row'>
                        <div className='col-md-12 fv-row'>
                            <SelectSearch
                                options={demoUserOptions}
                                value={selectedUser}
                                // @ts-ignore
                                name='user'
                                // @ts-ignore
                                onChange={v => setSelectedUser(v)}
                                placeholder='Select User' />
                        </div>
                    </div>
                </div>
            </div>


            <div className='row mb-6' style={{ backgroundColor: '' }}>
                <label className='col-md-2 col-form-label required fw-bold fs-6' style={{ backgroundColor: '' }}>Role</label>
                <div className='col-md-10'>
                    <div className='row'>
                        <div className='col-md-12 fv-row'>
                            <SelectSearch
                                options={roleOptions}
                                value={selectedRole}
                                // @ts-ignore
                                name='role'
                                // @ts-ignore
                                onChange={v => setSelectedRole(v)}
                                placeholder='Select Role' />
                        </div>
                    </div>
                </div>
            </div>


            {/* submit button */}
            <div className="row m-0 mt-10 border-top pt-9" style={{ backgroundColor: '' }}>
                <div className='col-sm-2 offset-sm-10 d-flex justify-content-end p-0' style={{ backgroundColor: '' }}>
                    <button
                        className='btn btn-sm btn-primary px-12'
                        disabled={selectedUser === "" || selectedRole === ""}
                        type="submit">
                        Save
                    </button>
                </div>
            </div>
            {/* end: submit button */}


        </form>
    )
}

export default UserRoleForm
