import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router';
import { Link } from 'react-router-dom';
import { IShop, IShopBranch, IShopBranchProduct } from '../../../../interfaces';
import { getShop } from '../../../api/shopAPI';
import { getShopBranch, getShopProducts } from '../../../api/shopBranchAPI';
import Card from "../../../components/Card";
import ModalWrapper from '../../../components/ModalWrapper';
import { hideModal } from '../../../redux/slices/modalSlice';
import { disableCreateButton, enableCreateButton } from '../../../redux/slices/uiSlice';
import { AppState } from '../../../redux/store';
import ProductEnlistForm from './ProductEnlistForm';
import ProductListItem, { ProductListHeading } from './ProductListItem';
import ProductStockForm from './ProductStockForm';

export default function ProductList() {
    const dispatch = useDispatch();

    //@ts-ignore
    const { shopID, branchID } = useParams();

    const [productList, setProductList] = useState<IShopBranchProduct[]>([]);

    const [shop, setShop] = useState<IShop>();
    const [shopBranch, setShopBranch] = useState<IShopBranch>();

    const fetchShop = async (shopID: number) => {
        // const {data: shopData, status: shopStatus, errorMessage: shopErrorMsg} = getShop(shopID);
        const { data, status, errorMessage } = await getShop(shopID);

        if (status !== 200) {
            alert(`[fetchShop] Something went wrong : [status: ${status}]`)
            return
        }

        setShop(data)
    };

    const fetchShopBranch = async (branchID: number) => {
        // const {data: shopData, status: shopStatus, errorMessage: shopErrorMsg} = getShop(shopID);
        const { data, status, errorMessage } = await getShopBranch(branchID);

        if (status !== 200) {
            alert(`[fetchShopBranch] Something went wrong : [status: ${status}]`)
            return
        }

        setShopBranch(data)
    };


    const fetchProductList = async () => {
        if (!shop) return;

        const { data, status } = await getShopProducts(shop.slug, shopBranch ? shopBranch.slug : null)

        if (status !== 200) {
            alert(`[fetchProductList] Something went wrong : [status: ${status}]`)
            return
        }

        setProductList(data.results);
    };

    // fetch shop & branch when component mounts
    useEffect(() => {
        fetchShop(shopID)
        if (branchID !== undefined) fetchShopBranch(branchID)
    }, [])


    // fetch product list when shop and shopBranch exists
    useEffect(() => {
        fetchProductList();
    }, [shop, shopBranch])

    // ***** debug ****************************


    // ***** end: debug ***********************

    // list item event handlers
    const productDeleteHandler = async (e: React.FormEvent<HTMLButtonElement>, id: number) => {
        e.preventDefault();

        console.log("deleting shop product with id : " + id)
        alert("deleting shop product with id : " + id)
    };





    useEffect(() => {
        // disable create button for update operation
        dispatch(disableCreateButton())

        // enable create button again when component dismounts
        return () => { dispatch(enableCreateButton()) }
    }, []);



    // ***** stock update modal *******************

    const [stockModalVisible, setStockModalVisible] = useState(false)
    const [stockModalData, setStockModalData] = useState<IShopBranchProduct>();


    const handleProductClick = (e: React.MouseEvent<HTMLDivElement, MouseEvent>, product: IShopBranchProduct) => {
        e.preventDefault()

        console.log(">> product :: ");
        console.log(product);

        setStockModalData(product);
        setStockModalVisible(true)

    };
    // ***** end: stock update modal **************


    return (
        <>
            {/* add product to shop/branch modal */}
            {/* <ModalWrapper
                modalWidth="mw-700px"
                modalTitle="Add Product to Shop"
                handleClose={handleClose}
                show={visible}>

                <div style={{ height: 300 }}>
                    <ProductEnlistForm />
                </div>

            </ModalWrapper> */}

            {/* {stockModalData && (<ModalWrapper
                modalWidth="mw-700px"
                modalTitle="Update Product Stock"
                handleClose={() => setStockModalVisible(false)}
                show={stockModalVisible}>

                <div style={{ height: 380 }}>
                    <div style={{ height: '100%', overflowX: 'hidden', overflowY: 'auto' }}>
                        <ProductStockForm product={stockModalData} />
                    </div>
                </div>

            </ModalWrapper>)} */}



            <Card>

                {/* list heading */}
                <ProductListHeading />

                {productList.map((item, i) => (
                    // <div
                    //     onClick={e => handleProductClick(e, item)}
                    //     key={item.id}
                    // >
                    <Link
                        style={{ color: 'inherit' }}
                        to={`/shops/${shopID}/products/${item.id}`}>
                        <ProductListItem
                            // key={item.id}
                            id={item.id}
                            name={item.product.name}
                            price={item.price}

                            showEditButton={false}

                            deleteHandler={productDeleteHandler}
                        />
                    </Link>
                    // </div>
                ))}


            </Card>
        </>
    )
}
