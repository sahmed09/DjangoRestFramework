import React, { useEffect, useState } from 'react';
import Select from 'react-dropdown-select';
import SelectSearch from 'react-select-search';
import { IShopBranchProduct } from '../../../../interfaces';
import { getShops } from '../../../api/shopAPI';
import { getShopBranches } from '../../../api/shopBranchAPI';
import Card from "../../../components/Card";

export default function ProductEnlistForm() {

    // form state
    // const [shopList, setShopList] = useState<IShop[]>();
    const [shopList, setShopList] = useState([]);
    // const [shop, setShop] = useState<IShop>();
    const [shop, setShop] = useState();
    // selected shop slug
    const [selectedShop, setSelectedShop] = useState('');

    // const [branchList, setBranchList] = useState<IShopBranch[]>();
    const [branchList, setBranchList] = useState([]);
    // const [branch, setBranch] = useState<IShopBranch>();
    const [branch, setBranch] = useState();
    // selected branch slug
    const [selectedBranch, setSelectedBranch] = useState('');

    // fetched product list
    // const [productList, setProductList] = useState([]);
    const [productList, setProductList] = useState<IShopBranchProduct[]>([]);



    // utility functions

    // get all shop list (page 1) to display shop select dropdown options
    const getShopList = async () => {
        // todo: handle pagination
        const { data, status } = await getShops(1);
        // if (status === 200) setShopList(data.results);
        if (status === 200) {
            // @ts-ignore
            const preparedData = data.results.map(item => ({ name: item.name, value: item.slug }))
            setShopList(preparedData);

            // reset selected shop branch
            setSelectedBranch('')
        }
    };


    // get all branch list (page 1) of a specific shop (filter by slug)
    const getShopBranchList = async (shopSlug: string) => {
        // todo: handle pagination
        const { data, status } = await getShopBranches(shopSlug);
        // if (status === 200) setBranchList(data.results);
        if (status === 200) {
            // @ts-ignore
            const preparedData = data.results.map(item => ({ name: item.name, value: item.slug }))
            setBranchList(preparedData);
        }
    };


    // get product list of a specific shop (& branch if not null) (filter by shop slug, branch slug [nullable])
    const getProductList = async (shopSlug: string, branchSlug: string | null = null) => {
        //@ts-ignore
        // const { data, status } = await getShopProducts(shop.slug, branch.slug)
        const { data, status } = await getShopProducts(shopSlug, branchSlug)

        console.log({ data, status });


        if (status !== 200) {
            alert(`Something went wrong [status: ${status}]`);
            return
        }

        if (data.results) setProductList(data.results);
        else alert("data.results undefined")
    };


    // get shop and branch list when page loads
    useEffect(() => {
        getShopList();
    }, [])

    // get shop branch list when shop is selected
    useEffect(() => {
        // if (!shop) return
        if (!selectedShop) return

        // reset branch list
        setBranchList([]);
        // reset product list
        setProductList([]);


        //@ts-ignore
        // getShopBranchList(shop.slug);
        getShopBranchList(selectedShop);

        // get shop products
        //@ts-ignore
        // getProductList(shop.slug);
    }, [selectedShop])

    // fetch product list if shop and branch both exists
    useEffect(() => {
        if (!shop || !branch) return;
        //@ts-ignore
        if (!shop.slug || !branch.slug) return
        //@ts-ignore
        // getProductList();
        // getProductList(shop.slug, branch?.slug ? branch.slug : null);
        getProductList(shop.slug, branch.slug);
    }, [branch])


    // ***** debug *******************************
    useEffect(() => {
        console.log(selectedShop);
    }, [selectedShop])

    useEffect(() => {
        console.log(branchList);
    }, [branchList])

    useEffect(() => {
        console.log(selectedBranch);
    }, [selectedBranch])
    // ***** end: debug **************************





    // event handlers

    const handleShopSelectOnChange = (value: string) => {
        setSelectedShop(value);
    };

    const handleBranchSelectOnChange = (value: string) => {
        setSelectedBranch(value);
    };


    const formSaveHandler = async (e: React.FormEvent<any>) => {
        e.preventDefault();

        console.log('submitted');

    };
    return (
        <Card>

            <form
                onSubmit={formSaveHandler}
                noValidate
                className='form d-flex flex-column'>

                <div className="row mb-5 py-5" style={{ flex: 1, backgroundColor: '' }}>
                    <div className="col-sm-12" style={{ backgroundColor: "" }}>
                        <label htmlFor="brand" className='col-lg-2 col-form-label required fw-bold fs-6'>Shop</label>

                        {/* <div className='col-lg-8' style={{ backgroundColor: "lavender" }}> */}
                        <div className='row'>
                            <div className='col-lg-12'>

                                {shopList.length > 0 && (
                                    <SelectSearch
                                        //@ts-ignore
                                        // getOptions={handleBrandSelectSearch}
                                        options={shopList}
                                        value={selectedShop}
                                        // @ts-ignore
                                        onChange={handleShopSelectOnChange}
                                        search={true}
                                        //@ts-ignore
                                        name="shop"
                                        placeholder="Choose Shop" />
                                )}

                            </div>
                        </div>
                        {/* </div> */}

                    </div>

                    <div className="col-sm-12" style={{ backgroundColor: "" }}>
                        <label htmlFor="brand" className='col-lg-2 col-form-label required fw-bold fs-6'>Branch</label>

                        {/* <div className='col-lg-8'> */}
                        <div className='row'>
                            <div className='col-lg-12'>

                                {branchList.length > 0 && (
                                    <SelectSearch
                                        //@ts-ignore
                                        // getOptions={handleBrandSelectSearch}
                                        options={branchList}
                                        value={selectedBranch}
                                        // @ts-ignore
                                        onChange={handleBranchSelectOnChange}
                                        search={true}
                                        //@ts-ignore
                                        name="branch"
                                        placeholder="Choose Branch" />
                                )}

                            </div>
                        </div>
                        {/* </div> */}

                    </div>

                    {/* todo: add filter button */}

                </div>
                {/* end: shop & branch select area */}

                {/* form button area */}
                {/* end: form button area */}

                <div className="row d-flex justify-content-end" style={{ backgroundColor: '' }}>

                    <button
                        className="btn btn-primary btn-sm"
                        type="submit">
                        Save
                    </button>

                </div>

            </form>


        </Card >
    )
}
