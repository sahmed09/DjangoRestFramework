import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { IShop } from '../../../../interfaces'
import { createProductStockAlert, updateProductStockAlert } from '../../../api/stockAlertAPI'
import { hideModal } from '../../../redux/slices/modalSlice'
import { getStockAlertList } from '../../../redux/slices/productStockAlertSlice'
import { AppState } from '../../../redux/store'
import { IShopBranchProductDetails } from './ProductStockForm'


interface IShopBranch {
    id: number
    name: string
    slug: string
    shop: number
    album?: number
}

interface IStockFormProps {
    product: IShopBranchProductDetails,
    shop: IShop,
    branch?: IShopBranch
}

const StockAlertForm: React.FC<IStockFormProps> = ({ product, shop, branch = null }) => {

    const dispatch = useDispatch()
    const { visible, modalData } = useSelector((state: AppState) => state.modal)

    // form input state
    const [name, setName] = useState('')
    const [description, setDescription] = useState('')
    const [above, setAbove] = useState('')
    const [below, setBelow] = useState('')

    const [aboveInt, setAboveInt] = useState(parseInt(above))
    const [belowInt, setBelowInt] = useState(parseInt(below))


    useEffect(() => {
        setAboveInt(parseInt(above))
    }, [above])

    useEffect(() => {
        setBelowInt(parseInt(below))
    }, [below])


    const [submitButtonEnabled, setSubmitButtonEnabled] = useState(false)


    // populate fields if modal data exists
    useEffect(() => {
        if (!modalData) return;
        // console.log(modalData)

        setName(modalData.name);
        setDescription(modalData.description)
        setAbove(modalData.stockAbove)
        setBelow(modalData.stockBelow)
    }, [])

    useEffect(() => {
        // if (name === "" || description === "" || above === "" || below === "" || isNaN(aboveInt) || isNaN(belowInt) || belowInt > aboveInt) {
        if (name === "" || description === "" || above === "" || below === "") {
            setSubmitButtonEnabled(false)
            return
        }

        if (!shop.slug || !product.product.slug) {
            setSubmitButtonEnabled(false)
            return
        }

        setSubmitButtonEnabled(true)

    }, [name, description, above, below])



    const formSaveHandler = async (e: React.FormEvent<any>) => {
        e.preventDefault();


        //update operation 
        if (modalData) {
            const { data, status } = await updateProductStockAlert(
                modalData.id,
                name,
                description,
                product.product.slug,
                aboveInt,
                belowInt,
                shop.slug,
                branch?.slug ? branch.slug : null
            )

            // console.log({ data, status })

            if (status === 200) {
                dispatch(hideModal());

                //reload alerts 
                dispatch(getStockAlertList({ productSlug: product.product.slug, shopSlug: shop.slug }))
            }
            else alert(`Error creating alert [status: ${status}]`)

            return
        }
        // create operation

        // const { data, status } = await createProductStockAlert(name, description, product.product.slug, aboveInt, belowInt, shop.slug)
        const { data, status } = await createProductStockAlert(
            name,
            description,
            product.product.slug,
            aboveInt,
            belowInt,
            shop.slug,
            branch?.slug ? branch.slug : null
        )

        // console.log({ data, status })

        if (status === 201) {
            dispatch(hideModal());

            //reload alerts 
            dispatch(getStockAlertList({ productSlug: product.product.slug, shopSlug: shop.slug }))
        }
        else alert(`Error creating alert [status: ${status}]`)
    }


    return (
        <form
            onSubmit={formSaveHandler}
            noValidate className='form'>

            {/* name input area */}
            <div className='row mb-6' style={{ backgroundColor: '' }}>
                <label className='col-md-2 col-form-label required fw-bold fs-6' style={{ backgroundColor: '' }}>Name</label>
                <div className='col-md-10'>
                    <div className='row'>
                        <div className='col-md-12 fv-row'>
                            <input
                                type='text'
                                className='form-control form-control-md form-control-solid mb-3 mb-lg-0'
                                placeholder='Alert Name'
                                value={name}
                                autoFocus
                                onChange={e => setName(e.target.value)}
                            />
                        </div>
                    </div>
                </div>
            </div>
            {/* end: name input area */}

            {/* description area */}
            <div className='row mb-6' style={{ backgroundColor: '' }}>
                <label className='col-md-2 col-form-label required fw-bold fs-6' style={{ backgroundColor: '' }}>Description</label>
                <div className='col-md-10'>
                    <div className='row'>
                        <div className='col-md-12 fv-row'>
                            <input
                                type='text'
                                className='form-control form-control-md form-control-solid mb-3 mb-lg-0'
                                placeholder='Alert Description'
                                value={description}
                                autoFocus
                                onChange={e => setDescription(e.target.value)}
                            />
                        </div>
                    </div>
                </div>
            </div>
            {/* end: description area */}


            {/* above area */}
            <div className='row mb-6' style={{ backgroundColor: '' }}>
                <label className='col-md-2 col-form-label required fw-bold fs-6' style={{ backgroundColor: '' }}>Stock Above</label>
                <div className='col-md-10'>
                    <div className='row'>
                        <div className='col-md-12 fv-row'>
                            <input
                                type='number'
                                min={0}
                                className='form-control form-control-md form-control-solid mb-3 mb-lg-0'
                                placeholder='Stock Above Value'
                                value={above}
                                autoFocus
                                onChange={e => setAbove(e.target.value)}
                            />
                        </div>
                    </div>
                </div>
            </div>
            {/* end: above area */}


            {/* below area */}
            <div className='row mb-6' style={{ backgroundColor: '' }}>
                <label className='col-md-2 col-form-label required fw-bold fs-6' style={{ backgroundColor: '' }}>Stock Below</label>
                <div className='col-md-10'>
                    <div className='row'>
                        <div className='col-md-12 fv-row'>
                            <input
                                type='number'
                                min={0}
                                className='form-control form-control-md form-control-solid mb-3 mb-lg-0'
                                placeholder='Stock Below Value'
                                value={below}
                                autoFocus
                                onChange={e => setBelow(e.target.value)}
                            />
                        </div>
                    </div>
                </div>
            </div>
            {/* end: below area */}





            {/* submit button */}
            <div className="row m-0 mt-10 border-top pt-9" style={{ backgroundColor: '' }}>
                <div className='col-sm-2 offset-sm-10 d-flex justify-content-end p-0' style={{ backgroundColor: '' }}>
                    <button
                        className='btn btn-sm btn-primary px-12'
                        disabled={!submitButtonEnabled}
                        type="submit">
                        Save
                    </button>
                </div>
            </div>
            {/* end: submit button */}

        </form>
    )
}

export default StockAlertForm;

