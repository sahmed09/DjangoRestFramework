import React, { useEffect, useState, useRef } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { useHistory, useParams } from 'react-router';
import { IShop, IShopBranch } from '../../../../interfaces';
import { createShop, updateShop } from '../../../api/shopAPI';
import { createShopBranch, updateShopBranch } from '../../../api/shopBranchAPI';
import { hideModal } from '../../../redux/slices/modalSlice';
import { getShopBranches } from '../../../redux/slices/shopBranchSlice';
import { disableCreateButton, enableCreateButton } from '../../../redux/slices/uiSlice';
import { AppState } from '../../../redux/store';

interface IBranchFormProps {
    shop: IShop
};

// const ShopBranchForm: React.FC<IBranchFormProps> = ({ shop }) => {
const ShopBranchForm: React.FC<IBranchFormProps> = ({ shop }) => {
    //@ts-ignore
    const { shopID } = useParams();

    useEffect(() => {
        console.log({ shopID });
    }, [])

    useEffect(() => {
        console.log({ shop });
    }, [])



    // update operation
    // const history = useHistory();
    // const { state } = history.location;
    // @ts-ignore
    // const { update, passedData } = state ? state : {};

    // redux
    const dispatch = useDispatch();
    const { branches } = useSelector((state: AppState) => state.shopBranch);

    const [branchName, setBranchName] = useState('')

    // for update operation
    const [branch, setBranch] = useState<IShopBranch>();


    // save shop and branch slugs 
    // const paths = history.location.pathname.split('/');


    // const shopSlugRef = useRef(paths[2]);
    // const branchSlugRef = useRef(paths[4] !== "list" ? paths[4] : null);

    const shopSlugRef = useRef(null);
    const branchSlugRef = useRef(null);


    // const branchSlugRef = useRef(paths[4]);


    // update form values for update operatino
    // useEffect(() => {
    //     if (!update || !passedData) return;
    //     setBranchName(passedData.name);
    // }, []);

    // useEffect(() => {
    //     if (!update) return;

    //     if(branchSlugRef.current === null || branchSlugRef.current === undefined) return;

    //     // get branch
    //     const branch = branches.filter(item => item.slug === branchSlugRef.current)[0];

    //     setBranch(branch);
    //     // setBranchName(passedData.name);
    //     setBranchName(branch.name);
    // }, []);


    // useEffect(() => {
    //     console.log('passed data : ');
    //     console.log(passedData);
    // }, [passedData])

    // useEffect(() => {
    //     console.log('branch state : ');
    //     console.log(branch);
    // }, [branch])


    // useEffect(() => {
    //     console.log('history : ');
    //     console.log(history);

    //     const paths = history.location.pathname.split('/')

    //     console.log('paths: ');
    //     console.log(paths);

    //     const shopSlug = paths[2];
    //     const branchSlug = paths[4];

    //     console.log('shopSlug: ');
    //     console.log(shopSlug);

    //     console.log("branchSlug: "); // check: !== 'list'
    //     console.log(branchSlug);

    //     console.log("update: ");
    //     console.log(update);

    // }, [history])

    // useEffect(() => {
    //     console.log("shopSlugRef.current: ");
    //     console.log(shopSlugRef.current);

    //     console.log("branchSlugRef.current: ");
    //     console.log(branchSlugRef.current);

    // }, [])


    const formSubmitHandler = async (e: React.FormEvent<any>) => {
        e.preventDefault()
        console.log('form submitted');

        // update
        // if (update) {
        //     console.log('updating');

        //     if(!branch) return

        //     // console.log({
        //     //     shopSlug: shopSlugRef.current,
        //     //     branchSlug: branchSlugRef.current,
        //     //     branchName,
        //     // });

        //     // todo: remove hardcoded album_name
        //     //get branch > id by slug

        //     // console.log("branches: ");
        //     // console.log(branches);


        //     // const branch = branches.filter(item => item.slug === branchSlugRef.current)[0]

        //     // console.log(">>> branch: ");
        //     // console.log(branch);

        //     const { status, errorMessage } = await updateShopBranch(branch.id, shopSlugRef.current, branchName);

        //     // return to the previous page
        //     if (status === 200) history.goBack();

        //     else if (errorMessage) alert(errorMessage);
        //     else alert("[Update] Something went wrong");

        //     return;
        // }

        // console.log("creating: ");

        // console.log({
        //     shopSlug: shopSlugRef.current,
        //     branchSlug: branchSlugRef.current,
        //     branchName,
        // });



        // // create operation
        // // const { status, errorMessage } = await createShopBranch(shop.slug, branchName);
        // // const { status, errorMessage } = await createShopBranch(shopSlugRef.current, branchName);
        // const { status, errorMessage } = await createShopBranch(shopSlugRef.current, branchName);
        const { status, errorMessage } = await createShopBranch(shop.slug, branchName);

        if (status === 201) {
            // reload shop branch list
            dispatch(getShopBranches(shop.slug));

            // close modal
            dispatch(hideModal());
        }
        else if (errorMessage) alert(errorMessage)
        else alert("Something went wrong")

    };



    return (
        <div className='row' style={{ backgroundColor: '' }}>
            <div className="col-lg-12">
                <div className='card mb-5 mb-xl-10' style={{ backgroundColor: '' }}>

                    {/* card body */}
                    <div className='row' style={{ backgroundColor: '' }}>
                        <form
                            onSubmit={formSubmitHandler}
                            noValidate className='form'>

                            <div className='card-body border-top p-9' style={{ backgroundColor: '' }}>

                                {/* shop name input area */}
                                <div className='row mb-6'>
                                    <label className='col-lg-2 col-form-label required fw-bold fs-6'>Branch Name</label>
                                    <div className='col-lg-10'>
                                        <div className='row'>
                                            <div className='col-lg-12 fv-row'>
                                                <input
                                                    type='text'
                                                    className='form-control form-control-lg form-control-solid mb-3 mb-lg-0'
                                                    placeholder='Branch Name'
                                                    value={branchName}
                                                    autoFocus
                                                    onChange={e => setBranchName(e.target.value)}
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                {/* end: shop name input area */}

                                {/* todo: show error message */}

                                {/* submit button */}
                                <div className="row m-0 mt-10 border-top pt-9" style={{ backgroundColor: '' }}>
                                    <div className='col-sm-2 offset-sm-10' style={{ backgroundColor: '' }}>
                                        <button
                                            className='btn btn-sm btn-primary me-3 px-12'
                                            disabled={branchName.length === 0}
                                            type="submit">
                                            Save
                                        </button>
                                    </div>
                                </div>
                                {/* end: submit button */}
                            </div>

                        </form>
                    </div>
                    {/* end: card body */}

                </div>
            </div>

        </div>
    )
}


export default ShopBranchForm
