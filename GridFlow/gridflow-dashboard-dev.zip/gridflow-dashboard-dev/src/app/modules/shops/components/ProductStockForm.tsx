import React, { useEffect, useState } from 'react'
import { useDispatch } from 'react-redux'
import { useHistory } from 'react-router'
// import { IShopBranchProduct, IShop, IProduct } from '../../../../interfaces'
import { updateProductStock } from '../../../api/productStockAPI'
import { hideModal } from '../../../redux/slices/modalSlice'


// interface IBranch {
//     name: string
//     slug: string
// }

// interface IProductStock extends IShopBranchProduct {
//     shop: IShop
//     branch: IBranch
// }


interface IProduct {
    name: string
    slug: string
}


interface IShop {
    name: string,
    slug: string,
}

interface IShopBranch {
    name: string
    slug: string
}


export interface IShopBranchProductDetails {
    id: number
    product: IProduct
    price: string
    shop: IShop
    branch?: IShopBranch

    // utilities

    // available in shop/branch 
    added?: boolean

}



interface IProductStockFormProps {
    // product: IShopBranchProduct
    product: IShopBranchProductDetails
    // product: IProductStock
}



const ProductStockForm: React.FC<IProductStockFormProps> = ({ product }) => {


    const history = useHistory()

    const dispatch = useDispatch();

    const productSlug = product.product.slug
    // @ts-ignore
    const shopSlug = product.shop.slug

    useEffect(() => {
        console.log({ productSlug, shopSlug });

    }, [])



    // form input state
    const [stockAlertName, setStockAlertName] = useState('')
    const [stockAlertDescription, setStockAlertDescription] = useState('')
    const [stockBelow, setStockBelow] = useState('')
    const [stockAbove, setStockAbove] = useState('')

    const [submitButtonEnabled, setSubmitButtonEnabled] = useState(false)


    useEffect(() => {
        if (stockAlertName === "" || stockAlertDescription === "" || stockBelow === "" || stockAbove === "") {
            setSubmitButtonEnabled(false);
            return
        }
        setSubmitButtonEnabled(true)
    }, [stockAlertName, stockAlertDescription, stockBelow, stockAbove])


    const formSaveHandler = async (e: React.FormEvent<any>) => {
        e.preventDefault()

        if (stockAlertName === "" || stockAlertDescription === "" || stockBelow === "" || stockAbove === "") return;


        const _stockBelowInt = parseInt(stockBelow);
        if (isNaN(_stockBelowInt)) {
            alert('Invalid stock below value')
            return;
        }

        const _stockAboveInt = parseInt(stockAbove);
        if (isNaN(_stockAboveInt)) {
            alert('Invalid stock above value')
            return;
        }


        const { data, status, errorMessage } = await updateProductStock(shopSlug, productSlug, stockAlertName, stockAlertDescription, _stockAboveInt, _stockBelowInt)

        console.log('stock update response : ');
        console.log({ data, status, errorMessage });


        if (status === 201) {
            //close modal
            dispatch(hideModal())

            // reload current pgae
            // history.go(0)
        }

        // // else {
        // //     alert(`Cannot update stock [status: ${status}]`)
        // // }

        // todo: repalce with background data reload
        // history.go(0)



    };


    return (
        <form
            onSubmit={formSaveHandler}
            noValidate className='form'>

            {/* <pre>{JSON.stringify(product, null, 4)}</pre> */}

            {/* alert name */}
            <div className='row mb-6' style={{ backgroundColor: '' }}>
                <label className='col-md-2 col-form-label required fw-bold fs-6' style={{ backgroundColor: '' }}>Name</label>
                <div className='col-md-10'>
                    <div className='row'>
                        <div className='col-md-12 fv-row'>
                            <input
                                type='text'
                                className='form-control form-control-md form-control-solid mb-3 mb-lg-0'
                                placeholder='Stock Alert Name'
                                value={stockAlertName}
                                autoFocus
                                onChange={e => setStockAlertName(e.target.value)}
                            />
                        </div>
                    </div>
                </div>
            </div>
            {/* end: alert name */}


            {/* description */}
            <div className='row mb-6' style={{ backgroundColor: '' }}>
                <label className='col-md-2 col-form-label required fw-bold fs-6' style={{ backgroundColor: '' }}>Description</label>
                <div className='col-md-10'>
                    <div className='row'>
                        <div className='col-md-12 fv-row'>
                            <input
                                type='text'
                                className='form-control form-control-md form-control-solid mb-3 mb-lg-0'
                                placeholder='Stock Alert Description'
                                value={stockAlertDescription}
                                autoFocus
                                onChange={e => setStockAlertDescription(e.target.value)}
                            />
                        </div>
                    </div>
                </div>
            </div>
            {/* end: description */}


            {/* stock below value */}
            <div className='row mb-6' style={{ backgroundColor: '' }}>
                <label className='col-md-2 col-form-label required fw-bold fs-6' style={{ backgroundColor: '' }}>Stock Below</label>
                <div className='col-md-10'>
                    <div className='row'>
                        <div className='col-md-12 fv-row'>
                            <input
                                type='number'
                                className='form-control form-control-md form-control-solid mb-3 mb-lg-0'
                                placeholder='Stock Below'
                                value={stockBelow}
                                autoFocus
                                onChange={e => setStockBelow(e.target.value)}
                            />
                        </div>
                    </div>
                </div>
            </div>
            {/* end: stock below value */}


            {/* stock above value */}
            <div className='row mb-6' style={{ backgroundColor: '' }}>
                <label className='col-md-2 col-form-label required fw-bold fs-6' style={{ backgroundColor: '' }}>Stock Above</label>
                <div className='col-md-10'>
                    <div className='row'>
                        <div className='col-md-12 fv-row'>
                            <input
                                type='number'
                                className='form-control form-control-md form-control-solid mb-3 mb-lg-0'
                                placeholder='Stock Above'
                                value={stockAbove}
                                autoFocus
                                onChange={e => setStockAbove(e.target.value)}
                            />
                        </div>
                    </div>
                </div>
            </div>
            {/* end: stock aboce value */}


            {/* submit button */}
            <div className="row m-0 mt-10 border-top pt-9" style={{ backgroundColor: '' }}>
                <div className='col-sm-2 offset-sm-10 d-flex justify-content-end p-0' style={{ backgroundColor: '' }}>
                    <button
                        className='btn btn-sm btn-primary px-12'
                        disabled={!submitButtonEnabled}
                        type="submit">
                        Save
                    </button>
                </div>
            </div>
            {/* end: submit button */}

        </form>
    )
}

export default ProductStockForm
