import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector, useStore } from 'react-redux';
import { useParams } from 'react-router';
import { IShop } from '../../../interfaces';
import { getShop } from '../../api/shopAPI';
import { getShopBranches, getShopBranchProductDetails } from '../../api/shopBranchAPI';
import { deleteProductStockAlert } from '../../api/stockAlertAPI';
import Card from '../../components/Card'
import ModalWrapper from '../../components/ModalWrapper';
import { hideModal, setModalData, showModal } from '../../redux/slices/modalSlice';
import { getStockAlertList } from '../../redux/slices/productStockAlertSlice';
import { AppState } from '../../redux/store';
import { IShopBranchProductDetails } from './components/ProductStockForm';
import StockAlertForm from './components/StockAlertForm';


interface IStockAlertListItemProps {
    id: number
    name: string
    stockAbove: number
    stockBelow: number

    // button/checkbox click handlers
    // checkHandler?: (e: React.FormEvent<HTMLButtonElement>, id: number) => void
    editHandler?: (e: React.FormEvent<HTMLButtonElement>, id: number) => void
    deleteHandler?: (e: React.FormEvent<HTMLButtonElement>, id: number) => void
}
const StockAlertListItem: React.FC<IStockAlertListItemProps> = ({ id, name, stockAbove, stockBelow, editHandler = null, deleteHandler = null }) => {


    return (
        <div className="row border-bottom /*border-dark*/ cursor-pointer mt-2 p-2" style={{ backgroundColor: '', height: 50 }}>
            <div className="d-flex align-items-center h-100 p-0" style={{ backgroundColor: '' }}>
                {/* checkbox */}
                <div style={{ width: 30, backgroundColor: '', marginRight: 10 }}>
                    <input className="form-check-input" type="checkbox" />
                </div>

                {/* shop name */}
                <div style={{ flex: 1, backgroundColor: '', marginRight: 10 }}>{name}</div>
                <div className="d-flex justify-content-center" style={{ width: 80, backgroundColor: '', marginRight: 10 }}>{stockAbove}</div>
                <div className="d-flex justify-content-center" style={{ width: 80, backgroundColor: '', marginRight: 10 }}>{stockBelow}</div>

                {/* control buttons */}
                <div className="d-flex justify-content-end" style={{ width: 85, backgroundColor: '' }}>

                    {/* edit button */}
                    <button
                        onClick={e => editHandler ? editHandler(e, id) : e.preventDefault()}
                        className="btn btn-sm me-2 px-3"
                        style={{ backgroundColor: '' }}>
                        < i className="bi bi-pencil"></i>
                    </button>

                    {/* delete button */}
                    <button
                        onClick={e => deleteHandler ? deleteHandler(e, id) : e.preventDefault()}
                        className="btn btn-sm px-3"
                        style={{ backgroundColor: '' }}>
                        < i className="bi bi-trash"></i>
                    </button>

                </div>
                {/* end: control buttons */}

            </div>
        </div>
    )
};


export default function ShopProductStockAlert() {

    // @ts-ignore
    const { shopID, productID } = useParams()

    const dispatch = useDispatch();

    const { alerts } = useSelector((state: AppState) => state.productStockAlert);
    const { visible, modalData } = useSelector((state: AppState) => state.modal)

    const [shop, setShop] = useState<IShop>()

    const [product, setProduct] = useState<IShopBranchProductDetails>()

    // get shop (slug)
    const fetchShop = async () => {
        const { data, status, errorMessage } = await getShop(shopID);

        if (status !== 200) {
            alert(`Something went wrong [status: ${status}] [errmsg: ${errorMessage}]`)
            return;
        }
        if (!data.slug) {
            alert('No data.slug exists')
            console.log({ data });
            return;
        }

        // set shop to local state
        // @ts-ignore
        setShop(data);
    };

    // get shop branch (slug) [optional]
    const getShopBranch = async () => { };

    // get product (slug)
    const fetchProduct = async () => {
        const { data, status } = await getShopBranchProductDetails(productID)

        if (status !== 200) {
            alert(`[fetchProductList] Something went wrong : [status: ${status}]`)
            return
        }

        setProduct(data);
    };



    useEffect(() => {
        if (!shopID || !productID) return;

        fetchShop();
        fetchProduct();


    }, [shopID, productID])

    useEffect(() => {
        if (!shop?.slug || !product?.product.slug) return


        dispatch(getStockAlertList({ productSlug: product.product.slug, shopSlug: shop.slug }))


    }, [shop, product])


    const handleClose = () => {
        console.log('handleClose');
        dispatch(hideModal());

        // reload alerts
        // @ts-ignore
        dispatch(getStockAlertList({ productSlug: product.product.slug, shopSlug: shop.slug }))
    };


    const editClickHandler = async (e: React.FormEvent<HTMLButtonElement>, id: number) => {
        e.preventDefault()

        const filteredAlert = alerts.find(item => item.id === id);

        dispatch(setModalData(filteredAlert))
        dispatch(showModal())
    };


    const deleteClickHandler = async (e: React.FormEvent<HTMLButtonElement>, id: number) => {
        e.preventDefault();

        const confirmDelete = window.confirm('Delete stock alert?' + id);
        if (!confirmDelete) return;

        const { status } = await deleteProductStockAlert(id)

        if (status === 204) {
            // reload alert list
            // @ts-ignore
            dispatch(getStockAlertList({ productSlug: product.product.slug, shopSlug: shop.slug }))
        }
        else alert(`Something went wrong [status: ${status}]`)

    };




    return (
        <>

            {/* todo: add create alert modal */}
            {product && shop && (
                <ModalWrapper
                    modalTitle="Create Stock Alert"
                    handleClose={handleClose}
                    show={visible}>

                    <div className="" style={{ overflowX: 'hidden', overflowY: 'auto' }}>
                        <StockAlertForm
                            product={product}
                            shop={shop}
                        />
                    </div>

                </ModalWrapper>
            )}


            <Card cardHeading="Product Stock Alerts">

                {/* list heading */}
                <div className="row d-flex align-items-center mt-2 p-2" style={{ backgroundColor: '', height: 40, borderBottom: '1px solid #cecece' }}>
                    <div className="d-flex justify-content-end" style={{ width: 30, backgroundColor: '' }}></div>
                    <div style={{ flex: 1, backgroundColor: '', marginRight: 10 }}>Status</div>

                    <div style={{ width: 80, backgroundColor: '', marginRight: 10 }}>Above</div>
                    <div style={{ width: 80, backgroundColor: '', marginRight: 10 }}>Below</div>

                    <div className="d-flex justify-content-end" style={{ width: 80, backgroundColor: '' }}></div>
                </div>
                {/* end: list heading */}

                {/* alert list items */}
                {alerts.map(({ id, name, stockAbove, stockBelow }) => (
                    <StockAlertListItem
                        key={id}
                        id={id}
                        name={name}
                        stockAbove={stockAbove}
                        stockBelow={stockBelow}

                        editHandler={editClickHandler}
                        deleteHandler={deleteClickHandler}
                    />

                ))}
                {/* end: alert list items */}


                {/* <StockAlertListItem /> */}
                {/* <StockAlertListItem /> */}

            </Card>
        </>
    )
}
