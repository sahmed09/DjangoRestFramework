import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router';
import { IShopBranchProduct } from '../../../interfaces';
import { getProductStockInfo } from '../../api/productStockAPI';
import { getShopBranchProductDetails } from '../../api/shopBranchAPI';
import Card from "../../components/Card";
import ModalWrapper from '../../components/ModalWrapper';
import { hideModal } from '../../redux/slices/modalSlice';
import { AppState } from '../../redux/store';
import ProductStockForm from './components/ProductStockForm';


interface IProduct {
    name: string
    slug: string
}


interface IShop {
    name: string,
    slug: string,
}

interface IShopBranch {
    name: string
    slug: string
}


export interface IShopBranchProductDetails {
    id: number
    product: IProduct
    price: string
    shop: IShop
    branch?: IShopBranch

    // utilities

    // available in shop/branch 
    added?: boolean

}

export default function ShopProductDetails() {


    // @ts-ignore
    const { shopID, productID } = useParams()

    const dispatch = useDispatch();
    const { visible, modalData } = useSelector((state: AppState) => state.modal)


    const [stockModalData, setStockModalData] = useState<IShopBranchProduct>();
    // const [shopProduct, setShopProduct] = useState<IShopBranchProduct>();
    const [shopProduct, setShopProduct] = useState<IShopBranchProductDetails>();

    // @ts-ignore
    const [productStockInfo, setProductStockInfo] = useState([]);


    const fetchShopProduct = async () => {
        const { data, status } = await getShopBranchProductDetails(productID)

        if (status !== 200) {
            alert(`[fetchProductList] Something went wrong : [status: ${status}]`)
            return
        }

        setShopProduct(data);
    };

    const fetchProductStockInfo = async (productSlug: string) => {
        const { data, status } = await getProductStockInfo(productSlug)

        if (status !== 200) {
            alert(`[fetchProductStockInfo] Something went wrong : [status: ${status}]`)
            return
        }

        setProductStockInfo(data.results);
    };


    useEffect(() => {
        console.log({ shopID, productID });

        if (!productID) return
        fetchShopProduct();
    }, [])


    useEffect(() => {
        console.log(shopProduct);

        if (!shopProduct?.product.slug) return;

        // fetch stock info
        fetchProductStockInfo(shopProduct?.product.slug)

    }, [shopProduct])


    useEffect(() => {
        console.log(productStockInfo);

    }, [productStockInfo])

    const handleClose = () => {
        // hide modal
        dispatch(hideModal());

        // reload page data
        fetchShopProduct();
    };


    return (
        <>

            {shopProduct && (
                <ModalWrapper
                    modalWidth="mw-700px"
                    modalTitle="Update Product Stock"
                    handleClose={handleClose}
                    show={visible}>

                    <div style={{ height: 380 }}>
                        <div style={{ height: '100%', overflowX: 'hidden', overflowY: 'auto' }}>
                            <ProductStockForm product={shopProduct} />
                        </div>
                    </div>

                </ModalWrapper>
            )}


            <div className="row">
                {/* shop product details */}
                <div className="col-sm-12 col-md-6">
                    <Card cardHeading={shopProduct?.product.name}>

                        <div className="row">
                            <div className="col-sm-12">
                                <p><strong>Price: </strong>{shopProduct?.price}</p>
                                <p><strong>Shop: </strong>{shopProduct?.shop?.name}</p>
                                <p><strong>Branch: </strong>{shopProduct?.branch?.name}</p>
                            </div>
                        </div>

                    </Card>
                </div>
                {/* end: shop product details */}

                {/* stock details */}
                <div className="col-sm-12 col-md-6">
                    <Card cardHeading="Stock Info">

                        {/* <div className="row">
                            <div className="col-sm-12">
                                <p><strong>Name: </strong>Stock Alert</p>
                                <p><strong>Description: </strong>Lorem ipsum dolor sit amet.</p>
                                <p><strong>Stock Above: </strong>15</p>
                                <p><strong>Stock Below: </strong>5</p>
                            </div>
                        </div> */}

                        {productStockInfo.length > 0 && productStockInfo.map((info) => {

                            // @ts-ignore
                            const { name = '', description = '', stock_below = '', stock_above = '' } = info

                            return (
                                <div className="row pb-2 mb-3" style={{borderBottom: '1px solid #ededed'}}>
                                    <div className="col-sm-12">
                                        <p><strong>Name: </strong>{name}</p>
                                        <p><strong>Description: </strong>{description}</p>
                                        <p><strong>Stock Above: </strong>{stock_above}</p>
                                        <p><strong>Stock Below: </strong>{stock_below}</p>
                                    </div>
                                </div>
                            )
                        })}

                    </Card>
                </div>
                {/* end: stock details */}
            </div>



        </>
    )
}
