import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router';
import { IShop } from '../../../../../interfaces';
import { getShop } from '../../../../api/shopAPI';
import Card from "../../../../components/Card";
import ModalWrapper from '../../../../components/ModalWrapper';
import { hideModal } from '../../../../redux/slices/modalSlice';
import { getShopUsers } from '../../../../redux/slices/userRoleSlice';
import { AppState } from '../../../../redux/store';
import UserRoleForm from '../../components/UserRoleForm';
// import UserRoleForm from '../../components/UserRoleForm';








interface IRoleListItemProps {
    id: number
    index: number
    username: string
    shopName: string
    shopSlug: string
    roleName: string

    deleteHandler?: (e: React.FormEvent<HTMLButtonElement>, id: number) => void
}


const RoleListItem: React.FC<IRoleListItemProps> = ({ index, id, username, shopName, shopSlug, roleName, deleteHandler = null }) => (
    <div className="d-flex align-items-center mt-2 p-2" style={{ backgroundColor: '', height: 40, border: '1px solid #ececec', cursor: 'pointer' }}>
        {/* sl. */}
        <div className="d-flex justify-content-end" style={{ width: 30, backgroundColor: '', marginRight: 15 }}>{index}</div>
        {/* date time */}
        <div style={{ flex: 1, backgroundColor: '', marginRight: 10 }}>{username}</div>
        {/* email */}
        <div style={{ width: 150, backgroundColor: '', marginRight: 10 }}>{shopName}</div>
        {/* phone number */}
        <div style={{ width: 180, backgroundColor: '', marginRight: 10 }}>{roleName}</div>
        {/* delete button */}
        <div className="d-flex justify-content-end" style={{ width: 80, backgroundColor: '' }}>
            <button
                onClick={e => deleteHandler ? deleteHandler(e, id) : e.preventDefault()}
                className="btn btn-sm">
                <i className="bi bi-trash"></i>
            </button>
        </div>
    </div>
);










export default function ShopUserRoles() {
    // @ts-ignore
    const { shopID } = useParams()


    const dispatch = useDispatch();
    const { page, roles } = useSelector((state: AppState) => state.userRole)
    const { visible } = useSelector((state: AppState) => state.modal)

    const [shop, setShop] = useState<IShop>()


    const fetchShop = async () => {
        const { data, status, errorMessage } = await getShop(shopID);

        if (status !== 200) {
            alert(`Something went wrong [status: ${status}] [errmsg: ${errorMessage}]`)
            return;
        }
        if (!data.slug) {
            alert('No data.slug exists')
            console.log({ data });
            return;
        }

        // set shop to local state
        setShop(data);
    };

    useEffect(() => {
        console.log(shopID);
        if (!shopID) return
        fetchShop()
        // dispatch(getShopUsers())
    }, [shopID])

    useEffect(() => {
        if (!shop) return;

        dispatch(getShopUsers({ shopSlug: shop.slug, page: 1 }))
    }, [shop])

    const handleClose = () => {
        // hide modal
        dispatch(hideModal());

        // todo: refresh customer list
    };


    return (
        <>
            {/* todo: add user role form modal */}
            {shop && (<ModalWrapper
                modalWidth="mw-700px"
                modalTitle="Set user role for ${user}"
                handleClose={handleClose}
                show={visible}>

                <div style={{ height: 250 }}>
                    <div style={{ height: '100%', overflowX: 'hidden', overflowY: 'auto' }}>
                        <UserRoleForm shopSlug={shop.slug} />
                    </div>
                </div>

            </ModalWrapper>)}


            <Card cardHeading="Shop Users">


                {/* list heading */}
                <div className="d-flex align-items-center mt-2 p-2" style={{ backgroundColor: '', height: 40, borderBottom: '1px solid #cecece' }}>
                    <div className="d-flex justify-content-end" style={{ width: 30, backgroundColor: '', marginRight: 15 }}>#</div>
                    <div style={{ flex: 1, backgroundColor: '', marginRight: 10 }}>Username</div>
                    <div style={{ width: 150, backgroundColor: '', marginRight: 10 }}>Shop</div>
                    <div style={{ width: 180, backgroundColor: '', marginRight: 10 }}>Role</div>
                    <div className="d-flex justify-content-end" style={{ width: 80, backgroundColor: '' }}></div>
                </div>
                {/* end: list heading */}

                {roles.map((role, index) => (

                    // <pre>{JSON.stringify(role, null, 4)}</pre>
                    <RoleListItem
                        key={role.id}
                        id={role.id}
                        index={index + 1}
                        username={role.user.username}
                        shopName={role.shop.name}
                        shopSlug={role.shop.slug}
                        roleName={role.role}
                    />

                ))}

            </Card>
        </>
    )
}
