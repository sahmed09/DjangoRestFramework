import React, { useEffect, useState } from 'react'
import { Redirect, Route, Switch, useParams } from 'react-router';
import { PageLink, PageTitle } from '../../../../_metronic/layout/core';
import BranchDetails from '../BranchDetails/BranchDetails';
import ProductList from '../components/ProductList';
import { IHeaderTab, PageHeader } from '../PageHeader';
import ShopProductDetails from '../ShopProductDetails';
import ShopProductStockAlert from '../ShopProductStockAlert';
import ShopBranchList from './sections/ShopBranchList';
import ShopInfo from './sections/ShopInfo';
import ShopOrderStatus from './sections/ShopOrderStatus';
import ShopUserRoles from './sections/ShopUserRoles';


const shopBreadCrumbs: Array<PageLink> = [
    {
        title: 'Shops',
        path: '/shops',
        isSeparator: false,
        isActive: false,
    },
    // separator (-)
    {
        title: '',
        path: '',
        isSeparator: true,
        isActive: false,
    },
]


export default function ShopDetails() {
    // @ts-ignore
    const { shopID } = useParams()

    const [pageSections, setPageSections] = useState<IHeaderTab[]>()

    // set page section data when component mounts
    useEffect(() => {
        setPageSections(
            [
                {
                    path: `/shops/${shopID}/overview`,
                    title: 'Overview'
                },
                {
                    path: `/shops/${shopID}/branch`,
                    title: 'Branch List',
                },
                {
                    path: `/shops/${shopID}/products`,
                    title: 'Product List',
                },
                {
                    path: `/shops/${shopID}/users`,
                    title: 'Users',
                },
                {
                    path: `/shops/${shopID}/configuration`,
                    title: 'Configuration',
                },
            ]
        );
    }, []);

    return (
        <>
            {/* page sections */}
            {/* show this pagination only in shop list, not branch list */}
            <Route exact path='/shops/:shopID/overview'>
                {pageSections && <PageHeader sections={pageSections} />}
            </Route>
            <Route exact path='/shops/:shopID/branch'>
                {pageSections && <PageHeader sections={pageSections} />}
            </Route>
            <Route exact path='/shops/:shopID/products'>
                {pageSections && <PageHeader sections={pageSections} />}
            </Route>
            {/* <Route exact path='/shops/:shopID/products/:productID'>
                {pageSections && <PageHeader sections={pageSections} />}
            </Route> */}
            <Route exact path='/shops/:shopID/users'>
                {pageSections && <PageHeader sections={pageSections} />}
            </Route>
            <Route exact path='/shops/:shopID/configuration'>
                {pageSections && <PageHeader sections={pageSections} />}
            </Route>

            <Switch>
                {/* shop info (graphs) */}
                <Route path='/shops/:shopID/overview'>
                    <PageTitle breadcrumbs={shopBreadCrumbs}>Shop Overview</PageTitle>
                    <ShopInfo />
                </Route>

                {/* branch list */}
                <Route exact path='/shops/:shopID/branch'>
                    <PageTitle breadcrumbs={shopBreadCrumbs}>Shop Branch List</PageTitle>
                    <ShopBranchList />
                </Route>

                {/* shop product list (from all branch) */}
                <Route exact path='/shops/:shopID/products'>
                    <PageTitle breadcrumbs={shopBreadCrumbs}>Shop Product List</PageTitle>
                    <ProductList />
                </Route>

                {/* shop product details */}
                <Route exact path='/shops/:shopID/products/:productID'>
                    <PageTitle breadcrumbs={shopBreadCrumbs}>Shop Product Details</PageTitle>
                    <ShopProductDetails />
                </Route>

                {/* product stock alert route */}
                <Route exact path='/shops/:shopID/products/:productID/stockalerts'>
                    <PageTitle breadcrumbs={shopBreadCrumbs}>Product Stock Alert</PageTitle>
                    <ShopProductStockAlert />
                </Route>

                {/* shop user & role management */}
                <Route exact path='/shops/:shopID/users'>
                    <PageTitle breadcrumbs={shopBreadCrumbs}>Shop Users</PageTitle>
                    <ShopUserRoles />
                </Route>

                {/* shop specific order status and other config management section */}
                <Route exact path='/shops/:shopID/configuration'>
                    <PageTitle breadcrumbs={shopBreadCrumbs}>Configuration</PageTitle>
                    <ShopOrderStatus />
                </Route>

                {/* branch details page */}
                <Redirect from='/shops/:shopID/branch/:branchID' exact={true} to='/shops/:shopID/branch/:branchID/overview' />
                {/* note: don't use 'exact' here */}
                <Route path='/shops/:shopID/branch/:branchID'>
                    <PageTitle breadcrumbs={shopBreadCrumbs}>Branch Details</PageTitle>
                    {/* <ShopDetails /> */}
                    <BranchDetails />
                </Route>



            </Switch>
        </>
    )
}
