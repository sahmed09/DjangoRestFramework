import React, { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import Card from "../../../../components/Card";
import { disableCreateButton, enableCreateButton } from '../../../../redux/slices/uiSlice';
import { BarChart, IChartDataset, LineChart } from "../../../../components/Chart";
import { getChartData } from '../../../../api/chartAPI';
import { start } from 'repl';
import { useParams } from 'react-router';
import { getShop } from '../../../../api/shopAPI';
import { addDaysToToday, dateToString, subtractDaysFromToday } from '../../../../../utils';
import SelectSearch from 'react-select-search';

// const chartIntervalOptions = ['daily', 'monthly', 'yearly'];
const chartIntervalOptions = [
    { name: 'Daily', value: 'daily' },
    { name: 'Monthly', value: 'monthly' },
    { name: 'Yearly', value: 'yearly' },
];


export default function ShopInfo() {

    const dispatch = useDispatch();

    // @ts-ignore
    const { shopID } = useParams()

    // @ts-ignore
    const [shop, setShop] = useState(null);

    // chart data
    const [startDate, setStartDate] = useState<string>('');
    const [endDate, setEndDate] = useState<string>('');

    const [interval, setInterval] = useState<string>("daily");

    const [chartLabels, setChartLabels] = useState([]);
    const [chartDatasets, setChartDatasets] = useState<IChartDataset[]>();


    // disable create button, set start and end dates on component mount
    useEffect(() => {
        // disable create button for update operation
        dispatch(disableCreateButton())

        // set endDate as tomorrow (not today), startDate = (today - 7 days) as default value
        const _startDate = dateToString(subtractDaysFromToday(7));
        const _endDate = dateToString(addDaysToToday(1));
        setStartDate(_startDate);
        setEndDate(_endDate);

        // enable create button again when component dismounts
        return () => { dispatch(enableCreateButton()) }
    }, []);



    // fetch shop details
    const fetchShop = async () => {
        const { data, status, errorMessage } = await getShop(shopID);

        if (status !== 200) {
            alert(`Something went wrong [status: ${status}] [errmsg: ${errorMessage}]`)
            return;
        }
        if (!data.slug) {
            alert('No data.slug exists')
            console.log({ data });
            return;
        }

        // set shop to local state
        setShop(data);
    };


    // fetch shop if shop id (url param) changes 
    // shop (slug) is required for chart query
    useEffect(() => {
        if (!shopID) return;
        fetchShop();
    }, [shopID])


    const fetchChartData = async () => {
        // @ts-ignore
        const { data, status, errorMessage } = await getChartData(startDate, endDate, interval, shop.slug);

        if (status !== 200) {
            console.log("Chart fetch error");
            console.log({ data, status, errorMessage });
            return
        }

        //demo data
        // const data = {
        //     results: [
        //         {
        //             date: "2021-10-24",
        //             max_quantity: 11,
        //             min_quantity: 4,
        //             avg_quantity: 7.5
        //         },
        //         {
        //             date: "2021-10-25",
        //             max_quantity: 7,
        //             min_quantity: 2,
        //             avg_quantity: 4.5
        //         },
        //         {
        //             date: "2021-10-26",
        //             max_quantity: 6,
        //             min_quantity: 4,
        //             avg_quantity: 5
        //         },
        //         {
        //             date: "2021-10-27",
        //             max_quantity: 14,
        //             min_quantity: 4,
        //             avg_quantity: 9
        //         },
        //         {
        //             date: "2021-10-28",
        //             max_quantity: 9,
        //             min_quantity: 8,
        //             avg_quantity: 8.5
        //         },
        //     ]
        // }

        // prepare chart data

        // @ts-ignore
        const labels = data.results.map(d => d.date);

        // @ts-ignore
        const minVals = data.results.map(d => d.min_quantity)
        // @ts-ignore
        const maxVals = data.results.map(d => d.max_quantity)
        // @ts-ignore
        const avgVals = data.results.map(d => d.avg_quantity)

        const datasets: IChartDataset[] = [
            // sequence is important: min to max
            {
                label: 'Minimum Quantity',
                data: minVals,
                backgroundColor: 'rgb(255, 99, 132)',
                // stack: 'Stack 0',
                fill: true,
                tension: 0.5,
            },
            {
                label: 'Average Quantity',
                data: avgVals,
                backgroundColor: 'rgb(75, 192, 192)',
                // stack: 'Stack 2',
                fill: true,
                tension: 0.5,
            },
            {
                label: 'Maximum Quantity',
                data: maxVals,
                backgroundColor: 'rgb(54, 162, 235)',
                // stack: 'Stack 1',
                fill: true,
                tension: 0.5,
            },
        ];

        // @ts-ignore
        setChartLabels(labels);
        // @ts-ignore
        setChartDatasets(datasets);
    };


    // fetch chart data when shop changes (componentDidMount)
    useEffect(() => {
        if (!shop) return
        fetchChartData()
    }, [shop])


    // fetch chart data when filter applied
    const filterChart = async (e: React.FormEvent<any>) => {
        e.preventDefault();
        fetchChartData();
    };


    return (
        <Card
            cardHeading={"Shop Info"}>

            {/* range select options */}
            {/* filter area */}
            <div className="row mb-6 d-flex align-items-center" style={{ backgroundColor: '' }}>

                {/* start date */}
                <div className="col-md-4 d-flex align-items-center" style={{ backgroundColor: '' }}>
                    <label className='' style={{ width: 150, backgroundColor: '' }}>Start Date</label>
                    <input
                        className='form-control form-control-md form-control-solid mb-3 mb-md-0'
                        style={{ backgroundColor: '', width: 380 }}
                        type="date"
                        value={startDate}
                        // @ts-ignore
                        onChange={e => setStartDate(e.target.value)}
                    />
                </div>
                {/* end: start date */}

                {/* end date */}
                <div className="col-md-4 d-flex align-items-center" style={{ backgroundColor: '' }}>
                    <label className='' style={{ width: 150, backgroundColor: '' }}>End Date</label>
                    <input
                        className='form-control form-control-md form-control-solid mb-3 mb-md-0'
                        type="date"
                        value={endDate}
                        // @ts-ignore
                        onChange={e => setEndDate(e.target.value)}
                    />
                </div>
                {/* end: end date */}

                {/* interval */}
                <div className='col-md-3 d-flex align-items-center' style={{ backgroundColor: '' }}>
                    <label className='' style={{ width: 100, backgroundColor: '' }}>Interval</label>
                    <SelectSearch
                        options={chartIntervalOptions}
                        value={interval}
                        // @ts-ignore
                        name="interval"
                        // @ts-ignore
                        onChange={v => setInterval(v)}
                        placeholder='Select Interval' />

                </div>
                {/* end: interval */}

                {/* submit button */}
                <div className="col-md-1 d-flex align-items-center" style={{ backgroundColor: '' }}>
                    <button
                        className="btn btn-primary btn-sm w-100"
                        onClick={filterChart}>
                        <i className="bi bi-funnel"></i>
                    </button>
                </div>
                {/* end: submit button */}
            </div>
            {/* end: filter area */}

            {/* end: range select options */}

            {/* render chart */}
            {chartLabels && chartDatasets && (
                <LineChart
                    labels={chartLabels}
                    datasets={chartDatasets} />
            )}
            {/* end: render chart */}

        </Card>
    )
}
