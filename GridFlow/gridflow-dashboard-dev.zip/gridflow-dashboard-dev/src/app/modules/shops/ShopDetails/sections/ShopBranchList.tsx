import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router';
import { Link } from 'react-router-dom';
import { IShop } from '../../../../../interfaces';
import { getShop } from '../../../../api/shopAPI';
import { deleteShopBranch } from '../../../../api/shopBranchAPI';
import Card from "../../../../components/Card";
import ModalWrapper from '../../../../components/ModalWrapper';
import { hideModal } from '../../../../redux/slices/modalSlice';
import { getShopBranches, resetShopBranchState, setShopID } from '../../../../redux/slices/shopBranchSlice';
import { AppState } from '../../../../redux/store';
import ListItem from '../../components/ListItem';
import ShopBranchForm from '../../components/ShopBranchForm';

export default function ShopBranchList() {

    //set shop in local state 
    const [shop, setShop] = useState<IShop>();

    // @ts-ignore
    const { shopID } = useParams();

    const dispatch = useDispatch();
    const { shopID: shopId, shopName, shopSlug, branches, hasPrevious, hasNext, error, page } = useSelector((state: AppState) => state.shopBranch);

    const fetchShopBranches = async (id: number) => {
        const { data, status, errorMessage } = await getShop(shopID);

        if (status !== 200) {
            alert(`Something went wrong [status: ${status}] [errmsg: ${errorMessage}]`)
            return;
        }

        // else if (!data.slug) {
        if (!data.slug) {
            alert('No data.slug exists')
            console.log({ data });
            return;
        }

        // set shop to local state
        setShop(data);

        //get shop branch list using redux async func call
        dispatch(getShopBranches(data.slug));
    };

    // fetch shop list (update redux store)
    useEffect(() => {
        fetchShopBranches(shopID);
    }, [shopID])

    //reset Shop Branch State when component dismounts
    useEffect(() => {
        return () => {
            dispatch(resetShopBranchState())
        }
    }, [])


    // modal state
    const { visible } = useSelector((state: AppState) => state.modal);

    const handleClose = () => {
        // hide modal
        dispatch(hideModal());
        // refetch shop list
        fetchShopBranches(shopID);

    };



    const branchDeleteHandler = async (e: React.FormEvent<HTMLButtonElement>, id: number) => {
        e.preventDefault();

        const branch = branches.filter(item => item.id === id)[0];
        const confirmDelete = window.confirm(`Delete branch '${branch.name}'`);

        if (!confirmDelete) return;

        const { status, errorMessage } = await deleteShopBranch(branch.id);

        // reload shop branch list
        if (status === 204) fetchShopBranches(shopID);
        else if (errorMessage) alert(errorMessage);
        else alert("Something wrong happened");

    }

    return (
        <>

            {/* shop create/update modal */}
            {shop && (
                <ModalWrapper
                    modalTitle="Create Branch"
                    handleClose={handleClose}
                    show={visible}>

                    <ShopBranchForm shop={shop} />

                </ModalWrapper>
            )}
            {/* end: shop create/update modal */}


            <Card cardHeading="Shop Branches">

                {branches.length === 0 && (
                    <div>No branch found!</div>
                )}

                {branches.map(branch => (

                    <Link
                        key={branch.id}
                        to={"/shops/" + shopID + "/branch/" + branch.id}
                        style={{ color: "inherit" }}>

                        <ListItem
                            key={branch.id}
                            id={branch.id}
                            name={branch.name}

                            deleteHandler={branchDeleteHandler} />

                    </Link>
                ))}

            </Card>
        </>
    )
}
