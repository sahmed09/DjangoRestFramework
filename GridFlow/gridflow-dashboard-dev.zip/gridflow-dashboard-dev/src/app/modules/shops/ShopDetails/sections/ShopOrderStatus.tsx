import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router';
import { number } from 'yup/lib/locale';
import { IShop } from '../../../../../interfaces';
import { deleteShopOrderStatus } from '../../../../api/orderStatusAPI';
import { getShop } from '../../../../api/shopAPI';
import Card from "../../../../components/Card";
import ModalWrapper from '../../../../components/ModalWrapper';
import { hideModal } from '../../../../redux/slices/modalSlice';
import { getShopStatusList } from '../../../../redux/slices/shopOrderStatusSlice';
import { AppState } from '../../../../redux/store';
import { ShopOrderStatusForm } from '../../components/ShopOrderStatusForm';


export interface IOrderStatusListItemProps {
    id: number,
    status: string,
    // button/checkbox click handlers
    checkHandler?: (e: React.FormEvent<HTMLButtonElement>, id: number) => void
    editHandler?: (e: React.FormEvent<HTMLButtonElement>, id: number) => void
    deleteHandler?: (e: React.FormEvent<HTMLButtonElement>, id: number) => void
}

const OrderStatusListItem: React.FC<IOrderStatusListItemProps> = ({ id, status, checkHandler = null, editHandler = null, deleteHandler = null }) => {
    return (
        <div className="row border-bottom /*border-dark*/ cursor-pointer mt-2 p-2" style={{ backgroundColor: '', height: 50 }}>
            <div className="d-flex align-items-center h-100 p-0" style={{ backgroundColor: '' }}>
                {/* checkbox */}
                <div style={{ width: 30, backgroundColor: '', marginRight: 10 }}>
                    <input className="form-check-input" type="checkbox" />
                </div>

                {/* shop name */}
                <div style={{ flex: 1, backgroundColor: '', marginRight: 10 }}>{status}</div>

                {/* control buttons */}
                <div className="d-flex justify-content-end" style={{ width: 85, backgroundColor: '' }}>

                    {/* edit button */}
                    {/* <button
                        onClick={e => editHandler ? editHandler(e, id) : e.preventDefault()}
                        className="btn btn-sm me-2 px-3"
                        style={{ backgroundColor: '' }}>
                        < i className="bi bi-pencil"></i>
                    </button> */}

                    {/* delete button */}
                    <button
                        onClick={e => deleteHandler ? deleteHandler(e, id) : e.preventDefault()}
                        className="btn btn-sm px-3"
                        style={{ backgroundColor: '' }}>
                        < i className="bi bi-trash"></i>
                    </button>

                </div>
                {/* end: control buttons */}

            </div>
        </div>
    )
};


const ShopOrderStatus = () => {

    // @ts-ignore
    const { shopID } = useParams()

    const dispatch = useDispatch();
    // const { statusList } = useSelector((state: AppState) => state.shopOrderStatus);
    // const { visible } = useSelector((state: AppState) => state.modal)

    const { statusList, visible } = useSelector((state: AppState) => ({
        ...state.shopOrderStatus,
        ...state.modal,
    }));



    // local state
    const [shop, setShop] = useState<IShop>();

    const fetchShop = async (shopID: number) => {
        const { data, status, errorMessage } = await getShop(shopID);
        console.log({ data, status, errorMessage });

        if (status !== 200) {
            alert(`Something went wrong [status: ${status}] [errmsg: ${errorMessage}]`)
            return;
        }

        setShop(data);
    };

    useEffect(() => {
        // todo: check if number
        if (!shopID) return
        fetchShop(shopID)
    }, [shopID])



    useEffect(() => {
        if (!shop?.slug) return
        console.log('fetching shop status list');

        dispatch(getShopStatusList({ slug: shop.slug }))
    }, [shop])

    const handleClose = () => {
        // hide modal
        dispatch(hideModal());

        // todo: refresh customer list
    };


    const deleteHandler = async (e: React.FormEvent<HTMLButtonElement>, id: number) => {
        e.preventDefault();

        const confirmDelete = window.confirm(`Delete status?`);
        if (!confirmDelete) return;

        const { status } = await deleteShopOrderStatus(id);

        if (status === 204) {

            //reload shop status list
            //@ts-ignore
            dispatch(getShopStatusList({ slug: shop.slug }))
            return;
        }
        alert(`Error deleting order status [HTTP status: ${status}]`)
    };


    return (
        <>

            {shop && (
                <ModalWrapper
                    modalWidth="mw-700px"
                    modalTitle="Order Status for Shop"
                    handleClose={handleClose}
                    show={visible}>
                    <ShopOrderStatusForm shop={shop} />
                </ModalWrapper>
            )}


            <Card cardHeading="Shop Order Status Configuration">

                {/* list heading */}
                <div className="row d-flex align-items-center mt-2 p-2" style={{ backgroundColor: '', height: 40, borderBottom: '1px solid #cecece' }}>
                    <div className="d-flex justify-content-end" style={{ width: 30, backgroundColor: '' }}></div>
                    <div style={{ flex: 1, backgroundColor: '', marginRight: 10 }}>Status</div>
                    <div className="d-flex justify-content-end" style={{ width: 80, backgroundColor: '' }}></div>
                </div>
                {/* end: list heading */}

                {/* loop through all order status for the shop */}
                {statusList.map(({ id, shopOrderStatus, message, timestamp }) => (
                    <OrderStatusListItem
                        key={id}
                        id={id}
                        status={shopOrderStatus}

                        // todo: add click handlers
                        deleteHandler={deleteHandler}
                    />
                ))}

            </Card>
        </>
    )
}

export default ShopOrderStatus
