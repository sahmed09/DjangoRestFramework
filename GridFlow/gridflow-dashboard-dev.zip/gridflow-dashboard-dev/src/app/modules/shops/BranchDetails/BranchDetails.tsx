import React, { useEffect, useState } from 'react'
import { Route, Switch, useParams } from 'react-router';
import { PageLink, PageTitle } from '../../../../_metronic/layout/core';
import ProductList from '../components/ProductList';
import { IHeaderTab, PageHeader } from '../PageHeader';
import BranchInfo from './sections/BranchInfo';
// import ShopBranchList from './sections/ShopBranchList';
// import ShopInfo from './sections/ShopInfo';


// const branchBreadCrumbs: Array<PageLink> = [
//     {
//         title: 'Shops',
//         path: '/shops',
//         isSeparator: false,
//         isActive: false,
//     },
//     // separator (-)
//     {
//         title: '',
//         path: '',
//         isSeparator: true,
//         isActive: false,
//     },
// ]


export default function BranchDetails() {
    // @ts-ignore
    const { shopID, branchID } = useParams()

    const [pageBreadCrumbs, setPageBreadCrumbs] = useState<PageLink[]>()
    const [pageSections, setPageSections] = useState<IHeaderTab[]>()

    // set page section data when component mounts
    useEffect(() => {
        setPageBreadCrumbs(
            [
                {
                    title: 'Shops',
                    path: '/shops',
                    isSeparator: false,
                    isActive: false,
                },
                // separator (-)
                {
                    title: '',
                    path: '',
                    isSeparator: true,
                    isActive: false,
                },
                {
                    // todo: replace with shop name
                    title: 'Shop Details',
                    path: `/shops/${shopID}`,
                    isSeparator: false,
                    isActive: false,
                },
                // separator (-)
                {
                    title: '',
                    path: '',
                    isSeparator: true,
                    isActive: false,
                },
            ]
        );


        setPageSections(
            [
                {
                    path: `/shops/${shopID}/branch/${branchID}/overview`,
                    title: 'Overview'
                },
                {
                    path: `/shops/${shopID}/branch/${branchID}/products`,
                    title: 'Product List',
                },
            ]
        );
    }, []);

    return (
        <>
            {/* page sections */}
            {pageSections && <PageHeader sections={pageSections} />}

            <Switch>
                {/* branch info (graphs) */}
                <Route path='/shops/:shopID/branch/:branchID/overview'>
                    {/* <PageTitle breadcrumbs={branchBreadCrumbs}>Branch Overview</PageTitle> */}
                    <PageTitle breadcrumbs={pageBreadCrumbs}>Branch Overview</PageTitle>
                    <BranchInfo />
                </Route>

                {/* product list */}
                <Route exact path='/shops/:shopID/branch/:branchID/products'>
                    {/* <PageTitle breadcrumbs={branchBreadCrumbs}>Product List</PageTitle> */}
                    <PageTitle breadcrumbs={pageBreadCrumbs}>Product List</PageTitle>
                    <ProductList />
                </Route>

                {/* todo: add shop product list section */}

            </Switch>
        </>
    )
}
