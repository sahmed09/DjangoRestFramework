import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Route, Switch } from 'react-router'
import { PageLink, PageTitle } from '../../../_metronic/layout/core'
import ModalWrapper from '../../components/ModalWrapper'
import { hideModal } from '../../redux/slices/modalSlice'
import { AppState } from '../../redux/store'
import CustomerList from './sections/CustomerList'
import Card from "../../components/Card";
import CustomerForm from './CustomerForm'

const customersBreadCrumbs: Array<PageLink> = [
    // Boilerplate root
    {
        title: 'Customers',
        path: '/customers',
        isSeparator: false,
        isActive: false,
    },

    // separator (-)
    {
        title: '',
        path: '',
        isSeparator: true,
        isActive: false,
    },
]


const CustomersPage: React.FC = () => {
    const dispatch = useDispatch();
    // modal state
    const { visible } = useSelector((state: AppState) => state.modal)

    const handleClose = () => {
        // hide modal
        dispatch(hideModal());

        // todo: refresh customer list
    };


    return (
        <>
            <ModalWrapper show={visible} handleClose={handleClose} modalTitle="Create Customer">

                <CustomerForm />

            </ModalWrapper>


            <Switch>
                <Route path='/customers'>
                    <PageTitle breadcrumbs={customersBreadCrumbs}>Order List</PageTitle>
                    <CustomerList />
                </Route>
            </Switch>

        </>
    )
}

export default CustomersPage;
