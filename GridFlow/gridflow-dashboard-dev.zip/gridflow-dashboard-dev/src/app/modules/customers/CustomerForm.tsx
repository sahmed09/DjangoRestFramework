import React, { useState, useEffect } from 'react'
import { useDispatch } from 'react-redux'
import SelectSearch from 'react-select-search'
import { createCustomer } from '../../api/customerAPI'
import { getShops } from '../../api/shopAPI'
import { hideModal } from '../../redux/slices/modalSlice'

export default function CustomerForm() {

    const dispatch = useDispatch();

    const [shopList, setShopList] = useState([])

    const [shop, setShop] = useState('')
    const [firstName, setFirstName] = useState('')
    const [lastName, setLastName] = useState('')
    const [email, setEmail] = useState('')
    const [mobile, setMobile] = useState('')

    const [saveButtonEnabled, setSaveButtonEnabled] = useState(false)

    // enable save button when all inputs are ok
    useEffect(() => {
        if (shop === "" || firstName === "" || lastName === "" || email === "" || mobile === "") {
            setSaveButtonEnabled(false);
            return;
        }
        setSaveButtonEnabled(true);
    }, [shop, firstName, lastName, email, mobile])


    const saveClickHandler = async (e: React.FormEvent<any>) => {
        e.preventDefault();

        // todo: show error
        if (shop === "" || firstName === "" || lastName === "" || email === "" || mobile === "") return;

        const { data, status, errorMessage } = await createCustomer(shop, firstName, lastName, email, mobile);

        // console.log({ data, status, errorMessage });

        if (status === 201) {
            // hide modal
            dispatch(hideModal());

            // todo: refresh customer list
        }

        else if (errorMessage) alert(errorMessage)
        else alert(`[save customer] Something went wrong [status: ${status}]`)
    };

    const fetchShops = async (page: number) => {
        const { data, status, errorMessage } = await getShops(page);

        if (status === 200) {
            // @ts-ignore
            const preparedData = data.results.map(item => ({ name: item.name, value: item.slug }))

            setShopList(preparedData);
        }
        else alert(`[fetchShops] Something went wrong [status: ${status}]`)
    };

    // fetch shop list when component mounts
    useEffect(() => {
        fetchShops(1);
    }, [])


    return (
        <div className='row' style={{ backgroundColor: '' }}>
            <form
                onSubmit={saveClickHandler}
                noValidate className='form'>
                <div className='card-body border-top p-9' style={{ backgroundColor: '' }}>

                    {/* shop select */}
                    {shopList.length > 0 && (
                        <div className='row mb-6'>
                            <label className='col-md-3 col-form-label required fw-bold fs-6'>Shop</label>

                            <div className='col-md-9'>
                                <div className='row'>
                                    <div className='col-lg-12 fv-row'>
                                        <SelectSearch
                                            options={shopList}
                                            value={shop}
                                            // @ts-ignore
                                            name='shop'
                                            // @ts-ignore
                                            onChange={v => setShop(v)}
                                            // search={true}
                                            placeholder='Select Shop' />
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}
                    {/* end: shop select */}

                    {/* first name */}
                    <div className='row mb-6'>
                        <label className='col-md-3 col-form-label required fw-bold fs-6'>First Name</label>

                        <div className='col-md-9'>
                            <div className='row'>
                                <div className='col-lg-12 fv-row'>
                                    <input
                                        type='text'
                                        className='form-control form-control-lg form-control-solid mb-3 mb-lg-0'
                                        placeholder='First Name'
                                        value={firstName}
                                        onChange={e => setFirstName(e.target.value)}
                                    />
                                </div>

                            </div>
                        </div>
                    </div>
                    {/* end: first name */}


                    {/* last name */}
                    <div className='row mb-6'>
                        <label className='col-md-3 col-form-label required fw-bold fs-6'>Last Name</label>

                        <div className='col-md-9'>
                            <div className='row'>
                                <div className='col-lg-12 fv-row'>
                                    <input
                                        type='text'
                                        className='form-control form-control-lg form-control-solid mb-3 mb-lg-0'
                                        placeholder='Last Name'
                                        value={lastName}
                                        onChange={e => setLastName(e.target.value)}
                                    />
                                </div>

                            </div>
                        </div>
                    </div>
                    {/* end: last name */}


                    {/* email */}
                    <div className='row mb-6'>
                        <label className='col-md-3 col-form-label required fw-bold fs-6'>Email</label>

                        <div className='col-md-9'>
                            <div className='row'>
                                <div className='col-lg-12 fv-row'>
                                    <input
                                        type='text'
                                        className='form-control form-control-lg form-control-solid mb-3 mb-lg-0'
                                        placeholder='Email'
                                        value={email}
                                        onChange={e => setEmail(e.target.value)}
                                    />
                                </div>

                            </div>
                        </div>
                    </div>
                    {/* end: email */}


                    {/* phone */}
                    <div className='row mb-6'>
                        <label className='col-md-3 col-form-label required fw-bold fs-6'>Phone Number</label>

                        <div className='col-md-9'>
                            <div className='row'>
                                <div className='col-lg-12 fv-row'>
                                    <input
                                        type='text'
                                        className='form-control form-control-lg form-control-solid mb-3 mb-lg-0'
                                        placeholder='Phone Number'
                                        value={mobile}
                                        onChange={e => setMobile(e.target.value)}
                                    />
                                </div>


                            </div>
                        </div>
                    </div>
                    {/* end: phone */}

                    {/* submit form btn */}
                    <div className="row mt-10 border-top m-0" style={{ backgroundColor: '' }}>
                        <div className='p-0 d-flex justify-content-end' style={{ backgroundColor: '' }}>
                            <button
                                type="submit"
                                disabled={!saveButtonEnabled}
                                className='btn btn-sm btn-primary px-12'>
                                Save
                            </button>
                        </div>
                    </div>
                    {/* end: submit form btn */}

                </div>

            </form>
        </div>
    )
}
