import React, { useEffect, useState } from 'react';
import Card from '../../../components/Card'

import { filterCustomer, getCustomerList, deleteCustomer } from "../../../api/customerAPI";

interface ICustomer {
    id: number
    firstName: string
    lastName: string
    email: string
    mobile: string
    shop?: number
}

interface ICustomerProps extends ICustomer {
    // button/checkbox click handlers
    checkHandler?: (e: React.FormEvent<HTMLButtonElement>, id: number) => void
    editHandler?: (e: React.FormEvent<HTMLButtonElement>, id: number) => void
    deleteHandler?: (e: React.FormEvent<HTMLButtonElement>, id: number) => void
}


const CustomerListItem: React.FC<ICustomerProps> = ({ id, firstName, lastName, email, mobile, checkHandler = null, editHandler = null, deleteHandler = null }) => (
    <div className="row border-bottom /*border-dark*/ cursor-pointer mt-2 p-2" style={{ backgroundColor: '', height: 50 }}>
        <div className="d-flex align-items-center h-100 p-0" style={{ backgroundColor: '' }}>
            {/* checkbox */}
            <div style={{ width: 30, backgroundColor: '', marginRight: 10 }}>
                <input className="form-check-input" type="checkbox" />
            </div>

            {/* shop name */}
            <div style={{ flex: 1, backgroundColor: '', marginRight: 10 }}>{firstName} {lastName}</div>
            <div style={{ flex: 1, backgroundColor: '', marginRight: 10 }}>{email}</div>
            <div style={{ flex: 1, backgroundColor: '', marginRight: 10 }}>{mobile}</div>

            {/* control buttons */}
            <div className="d-flex justify-content-end" style={{ width: 85, backgroundColor: '' }}>

                {/* edit button */}
                <button
                    onClick={e => editHandler ? editHandler(e, id) : e.preventDefault()}
                    className="btn btn-sm me-2 px-3"
                    style={{ backgroundColor: '' }}>
                    < i className="bi bi-pencil"></i>
                </button>

                {/* delete button */}
                <button
                    onClick={e => deleteHandler ? deleteHandler(e, id) : e.preventDefault()}
                    className="btn btn-sm px-3"
                    style={{ backgroundColor: '' }}>
                    < i className="bi bi-trash"></i>
                </button>

            </div>
            {/* end: control buttons */}

        </div>
    </div>
);


export default function CustomerList() {

    const [customers, setCustomers] = useState<ICustomer[]>([]);

    const fetchCustomers = async () => {
        // todo: use filterCustomer() with shop slug
        const { data, status, errorMessage } = await getCustomerList()

        if (status === 200) {
            // @ts-ignore
            const preparedCustomers = data.results.map(c => ({
                ...c,
                firstName: c.first_name,
                lastName: c.last_name,
            }))

            // setCustomers(data.results)
            setCustomers(preparedCustomers)
        }
        else alert(`Something went wrong [status: ${status}]`)
    };


    const deleteCustomerHandler = async (e: React.FormEvent<HTMLButtonElement>, id: number) => {
        e.preventDefault()
        const confirmDelete = window.confirm(`Delete Customer '${customers.filter(item => item.id === id)[0].firstName}'?`);
        if (!confirmDelete) return;

        const { status } = await deleteCustomer(id)

        if (status === 204) {
            fetchCustomers()
        }
        else alert(`Something went wrong [status: ${status}]`)
    };


    useEffect(() => {
        fetchCustomers()
    }, [])

    return (
        <Card cardHeading="Customer List">
            {/* <pre>{JSON.stringify(customers, null, 4)}</pre> */}

            {/* list heading */}
            <div className="row p-2" style={{ backgroundColor: '', borderBottom: '1px solid #cfcfcf', height: 50 }}>
                <div className="d-flex align-items-center h-100 p-0" style={{ backgroundColor: '' }}>

                    {/* todo: add checkbox to select all items */}
                    <div style={{ width: 30, backgroundColor: '', marginRight: 10 }}>
                    </div>

                    <div
                        style={{ flex: 1, backgroundColor: '', marginRight: 10, fontWeight: 600 }}>
                        Customer Name
                    </div>

                    <div
                        style={{ flex: 1, backgroundColor: '', marginRight: 10, fontWeight: 600 }}>
                        Email
                    </div>

                    <div
                        style={{ flex: 1, backgroundColor: '', marginRight: 10, fontWeight: 600 }}>
                        Phone
                    </div>

                    <div
                        className="d-flex justify-content-end"
                        style={{ width: 85, backgroundColor: '' }}>
                    </div>

                </div>
            </div>
            {/* end: list heading */}

            {customers.map(c => (
                <CustomerListItem
                    key={c.id}
                    id={c.id}
                    firstName={c.firstName}
                    lastName={c.lastName}
                    email={c.email}
                    mobile={c.mobile}

                    deleteHandler={deleteCustomerHandler}
                />
            ))}
        </Card>
    )
}
