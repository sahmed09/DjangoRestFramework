import { PageLink } from '../../../_metronic/layout/core'

export const profileSubmenu: Array<PageLink> = [
  {
    title: 'Overview',
    path: '/boilerplate/overview',
    isActive: true,
  },
  {
    title: 'Separator',
    path: '/boilerplate/overview',
    isActive: true,
    isSeparator: true,
  },
  {
    title: 'Account',
    path: '/boilerplate/account',
    isActive: false,
  },
  {
    title: 'Account',
    path: '/boilerplate/account',
    isActive: false,
    isSeparator: true,
  },
  {
    title: 'Settings',
    path: '/boilerplate/settings',
    isActive: false,
  },
  {
    title: 'Settings',
    path: '/boilerplate/settings',
    isActive: false,
    isSeparator: true,
  },
]
