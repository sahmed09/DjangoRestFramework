import React from 'react'
import { Redirect, Route, Switch } from 'react-router-dom'
import { PageLink, PageTitle } from '../../../_metronic/layout/core'
import { Overview } from './components/Overview'
import { Projects } from './components/Projects'
import { Campaigns } from './components/Campaigns'
import { Documents } from './components/Documents'
import { Connections } from './components/Connections'
import { BoilerplateHeader } from './BoilerplateHeader'

const profileBreadCrumbs: Array<PageLink> = [
  // Boilerplate root
  {
    title: 'Boilerplate',
    path: '/boilerplate/overview',
    isSeparator: false,
    isActive: false,
  },

  // separator (-)
  {
    title: '',
    path: '',
    isSeparator: true,
    isActive: false,
  },
]

const BoilerplatePage: React.FC = () => {
  return (
    <>
      {/* page header tabs (sections) */}
      <BoilerplateHeader />

      {/* page sections (tabs) as route */}
      <Switch>
        <Route path='/boilerplate/overview'>
          <PageTitle breadcrumbs={profileBreadCrumbs}>Overview</PageTitle>
          <Overview />
        </Route>

        <Route path='/boilerplate/projects'>
          <PageTitle breadcrumbs={profileBreadCrumbs}>Projects</PageTitle>
          <Projects />
        </Route>

        <Route path='/boilerplate/campaigns'>
          <PageTitle breadcrumbs={profileBreadCrumbs}>Campaigns</PageTitle>
          <Campaigns />
        </Route>

        <Route path='/boilerplate/documents'>
          <PageTitle breadcrumbs={profileBreadCrumbs}>Documents</PageTitle>
          <Documents />
        </Route>

        <Route path='/boilerplate/connections'>
          <PageTitle breadcrumbs={profileBreadCrumbs}>Connections</PageTitle>
          <Connections />
        </Route>


        {/* redirects for this page */}
        <Redirect from='/boilerplate' exact={true} to='/boilerplate/overview' />
        <Redirect to='/boilerplate/overview' />
      </Switch>
      {/* end: page sections (tabs) as route */}

    </>
  )
}

export default BoilerplatePage
