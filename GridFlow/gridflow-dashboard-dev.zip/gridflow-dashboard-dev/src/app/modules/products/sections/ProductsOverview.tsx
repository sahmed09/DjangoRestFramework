import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { useHistory } from 'react-router';
import ListItem from '../../../components/ListItem'
import { getProducts, setProductPage } from '../../../redux/slices/productSlice';
import { AppState } from '../../../redux/store';
import Pagination from "../../../components/Pagination";
import { deleteProduct } from '../../../api/productAPI';
import { Link } from 'react-router-dom';

export function ProductsOverview() {

  const history = useHistory()

  const { products, hasPrevious, hasNext, error, page } = useSelector((state: AppState) => state.product);
  const dispatch = useDispatch();


  // useEffect(() => {
  //   if (products.length === 0) dispatch(getProducts())
  // }, [])



  // ******************************************************
  // end: pagination handlers

  useEffect(() => {
    console.log('Category > useEffect()');

    // if (categories.length > 0) return;

    console.log('fetching categories | page : ', page);
    dispatch(getProducts(page))

  }, [page]);

  const { search } = history.location;

  useEffect(() => {

    const queryString = new URLSearchParams(search);

    const pageNumber = queryString.get('page');
    if (!pageNumber) return;

    const pn = parseInt(pageNumber);
    if (isNaN(pn)) return;

    dispatch(setProductPage(pn));

  }, [search])



  // pagination handlers
  // todo: solve double click issue
  const previousClickHandler = (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
    e.preventDefault();
    // console.log('previous clicked');

    if (page > 1) {
      dispatch(setProductPage(page - 1));
      history.push({ search: `?page=${page - 1}` })
    }
  };

  const nextClickHandler = (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
    e.preventDefault();
    // console.log('next clicked');

    dispatch(setProductPage(page + 1));
    history.push({ search: `?page=${page + 1}` })
  };
  // end: pagination handlers
  // ******************************************************

  const editClickHandler = (e: React.FormEvent<HTMLButtonElement>, id: string | number) => {
    e.preventDefault();

    console.log('edit clicked : ', id);

    history.push({
      pathname: "/products/" + id + "/update",
      state: {
        update: true,
        passedData: products.filter(product => product.id === id)[0],
      }
    });
  }


  const deleteClickHandler = async (e: React.FormEvent<HTMLButtonElement>, id: string | number) => {
    e.preventDefault();

    console.log('delete clicked : ', id);

    // todo: replace with modal
    const confirmDelete = window.confirm(`Delete Product '${products.filter(product => product.id === id)[0].name}'?`);
    // const confirmDelete = window.confirm('Delete Product?');
    if (!confirmDelete) return;

    const { status, errorMessage } = await deleteProduct(id);

    if (status === 204) history.push("/products");
    else if (errorMessage) alert(errorMessage);
    else alert("Something wrong happened");
  }




  return (
    <div className='card mb-5 mb-xl-10' style={{ backgroundColor: '' }}>

      {/* card heading */}
      <div
        className='card-header border-0'>
        <div className='card-title m-0'>
          <h3 className='fw-bolder m-0'>Products</h3>
        </div>
      </div>
      {/* end: card heading */}


      {/* card body */}
      <div className="card-body border-top px-9 py-5">

        {/* todo: add list heading */}

        {/* product list */}
        {products.map((product, i) => (
          <Link to={"/products/" + product.id} style={{ color: "inherit" }}>

            <ListItem
              key={product.slug}
              id={product.id}
              // index
              columnOneValue={i + 1}

              columnTwoValue={product.name}
              columnTwoWidth="100%"

              columnThreeValue={product.category.name}

              columnFourValue={product.album || ' '}
              columnFourWidth={150}

              editButtonHandler={editClickHandler}
              deleteButtonHandler={deleteClickHandler}

            // isChecked={false}
            // todo: add checkbox handler
            />

          </Link>
        ))}
        {/* end: product list */}

        {/* list items */}
        {/* <ListItem
          columnOneValue='1'
          columnTwoValue='ABCD'
          columnThreeValue="Product One"
          columnFourValue="12"
          isChecked={false}
        /> */}
        {/* end: list items */}


        {/* pagination */}
        <Pagination
          infoText="Pagination"
          previous={hasPrevious}
          next={hasNext}

          previousClickHandler={previousClickHandler}
          nextClickHandler={nextClickHandler}
        />



      </div>
      {/* end: card body */}
    </div>
  )
}
