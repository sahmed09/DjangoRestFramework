import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { useLocation } from 'react-router'
import SelectSearch from 'react-select-search';
import { number } from 'yup';
import { IProduct } from '../../../../interfaces';
import { addProductStockQuantity, getProductAttributes, getProductDetails } from '../../../api/productAPI';
import { getShops } from '../../../api/shopAPI';
import { addProductToShopBranch, getShopBranches } from '../../../api/shopBranchAPI';
import ModalWrapper from '../../../components/ModalWrapper';
import { hideModal } from '../../../redux/slices/modalSlice';
import { disableCreateButton, enableCreateButton } from '../../../redux/slices/uiSlice';
import { AppState } from '../../../redux/store';

export default function ProductDetails() {
    const location = useLocation();
    const { pathname } = location;

    // save shop and branch slugs 
    const paths = pathname.split('/');
    // trailing slash returns last element as empty string
    const productId = paths[paths.length - 1] === "" ? paths[paths.length - 2] : paths[paths.length - 1];

    const dispatch = useDispatch();
    // const { visible } = useSelector((state: AppState) => state.modal)


    const [product, setProduct] = useState<IProduct | null>()

    const [modalVisible, setModalVisible] = useState(false)

    // modal form state/data
    const [shopList, setShopList] = useState([]);
    const [selectedShop, setSelectedShop] = useState('');

    const [branchList, setBranchList] = useState([]);
    const [selectedBranch, setSelectedBranch] = useState("");

    const [productPrice, setProductPrice] = useState('');
    const [productStockQuantity, setProductStockQuantity] = useState('');

    // form error messages
    const [priceErrorMessage, setPriceErrorMessage] = useState('');
    const [stockErrorMessage, setStockErrorMessage] = useState('');

    const resetFormState = () => {
        setShopList([]);
        setSelectedShop('');

        setBranchList([]);
        setSelectedBranch('');

        setProductPrice('');
        setProductStockQuantity('');

        setPriceErrorMessage('');
        setStockErrorMessage('');
    };


    // reset modal form state when component dismounts
    useEffect(() => {
        return () => { resetFormState() }
    }, [])


    const getProduct = async (id: number) => {
        const { data, status } = await getProductDetails(id)
        if (status !== 200) alert(`Something went wrong [status: ${status}]`)
        setProduct(data);

    };

    // get product details
    useEffect(() => {
        if (!productId || productId === "") return
        getProduct(parseInt(productId));
    }, [])


    // disable product create button on this page
    useEffect(() => {
        dispatch(disableCreateButton())
        return (() => { dispatch(enableCreateButton()) })
    }, [])

    // add button click handlerr
    const addClickHandler = () => {
        // dispatch(showModal());
        setModalVisible(true);
    };

    // modal close handler
    const handleClose = () => {
        // dispatch(hideModal());
        setModalVisible(false);
    };


    const getShopList = async () => {
        // todo: handle pagination
        const { data, status } = await getShops(1);
        // if (status === 200) setShopList(data.results);

        if (status === 200) {
            // @ts-ignore
            const preparedShopList = data.results.map(item => ({ name: item.name, value: item.slug }))
            setShopList(preparedShopList);
        }

        else console.log('Error in getShopList: ');

    };

    const getShopBranchList = async (shopSlug: string) => {
        const { data, status } = await getShopBranches(shopSlug);
        if (status === 200) {
            // @ts-ignore
            const preparedShopList = data.results.map(item => ({ name: item.name, value: item.slug }))
            setBranchList(preparedShopList);
        }

        else console.log('Error in getShopBranchList: ');
        console.log(status);
    };

    // fetch shop and branch list when modal is visible
    useEffect(() => {
        if (!modalVisible) return;
        getShopList();
    }, [modalVisible])


    useEffect(() => {
        if (!selectedShop || selectedShop === "") return;
        // fetch branch list
        getShopBranchList(selectedShop)

        // reset selected branch
        setSelectedBranch("")
    }, [selectedShop])


    // ***** debug *************************


    // ***** end: debug ********************


    // save button click handler
    const saveClickHandler = async (e: React.MouseEvent<HTMLElement>) => {
        e.preventDefault();
        // branch can be empty string (convert to null), but shop is a required field
        if (selectedShop === "") {
            alert("Invalid shop")
            return;
        }

        if (productPrice === "") {
            alert("Invalid Price");
            return;
        }

        if (productStockQuantity === "") {
            alert("Invalid Stock Quantity");
            return;
        }

        // error catching flag
        // experimental code, remove 
        let hasError = false;

        // convert price value from string to number (int)
        let parsedPrice;
        try {
            parsedPrice = parseInt(productPrice);
            setPriceErrorMessage('')

            if (parsedPrice <= 0) {
                setPriceErrorMessage("Price cannot be zero or negative number")

                hasError = true;
                // return;
            }

        } catch (error) {
            setPriceErrorMessage("Invalid Price Input")

            hasError = true;
            // return;
        }


        // convert stock amount from string to number (int)
        let parsedStockQuantity;
        try {
            parsedStockQuantity = parseInt(productStockQuantity);
            setStockErrorMessage('')

            if (parsedStockQuantity <= 0) {
                setStockErrorMessage("Stock quantity cannot be zero or negative number")

                hasError = true;
                // return;
            }

        } catch (error) {
            setStockErrorMessage("Invalid Stock quantity")

            hasError = true;
            // return;
        }

        if (hasError) return;

        // shop-branch-price api call
        // @ts-ignore
        const { status, errorMessage } = await addProductToShopBranch(product.slug, parsedPrice, selectedShop, selectedBranch)

        // todo: add shop-branch-parsedStockQuantity api call
        // @ts-ignore
        const { status: quantityStatus, errorMessage: quantityErrorMessage } = await addProductStockQuantity(product.slug, parsedStockQuantity, selectedShop, selectedBranch)

        if (status === 201 && quantityStatus === 201) {
            console.log('success');

            // hide modal
            setModalVisible(false);
            // reset modal form state
            resetFormState();
        }
        else if (errorMessage) alert(errorMessage)
        else if (quantityErrorMessage) alert(quantityErrorMessage)
        else alert(`Something went wrong [status: ${status}, ${quantityStatus}]`)
    };


    // ****** product attribute list *****************

    // interface ICategoryAttribute {
    //     id: number
    //     name: string
    //     slug: string
    // }

    // interface IProductAttribute {
    //     id?:number
    //     product: IProduct
    //     categoryAttribute: ICategoryAttribute
    // }

    interface IPreparedProductAttribute {
        id: number
        attributeChoiceId: number
        attributeName: string
        attributeNameSlug: string
        attributeValue: string
        attributeValueSlug: string
    }

    // @ts-ignore
    const [productAttributes, setProductAttributes] = useState<IPreparedProductAttribute[]>([]);

    const fetchProductAttributes = async () => {
        if (!product?.slug) return;
        const { data, status } = await getProductAttributes(product?.slug)

        if (status !== 200) {
            alert(`[fetchProductAttributes] error [status: ${status}]`)
            return
        }

        // @ts-ignore
        const preparedAttributes: IPreparedProductAttribute[] = data.results.map(attribute => ({
            id: attribute.id,
            attributeChoiceId: attribute.category_attribute_choices.id,
            attributeName: attribute.category_attribute_choices.category_attribute.attribute_name,
            attributeNameSlug: attribute.category_attribute_choices.category_attribute.slug,
            attributeValue: attribute.category_attribute_choices.attribute_value,
            attributeValueSlug: attribute.category_attribute_choices.slug,
        }))

        console.log(preparedAttributes);


        // setProductAttributes(data.results)
        setProductAttributes(preparedAttributes)
    };


    useEffect(() => {
        if (!product) return;

        fetchProductAttributes()
    }, [product])
    // ****** end: product attribute list ************


    // todo: redirect to 404?
    if (!product) return (
        <div className="card p-10 mb-5 mb-xl-10">
            <div className="row">
                <div className="col-sm-12 p-10">
                    No Product Found!
                </div>
            </div>
        </div>
    )


    return (
        <>
            {/* add product to shop/branch */}
            <ModalWrapper
                modalTitle="Add Product to Shop/Branch"
                modalWidth="mw-600px"
                show={modalVisible}
                handleClose={handleClose}>

                {/* add to shop/branch form */}
                <div className="d-flex flex-column align-items-center" style={{ height: 320, backgroundColor: "", overflowY: 'auto', overflowX: 'hidden' }}>
                    <div style={{ flex: 1, width: "100%", backgroundColor: '' }}>
                        {/* shop select area */}
                        <div className="row mb-5 w-100" style={{ backgroundColor: "" }}>
                            <label
                                style={{ backgroundColor: "" }}
                                htmlFor="shop"
                                className='col-md-2 col-form-label required fw-bold fs-6'>
                                Shop
                            </label>

                            <div className='col-md-10' style={{ backgroundColor: '' }}>
                                <div className='row'>
                                    <div className='col-lg-12' style={{}}>
                                        <SelectSearch
                                            options={shopList}
                                            value={selectedShop}
                                            // @ts-ignore
                                            name="shop"
                                            // @ts-ignore
                                            onChange={v => setSelectedShop(v)}
                                            // search={true}
                                            placeholder='Choose Shop' />

                                    </div>
                                </div>
                            </div>
                        </div>
                        {/* end: shop select area */}

                        {/* shop branch select area */}
                        {branchList.length > 0 && (
                            <div className="row mb-5 w-100" style={{ backgroundColor: "" }}>
                                <label
                                    style={{ backgroundColor: "" }}
                                    htmlFor="branch"
                                    className='col-md-2 col-form-label fw-bold fs-6'>
                                    Branch
                                </label>

                                <div className='col-md-10' style={{ backgroundColor: '' }}>
                                    <div className='row'>
                                        <div className='col-lg-12' style={{}}>
                                            <SelectSearch
                                                options={branchList}
                                                value={selectedBranch}
                                                // @ts-ignore
                                                name="branch"
                                                // @ts-ignore
                                                onChange={v => setSelectedBranch(v)}
                                                // search={true}
                                                placeholder='Choose Branch' />

                                        </div>
                                    </div>
                                </div>
                            </div>
                        )}
                        {/* end: shop branch select area */}


                        {/* price input area */}
                        <div className="row mb-5 w-100" style={{ backgroundColor: "" }}>
                            <label
                                style={{ backgroundColor: "" }}
                                htmlFor="price"
                                className='col-md-2 col-form-label required fw-bold fs-6'>
                                Product Price
                            </label>

                            <div className='col-md-10' style={{ backgroundColor: '' }}>
                                <div className='row'>
                                    <div className='col-sm-12' style={{}}>
                                        <input
                                            name="price"
                                            className='form-control form-control-lg form-control-solid mb-3 mb-lg-0'
                                            type="number"
                                            min="0"
                                            placeholder="Product Price"
                                            onChange={e => setProductPrice(e.target.value)}
                                            value={productPrice}
                                        />

                                    </div>
                                </div>

                                {/* price error message area */}
                                {priceErrorMessage && priceErrorMessage.length > 0 && (
                                    <div className="row mb-5" style={{ backgroundColor: "" }}>
                                        <div className="col-sm-12 text-danger">{priceErrorMessage}</div>
                                    </div>
                                )}
                                {/* end: price error message area */}

                            </div>
                        </div>
                        {/* end: price input area */}

                        {/* stock quantity area */}
                        <div className="row mb-5 w-100" style={{ backgroundColor: "" }}>
                            <label
                                style={{ backgroundColor: "" }}
                                htmlFor="stock"
                                className='col-md-2 col-form-label required fw-bold fs-6'>
                                Stock Quantity
                            </label>

                            <div className='col-md-10' style={{ backgroundColor: '' }}>
                                <div className='row'>
                                    <div className='col-sm-12' style={{}}>
                                        <input
                                            name="stock"
                                            className='form-control form-control-lg form-control-solid mb-3 mb-lg-0'
                                            type="number"
                                            min="0"
                                            placeholder="Stock Quantity"
                                            onChange={e => setProductStockQuantity(e.target.value)}
                                            value={productStockQuantity} />

                                    </div>
                                </div>

                                {/* stock quantity error message area */}
                                {stockErrorMessage && stockErrorMessage.length > 0 && (
                                    <div className="row mb-5" style={{ backgroundColor: "" }}>
                                        <div className="col-sm-12 text-danger">{stockErrorMessage}</div>
                                    </div>
                                )}
                                {/* end: stock quantity error message area */}

                            </div>
                        </div>
                        {/* end: stock quantity area */}



                    </div>


                    {/* close modal & submit button area */}
                    <div className="row py-5 w-100" style={{ backgroundColor: "" }}>
                        <div className="d-flex justify-content-end" style={{ backgroundColor: "" }}>

                            {/* close modal button */}
                            <button
                                className="btn btn-outline-dark btn-sm me-5"
                                onClick={() => setModalVisible(false)}>
                                Close
                            </button>
                            {/* end: close modal button */}

                            {/* save button */}
                            <button
                                disabled={selectedShop.length === 0 || productPrice.length === 0 || productStockQuantity.length === 0}
                                // onClick={e => e.preventDefault()}
                                onClick={saveClickHandler}
                                className="btn btn-primary btn-sm">
                                Save
                            </button>
                            {/* end: save button */}

                        </div>
                    </div>
                    {/* end: close modal & submit button area */}

                </div>
                {/* end: add to shop/branch form */}

            </ModalWrapper>
            {/* end: add product to shop/branch */}


            <div className="card p-10 mb-5 mb-xl-10">
                {/* heading area */}
                <div className="row" style={{ backgroundColor: '' }}>
                    <div className="col-md-9" style={{ backgroundColor: '' }}>
                        <h2>{product.name}</h2>
                    </div>

                    <div className="col-md-3 d-flex justify-content-end" style={{ backgroundColor: '' }}>
                        <button
                            onClick={addClickHandler}
                            className="btn btn-primary btn-sm px-5">Add to Shop</button>
                    </div>
                </div>
                {/* end: heading area */}


                <div className="row mt-5">
                    <div className="col-md-12"><strong>Brand: </strong>{product?.brand?.name}</div>
                </div>

                <div className="row mt-2">
                    <div className="col-md-12"><strong>Category: </strong>{product?.category?.name}</div>
                </div>

                {productAttributes.length > 0 && (
                    <div className="row mt-6">
                        <div className="row">
                            <div className="col-sm-12"><h4>Product Attribute Values</h4></div>
                        </div>

                        {productAttributes.map(attr => (
                            <div className="row my-2" style={{ backgroundColor: '' }}>
                                <div className="col-md-12"><strong>{attr.attributeName}: </strong>{attr.attributeValue}</div>
                            </div>
                        ))}

                    </div>
                )}

            </div>
        </>
    )
}
