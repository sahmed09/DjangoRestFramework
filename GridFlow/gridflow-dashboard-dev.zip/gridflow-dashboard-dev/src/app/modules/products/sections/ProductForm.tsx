import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';

import { getBrands } from '../../../redux/slices/brandSlice';
import { getCategories } from '../../../redux/slices/categorySlice';
import { getAlbums } from '../../../redux/slices/albumSlice';

import { AppState } from '../../../redux/store';
import { createProduct, updateProduct } from '../../../api/productAPI';
import { useHistory } from 'react-router';
import { hideModal } from '../../../redux/slices/modalSlice';
import { disableCreateButton, enableCreateButton } from '../../../redux/slices/uiSlice';
import SelectSearch, { SelectedOptionValue } from 'react-select-search';
import { getCategoryAttributeNames, searchCategory } from '../../../api/categoryAPI';
import { searchBrand } from '../../../api/brandAPI';
import { IAttribute, ISelectOptions } from '../../../../interfaces';
import SearchableSelect from '../../../components/SearchableSelect';
import ProductAttributeSelect from '../components/ProductAttributeSelect';
import { addMultipleProductAttributeValues } from '../../../api/categoryAttributeAPI';


export default function ProductForm() {

    const history = useHistory();

    const brandState = useSelector((state: AppState) => state.brand);
    const categoryState = useSelector((state: AppState) => state.category);
    // const albumState = useSelector((state: AppState) => state.album);


    const dispatch = useDispatch();

    // get brand, category list, albums, and other required data when page loads
    useEffect(() => {
        dispatch(getBrands())
        dispatch(getCategories())
        dispatch(getAlbums())
    }, [])


    // disable create button in this page (update operation)
    useEffect(() => {
        if (update) dispatch(disableCreateButton())
        return () => {
            dispatch(enableCreateButton())
        }
    }, []);
    // end: disable create button in this page (update operation)


    // form input field values
    const [productName, setProductName] = useState('');

    // const [selectedBrandID, setSelectedBrandID] = useState<string | null>(null);
    // const [selectedCategoryID, setSelectedCategoryID] = useState<string | null>(null);
    // const [selectedAlbumID, setSelectedAlbumID] = useState<string | null>(null);

    // dropdown select options
    const [brandSelectOptions, setBrandSelectOptions] = useState<ISelectOptions[]>([]);
    const [selectedBrandValue, setSelectedBrandValue] = useState("");

    const [categorySelectOptions, setCategorySelectOptions] = useState<ISelectOptions[]>([]);
    const [selectedCategoryValue, setSelectedCategoryValue] = useState("");

    // array of category attribute form value
    const [categoryAttributeNames, setCategoryAttributeNames] = useState<any[]>([]);


    // update operation

    const { state } = history.location;

    // @ts-ignore
    const { update, passedData } = state ? state : {};


    // update form values for update operatino
    useEffect(() => {
        console.log({ update, passedData });

        if (!update || !passedData) return;

        setProductName(passedData.name);

        const _brand = [passedData.brand]
        // @ts-ignore
        setSelectedBrandValue(_brand.slug);

        const _cat = [passedData.category]
        // @ts-ignore
        setSelectedCategoryValue(_cat.slug);

        // const _album = [passedData.album]
        // @ts-ignore
        // setSelectedAlbum(_album);

        // todo: add attribute values
    }, [])

    // end: update operation


    // debug 
    useEffect(() => {
        console.log("categoryAttributeNames: ");
        console.log(categoryAttributeNames);

    }, [categoryAttributeNames])



    // @ts-ignore
    const [attrOptions, setAttrOptions] = useState([])


    // ************** BRAND *******************

    // update brand select options
    useEffect(() => {
        // setBrandSelectOptions(mappedBrands)
        setBrandSelectOptions(brandState.brands.map(cat => ({ name: cat.name, value: cat.slug })))
    }, [brandState])


    const handleBrandSelectSearch = async (query: string) => {
        // todo: use settimeout/any other throttling mechanism to avoid overloading the server

        if (query.length < 2) return;

        const { status, data } = await searchBrand(query);

        if (data.count > 0) {
            // prepare results
            //@ts-ignore
            const preparedBrandSelectOptions = data.results.map(item => ({ name: item.name, value: item.slug }))

            // set select options
            // setBrandSelectOptions(data.results)
            setBrandSelectOptions(preparedBrandSelectOptions)

            setSelectedBrandValue(data.results[0].slug)
        }

    };


    const handleBrandSelectOnChange = (value: string) => {
        setSelectedBrandValue(value);
    };


    // const [categoryAttributeNames, setCategoryAttributeNames] = useState<any[]>([]);


    // update category select options
    useEffect(() => {
        // if (categoryState.categories.length === 0) return;
        setCategorySelectOptions(categoryState.categories.map(item => ({ name: item.name, value: item.slug })));
    }, [categoryState])


    // search handler
    const handleCategorySelectSearch = async (query: string) => {
        // todo: use settimeout/any other throttling mechanism to avoid overloading the server
        if (query.length < 2) return;

        const { status, data } = await searchCategory(query);

        if (status !== 200) return;

        if (data.count > 0) {
            // prepare results
            // @ts-ignore
            const preparedCategories = data.results.map(item => ({ name: item.name, value: item.slug }))

            // set select options
            setCategorySelectOptions(preparedCategories)

            // set first item as selected value
            setSelectedCategoryValue(data.results[0].slug)
        }
    };


    // category select handler
    const handleCategorySelectOnChange = async (value: string) => {
        setSelectedCategoryValue(value);

        // fetch category attribute names
        // todo: use throttle
        const { status, data } = await getCategoryAttributeNames(value);

        if (status !== 200) return;

        // prepare response
        // @ts-ignore
        // const preparedAttributeNames = data.map(item => ({ name: item.attribute_name, slug: item.slug }));
        const preparedAttributeNames = data.map(item => ({ name: item.attribute_name, slug: item.slug, value: '' }));

        setCategoryAttributeNames(preparedAttributeNames);
    };

    // ********** end: category ***************

    const _attrValChangeHandler = (val: SelectedOptionValue | SelectedOptionValue[], id: string) => {
        console.log('_attrValChangeHandler()');
        console.log({ val, id });
    }


    const _attrValSearchHandler = (query: string, id: string) => {
        console.log('_attrValSearchHandler()');
        if (!query || query === "") return

        console.log({ query, id });
    }

    const _simpleAttrValSearchHandler = (q: string) => {
        console.log('_simpleAttrValSearchHandler()');

        console.log(q);


    };





    const attributeValueChangeHandler = (e: React.ChangeEvent<HTMLInputElement>, id: string) => {
        // get the attribute index and the attr object
        // const attrIndex = categoryAttributeNames.filter(item => item.slug === id)[0];
        const attrIndex = categoryAttributeNames.findIndex(item => item.slug === id);
        const attr = categoryAttributeNames[attrIndex];

        // update attr value
        const updatedAttr = {
            ...attr,
            value: e.target.value,
        }

        // update attributes list
        const _beforeItems = categoryAttributeNames.slice(0, attrIndex);
        const _afterItems = categoryAttributeNames.slice(attrIndex + 1);

        const updatedCategoryAttributeNames = [
            ..._beforeItems,
            updatedAttr,
            ..._afterItems,
        ];

        // update state
        setCategoryAttributeNames(updatedCategoryAttributeNames);

    };


    // *********** attr value **************************

    /*
    
    api payload format: 

    {
        "data": [
            {
                "category_attribute": {"slug": "frostability"},
                "category_attribute_choices": {"slug": "non-frost"}
            },
            {
                "category_attribute": {"slug": "no-of-window"},
                "category_attribute_choices": {"slug": "2"}
            }
        ]
    }
    
    */

    const valueSelectHandler = (
        id: string | number,
        attribute: IAttribute,
        value: string
    ) => {
        console.log('value selected: ');
        console.log({ id, attribute, value });

        /*
        categoryAttributeNames is an array : [
            {
                name: "No of doors",
                slug: "no-of-doors",
                value: "",
            },
        ]

        */

        // filter attribute by name slug
        const attrIndex = categoryAttributeNames.findIndex(item => item.slug === attribute.slug);
        const attr = categoryAttributeNames[attrIndex];

        // set attr value
        const updatedAttr = {
            ...attr,
            value,
        }

        const _beforeItems = categoryAttributeNames.slice(0, attrIndex);
        const _afterItems = categoryAttributeNames.slice(attrIndex + 1);

        // create new attrs array
        const newArray = [
            ..._beforeItems,
            updatedAttr,
            ..._afterItems,
        ];

        // set attribute names
        setCategoryAttributeNames(newArray);

    };


    // *********** end: attr value *********************


    // event handlers
    const formSubmitHandler = async (e: React.FormEvent<any>) => {
        e.preventDefault();


        // **********************************
        // **********************************
        // const preparedAttrs = categoryAttributeNames.map(attr => ({
        //     attrSlug: attr.slug,
        //     valSlug: attr.value
        // }))

        // console.log("preparedAttrs :: ");
        // console.log(preparedAttrs);
        

        // return
        // **********************************
        // **********************************

        // todo: show error alert
        // if (!productName || !selectedBrandValue || !selectedCategoryID || !selectedAlbumID) return;
        if (!productName || !selectedBrandValue || !selectedCategoryValue) return;


        // update
        if (update) {
            console.log('updating : ', passedData.id);

            const { status, errorMessage } = await updateProduct(passedData.id, productName, selectedBrandValue, selectedCategoryValue);

            if (status === 200) history.push("/products");

            // todo: show error message
            else if (errorMessage) alert(errorMessage);
            else alert("Something went wrong");

            return;
        }

        const { status, data, errorMessage } = await createProduct(productName, selectedBrandValue, selectedCategoryValue)

        console.log('product save resp :');
        console.log({ status, data, errorMessage });
        
        if (status === 201) {

            
            // history.push("/products");

            // **************************************
            // **************************************
            // save attribute values

            // product slug is required
            const productSlug = data.slug;

            const preparedAttrs = categoryAttributeNames.map(attr => ({
                attrSlug: attr.slug,
                valSlug: attr.value
            }))

            const {data: attrData, status: attrStatus, errorMessage: attrErrorMessage} =  await addMultipleProductAttributeValues(productSlug, preparedAttrs)

            console.log("Product attribute response: ");
            console.log({attrData, attrStatus, attrErrorMessage});

            // todo: check status before closing modal | show error message
            
            // **************************************
            // **************************************

            // close modal
            dispatch(hideModal());

            history.push("/products");

        }

    };






    return (
        <div className='row' style={{ backgroundColor: '' }}>

            <div className="col-lg-12">
                <div className='card mb-5 mb-xl-10' style={{ backgroundColor: '' }}>
                    <div
                        className='card-header border-0'>
                        <div className='card-title m-0'>
                            <h3 className='fw-bolder m-0'>Add Product</h3>
                        </div>
                    </div>

                    <div className='row' style={{ backgroundColor: '' }}>
                        <form
                            noValidate className='form'>
                            <div className='card-body border-top p-9' style={{ backgroundColor: '' }}>

                                {/* product name */}
                                <div className='row mb-6'>
                                    <label className='col-lg-2 col-form-label required fw-bold fs-6'>Name</label>

                                    <div className='col-lg-10'>
                                        <div className='row'>
                                            <div className='col-lg-12 fv-row'>
                                                <input
                                                    type='text'
                                                    className='form-control form-control-lg form-control-solid mb-3 mb-lg-0'
                                                    placeholder='Product Name'
                                                    value={productName}
                                                    onChange={e => setProductName(e.target.value)}
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                {/* end: product name */}


                                {/* brand select */}
                                <div className='row mb-6'>

                                    <label htmlFor="brand" className='col-lg-2 col-form-label required fw-bold fs-6'>Brand</label>

                                    <div className='col-lg-10'>
                                        <div className='row'>
                                            <div className='col-lg-12'>

                                                {brandSelectOptions.length > 0 && <SelectSearch
                                                    //@ts-ignore
                                                    getOptions={handleBrandSelectSearch}
                                                    options={brandSelectOptions}
                                                    value={selectedBrandValue}
                                                    // @ts-ignore
                                                    onChange={handleBrandSelectOnChange}
                                                    search={true}
                                                    //@ts-ignore
                                                    name="brand"
                                                    placeholder="Choose Brand" />}

                                            </div>
                                        </div>
                                    </div>

                                </div>
                                {/* end: brand select */}


                                {/* category select */}
                                <div className='row mb-6'>

                                    <label htmlFor="brand" className='col-lg-2 col-form-label required fw-bold fs-6'>Category</label>

                                    <div className='col-lg-10'>
                                        <div className='row'>
                                            <div className='col-lg-12'>

                                                {categorySelectOptions.length > 0 && <SelectSearch
                                                    //@ts-ignore
                                                    getOptions={handleCategorySelectSearch}
                                                    options={categorySelectOptions}
                                                    value={selectedCategoryValue}
                                                    // @ts-ignore
                                                    onChange={handleCategorySelectOnChange}
                                                    search={true}
                                                    name="category"
                                                    placeholder="Choose Category" />}
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                {/* end: category select */}


                                {/* category attribute values - select search */}

                                {categoryAttributeNames.map(attr => (
                                    <ProductAttributeSelect
                                        key={attr.slug}
                                        id={attr.slug}
                                        attribute={attr}

                                        selectHandler={valueSelectHandler}
                                    />
                                ))}
                                {/* {categoryAttributeNames.map(attr => (
                                    <div className='row mb-6'>
                                        <label className='col-lg-2 col-form-label fw-bold fs-6'>{attr.name}</label>

                                        <div className='col-lg-10'>
                                            <div className='row'>
                                                <div className='col-lg-12 fv-row'>


                                                    <SelectSearch
                                                        //@ts-ignore
                                                        // getOptions={q => _attrValSearchHandler(q, attr.slug)}
                                                        // getOptions={_simpleAttrValSearchHandler}
                                                        // options={attrOptions}
                                                        // options={categoryAttributeNames}
                                                        // value={selectedCategoryValue}
                                                        // value={categoryAttributeNames.filter(item => item.slug === attr.slug)[0].value}
                                                        // @ts-ignore
                                                        name={attr.slug}
                                                        // onChange={v => _attrValChangeHandler(v, attr.slug)}
                                                        // search={true}
                                                        placeholder={'Choose ' + attr.name + ' value'} />


                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                ))} */}
                                {/* end: category attribute values - select search */}


                                {/* category specific attribute fields */}
                                {/* {categoryAttributeNames.map(attr => (
                                    <div className='row mb-6'>
                                        <label className='col-lg-2 col-form-label fw-bold fs-6'>{attr.name}</label>

                                        <div className='col-lg-10'>
                                            <div className='row'>
                                                <div className='col-lg-12 fv-row'>
                                                    <input
                                                        type='text'
                                                        className='form-control form-control-lg form-control-solid mb-3 mb-lg-0'
                                                        placeholder={attr.name + ' value'}
                                                        value={categoryAttributeNames.filter(item => item.slug === attr.slug)[0].value}
                                                        onChange={e => attributeValueChangeHandler(e, attr.slug)}
                                                    />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                ))} */}
                                {/* end: category specific attribute fields */}


                                {/* todo: add CREATE ALBUM option */}
                                {/* album select */}
                                {/* <div className='row mb-6'>

                                    <label htmlFor="brand" className='col-lg-2 col-form-label required fw-bold fs-6'>Album</label>

                                    <div className='col-lg-8'>
                                        <div className='row'>
                                            <div className='col-lg-12'>

                                                <Select
                                                    options={albumState.albums}
                                                    values={selectedAlbum}
                                                    name="album"
                                                    labelField="name"
                                                    valueField="name"
                                                    searchBy="name"
                                                    required
                                                    keepSelectedInList={false}
                                                    onChange={values => setSelectedAlbumID(values[0]?.name)}
                                                    className="form-control form-control-lg form-control-solid mb-3 mb-lg-0" />

                                            </div>
                                        </div>
                                    </div>

                                    <div className="col-lg-2">
                                        <button
                                            onClick={e => e.preventDefault()}
                                            className="btn btn-outline-primary btn-sm">
                                            Create Album
                                        </button>
                                    </div>

                                </div> */}
                                {/* end: album select */}


                                {/* submit form btn */}
                                <div className="row mt-10 border-top pt-9" style={{ backgroundColor: '' }}>
                                    <div className='col-lg-4'>
                                        <button
                                            className='btn btn-sm btn-primary me-3 px-12'
                                            onClick={formSubmitHandler}>
                                            Save
                                        </button>
                                    </div>
                                </div>
                                {/* end: submit form btn */}

                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    )
}
