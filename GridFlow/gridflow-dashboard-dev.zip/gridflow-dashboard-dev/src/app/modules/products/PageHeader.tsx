/* eslint-disable jsx-a11y/anchor-is-valid */
import React from 'react'
import { KTSVG, toAbsoluteUrl } from '../../../_metronic/helpers'
import { Link } from 'react-router-dom'
import { Dropdown1 } from '../../../_metronic/partials'
import { useLocation } from 'react-router-dom'

const PageHeader: React.FC = () => {
    const location = useLocation()

    return (
        <div className='card mb-5 mb-xl-10'>
            <div className='card-body pt-5 pb-0'>

                {/* page section tabs */}
                <div className='d-flex overflow-auto h-55px'>
                    <ul className='nav nav-stretch nav-line-tabs nav-line-tabs-2x border-transparent fs-5 fw-bolder flex-nowrap'>

                        {/* section tab */}
                        <li className='nav-item'>
                            <Link
                                className={
                                    `nav-link text-active-primary me-6 ` +
                                    (location.pathname === '/products/overview' && 'active')
                                }
                                to='/products/overview'>
                                Overview
                            </Link>
                        </li>
                        {/* end: section tab */}


                        {/* section tab */}
                        <li className='nav-item'>
                            <Link
                                className={
                                    `nav-link text-active-primary me-6 ` +
                                    (location.pathname === '/products/add' && 'active')
                                }
                                to='/products/add'>
                                Add Product
                            </Link>
                        </li>

                        {/* end: section tab */}

                    </ul>
                </div>
                {/* end: page section tabs */}

            </div>
        </div>
    )
}

export { PageHeader }
