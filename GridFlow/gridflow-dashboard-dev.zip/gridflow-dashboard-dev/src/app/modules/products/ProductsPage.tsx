import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Redirect, Route, Switch } from 'react-router-dom'
import { PageLink, PageTitle } from '../../../_metronic/layout/core'
import ModalWrapper from '../../components/ModalWrapper'
import { hideModal } from '../../redux/slices/modalSlice'
import { getProducts } from '../../redux/slices/productSlice'
import { disableCreateButton, enableCreateButton } from '../../redux/slices/uiSlice'
import { AppState } from '../../redux/store'
// import CategoryForm from '../categories/sections/CategoryForm'
import { PageHeader } from './PageHeader'
import ProductDetails from './sections/ProductDetails'
import ProductForm from './sections/ProductForm'
// import ProductForm from './sections/ProductForm'
import { ProductsOverview } from './sections/ProductsOverview'
// import { Overview } from './components/Overview'
// import { Projects } from './components/Projects'
// import { Campaigns } from './components/Campaigns'
// import { Documents } from './components/Documents'
// import { Connections } from './components/Connections'
// import { BoilerplateHeader } from './BoilerplateHeader'

const productsBreadCrumbs: Array<PageLink> = [
    // Boilerplate root
    {
        title: 'Products',
        path: '/products/overview',
        isSeparator: false,
        isActive: false,
    },

    // separator (-)
    {
        title: '',
        path: '',
        isSeparator: true,
        isActive: false,
    },
]

const ProductsPage: React.FC = () => {

    const dispatch = useDispatch();

    const { page } = useSelector((state: AppState) => state.product);


    const { createButtonEnabled } = useSelector((state: AppState) => state.uiState)
    const { visible, modalData } = useSelector((state: AppState) => state.modal)



    // disable create button in this page
    // useEffect(() => {
    //     dispatch(disableCreateButton())
    //     return () => {
    //         dispatch(enableCreateButton())
    //     }
    // }, []);
    // end: disable create button in this page


    const handleClose = () => {
        console.log('handleClose');
        dispatch(hideModal());

        // reload products
        dispatch(getProducts(page))
    };


    return (
        <>

            <ModalWrapper
                modalTitle="Create Category"
                handleClose={handleClose}
                show={visible}>

                <div className="" style={{ overflow: "auto" }}>
                    {/* <ProductForm /> */}
                    <ProductForm />
                </div>


            </ModalWrapper>

            {/* page header tabs (sections) */}
            {/* <PageHeader /> */}

            {/* page sections (tabs) as route */}
            <Switch>
                <Route path='/products/overview'>
                    <PageTitle breadcrumbs={productsBreadCrumbs}>Overview</PageTitle>
                    <ProductsOverview />
                </Route>

                <Route path='/products/add'>
                    <PageTitle breadcrumbs={productsBreadCrumbs}>Add Product</PageTitle>
                    {/* <ProductForm /> */}
                    <ProductForm />
                </Route>

                {/* product details page */}
                <Route path='/products/:id' exact={true}>
                    <PageTitle breadcrumbs={productsBreadCrumbs}>Product Details</PageTitle>
                    <ProductDetails />
                </Route>

                <Route path='/products/:id/update' exact={true}>
                    <PageTitle breadcrumbs={productsBreadCrumbs}>Update Product</PageTitle>
                    {/* <ProductForm /> */}
                    <ProductForm />
                </Route>

                {/* redirects for this page */}
                <Redirect from='/products' exact={true} to='/products/overview' />
                <Redirect to='/products/overview' />
            </Switch>
            {/* end: page sections (tabs) as route */}

        </>
    )
}

export default ProductsPage
