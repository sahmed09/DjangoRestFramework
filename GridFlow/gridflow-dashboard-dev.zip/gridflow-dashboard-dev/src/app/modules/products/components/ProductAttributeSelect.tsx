import React, { useEffect, useState } from 'react'
import SelectSearch from 'react-select-search'
import { IAttribute } from '../../../../interfaces'
import { getCategoryAttributeChoices } from '../../../api/categoryAttributeAPI'


export interface IProductAttributePropps {
    id: string | number
    attribute: IAttribute

    // selectHandler?: (e: React.FormEvent<HTMLButtonElement>, id: string, attribute: IAttribute, value: string) => void
    selectHandler?: (id: string, attribute: IAttribute, value: string) => void
}

const ProductAttributeSelect: React.FC<IProductAttributePropps> = ({ id, attribute, selectHandler }) => {


    const [attributeSelectOptions, setAttributeSelectOptions] = useState([])
    const [selectedValue, setSelectedValue] = useState('')


    const fetchAttributeValues = async () => {
        const { data, status } = await getCategoryAttributeChoices(attribute.slug)

        console.log({ data, status });

        if (status !== 200) {
            console.log(`fetchAttributeValues error`);
            return
        }

        // @ts-ignore
        const preparedData = data.results.map(item => ({ name: item.attribute_value, value: item.slug }))

        console.log({ preparedData });


        setAttributeSelectOptions(preparedData);

    };


    // fetch attribute values when component mounts
    useEffect(() => {
        if (!attribute.slug || attribute.slug === '') return
        fetchAttributeValues();
    }, [attribute])


    // ***** debug *********************************
    useEffect(() => {
        console.log({ selectedValue });

    }, [selectedValue])
    // ***** end: debug ****************************


    return (
        <div className='row mb-6'>
            <label className='col-lg-2 col-form-label fw-bold fs-6'>{attribute.name}</label>

            <div className='col-lg-10'>
                <div className='row'>
                    <div className='col-lg-12 fv-row'>


                        <SelectSearch
                            //@ts-ignore
                            // getOptions={q => _attrValSearchHandler(q, attribute.slug)}
                            // getOptions={_simpleAttrValSearchHandler}
                            options={attributeSelectOptions}
                            value={selectedValue}
                            // value={categoryAttributeNames.filter(item => item.slug === attribute.slug)[0].value}
                            // @ts-ignore
                            name={attribute.slug}
                            // @ts-ignore
                            // onChange={v => setSelectedValue(v)}
                            onChange={v => selectHandler(id, attribute, v)}
                            // search={true}
                            placeholder={'Choose ' + attribute.name + ' value'} />


                    </div>
                </div>
            </div>
        </div>
    )
}

export default ProductAttributeSelect