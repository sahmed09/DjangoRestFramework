/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable jsx-a11y/anchor-is-valid */
import React from 'react'
import { Modal } from 'react-bootstrap-v5'
import { KTSVG } from '../../_metronic/helpers'

type Props = {
    children: React.ReactNode
    modalTitle?: string
    show: boolean
    handleClose: () => void
    modalWidth?: string
    // style?: React.CSSProperties
}

const ModalWrapper: React.FC<Props> = ({ children, modalWidth = "mw-900px", modalTitle = null, show, handleClose }) => {


    return (
        <Modal
            tabIndex={-1}
            aria-hidden='true'
            dialogClassName={`modal-dialog modal-dialog-centered ${modalWidth}`}
            show={show}
            onHide={handleClose}>
            <div className='modal-content'>

                {/* modal header */}
                <div className='modal-header'>
                    <h2>{modalTitle}</h2>

                    <div className='btn btn-sm btn-icon btn-active-color-primary' onClick={handleClose}>
                        <KTSVG path='/media/icons/duotune/arrows/arr061.svg' className='svg-icon-1' />
                    </div>
                </div>
                {/* end: modal header */}

                {/* modal body */}
                <div className='modal-body py-lg-10 px-lg-10'>
                    {children}
                </div>
                {/* end: modal body */}

            </div>
        </Modal>
    )


}

export default ModalWrapper
