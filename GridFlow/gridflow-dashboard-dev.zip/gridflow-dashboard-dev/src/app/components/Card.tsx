import React from 'react'

interface ICardProps {
    cardHeading?: string
    children: React.ReactNode,
}

const Card: React.FC<ICardProps> = ({ cardHeading = null, children }) => {
    return (
        <div className='card mb-5 mb-xl-10' style={{ backgroundColor: '' }}>

            {/* card heading */}
            {cardHeading && (
                <div
                    className='card-header border-0'>
                    <div className='card-title m-0'>
                        <h3 className='fw-bolder m-0'>{cardHeading}</h3>
                    </div>
                </div>
            )}
            {/* end: card heading */}

            {/* card body */}
            <div className="card-body border-top px-9 py-5">
                {children}
            </div>
            {/* end: card body */}
        </div>
    )
}

export default Card;

