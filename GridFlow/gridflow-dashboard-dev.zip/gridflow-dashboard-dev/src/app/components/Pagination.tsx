import clsx from 'clsx';
import React from 'react'


interface InterfaceProps {
    infoText?: string,
    previous?: boolean,
    next?: boolean,

    // event handlers
    previousClickHandler: (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void,
    nextClickHandler: (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void,
}

const Pagination: React.FC<InterfaceProps> = ({ infoText = null, previous = false, next = false, previousClickHandler, nextClickHandler }) => {
    return (
        <div className='d-flex flex-stack flex-wrap pt-10'>
            {/* info */}
            {/* <div className='fs-6 fw-bold text-gray-700'>Showing 1 to 10 of 50 entries</div> */}
            <div className='fs-6 fw-bold text-gray-700'>{infoText}</div>
            {/* end: info */}

            <ul className='pagination'>
                {/* previous page button */}
                <li className={clsx('page-item previous', !previous && 'disabled')}>
                    {/* <a href='#' className='page-link'>
                        <i className='previous'></i>
                    </a> */}
                    <button
                        onClick={previousClickHandler}
                        className='page-link'>
                        <i className='previous'></i>
                    </button>
                </li>
                {/* end: previous page button */}

                {/* next button */}
                <li className={clsx('page-item next', !next && 'disabled')}>
                    {/* <a href='#' className='page-link'>
                        <i className='next'></i>
                    </a> */}

                    <button
                        onClick={nextClickHandler}
                        className='page-link'>
                        <i className='next'></i>
                    </button>
                </li>
                {/* end: next button */}
            </ul>
        </div>
    )
}


export default Pagination;
