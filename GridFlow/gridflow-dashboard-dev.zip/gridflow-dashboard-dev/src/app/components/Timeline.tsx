import React from 'react'

export interface ITimelineItem {
  label: string
  content?: string
  text?: string
  children?: React.ReactNode

  textClass?: string
}

export interface ITimelineProps {
  title?: string
  subtitle?: string
  timelineContent: ITimelineItem[]
}


const Timeline: React.FC<ITimelineProps> = ({ title = null, subtitle = null, timelineContent }) => {
  return (
    <div className="card timeline-content fw-mormal text-muted ps-3">
      {/* begin::Header */}
      <div className='card-header align-items-center border-0 mt-4'>
        <h3 className='card-title align-items-start flex-column'>
          <span className='fw-bolder mb-2 text-dark'>{title}</span>
          <span className='text-muted fw-bold fs-7'>{subtitle}</span>
        </h3>

      </div>
      {/* end::Header */}

      {/* begin::Body */}
      <div className='card-body pt-5'>
        {/* begin::Timeline */}
        <div className='timeline-label'>

          {timelineContent.map(({ label, content = null, text = null, children = null, textClass = "text-primary" }) => {

            // todo: refactor
            let _txt;

            if (children) {
              _txt = (
                <div className='timeline-content fw-bolder text-gray-800 ps-3'>
                  {children}
                </div>
              )
            } else if (text) {
              _txt = (
                <div className='fw-mormal timeline-content text-muted ps-3'>
                  {text}
                </div>
              )
            }
            else {
              _txt = (
                <div className='timeline-content d-flex'>
                  <span className='fw-bolder text-gray-800 ps-3'>{content}</span>
                </div>
              )
            }

            return (
              <div className='timeline-item'>
                {/* begin::Label */}
                <div className='timeline-label fw-bolder text-gray-800 fs-8'>{label}</div>
                {/* end::Label */}

                {/* begin::Badge */}
                <div className='timeline-badge'>
                  <i className={`fa fa-genderless fs-1 ${textClass}`}></i>
                </div>
                {/* end::Badge */}

                {/* text */}
                {_txt}
                {/* end:: text */}

              </div>
            )
          })}

        </div>
        {/* end::Timeline */}
      </div>
      {/* end: Card Body */}
    </div>
  )
}

export default Timeline
