import React from 'react'



interface CategoryAttrProps {
    // UI values
    columnOneValue?: string | number,
    columnTwoValue?: string | number,
    columnThreeValue?: string | number,
    columnFourValue?: string | number,

    // styles
    columnOneWidth?: string | number,
    columnTwoWidth?: string | number,
    columnThreeWidth?: string | number,
    columnFourWidth?: string | number,


    // controls
    showCheckbox?: boolean,
    isChecked?: boolean,

    // unique identifier
    id: string | number,

    // event handlers
    // todo: add checkEventHandler
    editButtonHandler: (e: React.FormEvent<HTMLButtonElement>, id: string | number) => void,
    deleteButtonHandler: (e: React.FormEvent<HTMLButtonElement>, id: string | number) => void,
}


const ListItem: React.FC<CategoryAttrProps> = ({
    columnOneValue = null,
    columnTwoValue = null,
    columnThreeValue = null,
    columnFourValue = null,

    // styles
    columnOneWidth = 50,
    columnTwoWidth = 50,
    columnThreeWidth = "100%",
    columnFourWidth = 150,

    // controls
    showCheckbox = true,
    isChecked = false,

    id,

    // event handlers
    editButtonHandler,
    deleteButtonHandler,
}) => {
    return (
        <div className="row border-bottom /*border-dark*/ cursor-pointer" style={{ backgroundColor: '', height: 50 }}>
            <div className="col-sm-12" style={{ backgroundColor: '' }}>

                <div className="d-flex align-items-center h-100 " style={{ backgroundColor: '' }}>
                    {/* checkbox */}
                    {showCheckbox && (<span style={{ backgroundColor: '' }}>
                        <input className="form-check-input" type="checkbox" checked={isChecked} />
                    </span>)}

                    {/* <span className="mx-2 ms-5" style={{ backgroundColor: '', width: 50 }}>{columnOneValue}</span> */}
                    {columnOneValue && <span className="mx-2 ms-5" style={{ backgroundColor: '', width: columnOneWidth }}>{columnOneValue}</span>}

                    {/* <span className="mx-2" style={{ backgroundColor: '', width: 50 }}>{columnTwoValue}</span> */}
                    {columnTwoValue && <span className="mx-2" style={{ backgroundColor: '', width: columnTwoWidth }}>{columnTwoValue}</span>}

                    {/* <span className="mx-2" style={{ backgroundColor: '', width: "100%" }}>{columnThreeValue}</span> */}
                    {columnThreeValue && <span className="mx-2" style={{ backgroundColor: '', width: columnThreeWidth }}>{columnThreeValue}</span>}

                    {/* <span className="mx-2" style={{ backgroundColor: '', width: 150 }}>{columnFourValue}</span> */}
                    {columnFourValue && <span className="mx-2" style={{ backgroundColor: '', width: columnFourWidth }}>{columnFourValue}</span>}


                    {/* management btns */}
                    <span className="mx-2 d-flex align-items-center justify-content-center" style={{ backgroundColor: '', width: 100 }}>
                        <button
                            onClick={e => editButtonHandler(e, id)}
                            className="btn btn-sm me-2 px-3"
                            style={{ backgroundColor: '' }}>
                            < i className="bi bi-pencil"></i>
                        </button>

                        <button
                            onClick={e => deleteButtonHandler(e, id)}
                            className="btn btn-sm px-3"
                            style={{ backgroundColor: '' }}>
                            <i className="bi bi-trash"></i>
                        </button>
                    </span>

                </div>

            </div>
        </div>
    )
}


export default ListItem;