import clsx from 'clsx';
import React, { useState } from 'react'
import SelectSearch from 'react-select-search';
import { ISelectOptions } from '../../interfaces';


interface IProps {
    name: string
    label?: string
    placeholder?: string
    selectOptions: ISelectOptions[]
    selectedValue?: string
    search?: boolean

    // // event handlers
    onSelect?: (value: string) => void,
    onSearch?: (value: string) => void,
    // previousClickHandler: (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void,
    // nextClickHandler: (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void,
}

// const SearchableSelect: React.FC<IProps> = ({}) => {
const SearchableSelect: React.FC<IProps> = ({ label, name, placeholder, selectOptions, selectedValue, search = true, onSelect, onSearch }) => {

    // const [selectOptions, setCategorySelectOptions] = useState<ISelectOptions[]>([]);
    // const [selectedValue, setSelectedCategoryValue] = useState("");

    return (
        <>
            {/* {label && <label htmlFor="brand" className='col-lg-2 col-form-label required fw-bold fs-6'>{label}</label>} */}

            {selectOptions.length > 0 && (
                <SelectSearch
                    //@ts-ignore
                    getOptions={onSearch}
                    options={selectOptions}
                    value={selectedValue}
                    // @ts-ignore
                    onChange={onSelect}
                    search={search}
                    //@ts-ignore
                    name={name}
                    placeholder={placeholder} />
            )}
        </>
    )
}


export default SearchableSelect;
