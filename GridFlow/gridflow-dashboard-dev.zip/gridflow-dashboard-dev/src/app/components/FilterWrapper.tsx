import React from 'react'

interface FilterAttrProps {
    header: string,
    showActionButtons?: boolean,
    children: React.ReactNode,

    resetClickHandler?: (e: React.MouseEvent<HTMLButtonElement>) => void;
    applyClickHandler?: (e: React.MouseEvent<HTMLButtonElement>) => void;
}


const FilterWrapper: React.FC<FilterAttrProps> = ({ header, showActionButtons = true, children, resetClickHandler = null, applyClickHandler = null }) => {

    const filterResetClickHandler = (e: React.MouseEvent<HTMLButtonElement>) => {
        resetClickHandler ? resetClickHandler(e) : console.log('default reset handler');
    }

    const filterApplyClickHandler = (e: React.MouseEvent<HTMLButtonElement>) => {
        applyClickHandler ? applyClickHandler(e) : console.log('default apply handler');
    }

    return (
        <div className="menu menu-sub menu-sub-dropdown w-250px w-md-300px show" data-kt-menu="true" id="kt_menu_61553c2d47fdd" style={{ zIndex: 105, position: 'fixed', inset: '0px 0px auto auto', margin: 0, transform: 'translate3d(-118px, 129px, 0px)' }} data-select2-id="select2-data-kt_menu_61553c2d47fdd" data-popper-placement="bottom-end">
            {/* <!--begin::Header--> */}
            <div className="px-7 py-5">
                <div className="fs-5 text-dark fw-bolder">{header}</div>
            </div>
            {/* <!--end::Header--> */}

            {/* <!--begin::Menu separator--> */}
            <div className="separator border-gray-200"></div>
            {/* <!--end::Menu separator--> */}

            {/* <!--begin::Form--> */}
            <div className="px-7 py-5">

                {/* filter content */}
                {children}
                {/* end: filter content */}

                {/* <!--begin::Actions--> */}
                {showActionButtons && (<div className="d-flex justify-content-end">
                    <button
                        type="reset"
                        className="btn btn-sm btn-light btn-active-light-primary me-2"
                        data-kt-menu-dismiss="true"
                        onClick={filterResetClickHandler}>
                        Reset
                    </button>

                    <button
                        type="submit"
                        className="btn btn-sm btn-primary"
                        data-kt-menu-dismiss="true"
                        onClick={filterApplyClickHandler}>
                        Apply
                    </button>
                </div>)}
                {/* <!--end::Actions--> */}
            </div>
            {/* <!--end::Form--> */}
        </div>
    )
}


export default FilterWrapper;