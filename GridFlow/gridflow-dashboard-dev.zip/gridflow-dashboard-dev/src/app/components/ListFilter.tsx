import React, { useState } from 'react'

export default function ListFilter() {

    return (
        <div className="menu menu-sub menu-sub-dropdown w-250px w-md-300px show" data-kt-menu="true" id="kt_menu_61553c2d47fdd" style={{ zIndex: 105, position: 'fixed', inset: '0px 0px auto auto', margin: 0, transform: 'translate3d(-118px, 129px, 0px)' }} data-select2-id="select2-data-kt_menu_61553c2d47fdd" data-popper-placement="bottom-end">
            {/* <!--begin::Header--> */}
            <div className="px-7 py-5">
                <div className="fs-5 text-dark fw-bolder">Filter Options</div>
            </div>
            {/* <!--end::Header--> */}
            {/* <!--begin::Menu separator--> */}
            <div className="separator border-gray-200"></div>
            {/* <!--end::Menu separator--> */}
            {/* <!--begin::Form--> */}
            <div className="px-7 py-5">
                {/* <!--begin::Input group--> */}
                <div className="mb-10" data-select2-id="select2-data-72-lwg3">
                    {/* <!--begin::Label--> */}
                    <label className="form-label fw-bold">Select Options:</label>
                    {/* <!--end::Label--> */}
                    {/* <!--begin::Input--> */}
                    <div data-select2-id="select2-data-71-hovi">
                        <select className="form-select form-select-solid select2-hidden-accessible" data-kt-select2="true" data-placeholder="Select option" data-dropdown-parent="#kt_menu_61553c2d47fdd" data-allow-clear="true" data-select2-id="select2-data-7-dhtd" tabIndex={-1} aria-hidden="true">
                            <option data-select2-id="select2-data-9-vkgo"></option>
                            <option value="1" data-select2-id="select2-data-78-amfb">Option 1</option>
                            <option value="2" data-select2-id="select2-data-79-g246">Option 2</option>
                            <option value="3" data-select2-id="select2-data-80-qho3">Option 3</option>
                        </select>

                        {/* <span className="select2 select2-container select2-container--bootstrap5 select2-container--below" dir="ltr" data-select2-id="select2-data-8-7uzm" style={{ width: '100%' }}>
                            <span className="selection">
                                <span className="select2-selection select2-selection--single form-select form-select-solid" role="combobox" aria-haspopup="true" aria-expanded="false" tabIndex={0} aria-disabled="false" aria-labelledby="select2-dymp-container" aria-controls="select2-dymp-container">
                                    <span className="select2-selection__rendered" id="select2-dymp-container" role="textbox" aria-readonly="true" title="Select option">
                                        <span className="select2-selection__placeholder">Select option</span>
                                    </span>
                                    <span className="select2-selection__arrow" role="presentation">
                                        <b role="presentation"></b>
                                    </span>
                                </span>
                            </span>
                            <span className="dropdown-wrapper" aria-hidden="true"></span>
                        </span> */}

                    </div>
                    {/* <!--end::Input--> */}
                </div>
                {/* <!--end::Input group--> */}
                {/* <!--begin::Input group--> */}
                <div className="mb-10">
                    {/* <!--begin::Label--> */}
                    <label className="form-label fw-bold">Checkbox options:</label>
                    {/* <!--end::Label--> */}
                    {/* <!--begin::Options--> */}
                    <div className="d-flex">
                        {/* <!--begin::Options--> */}
                        <label className="form-check form-check-sm form-check-custom form-check-solid me-5">
                            <input className="form-check-input" type="checkbox" value="1" />
                            <span className="form-check-label">Option 1</span>
                        </label>
                        {/* <!--end::Options--> */}
                        {/* <!--begin::Options--> */}
                        <label className="form-check form-check-sm form-check-custom form-check-solid">
                            <input className="form-check-input" type="checkbox" value="2" checked={true} />
                            <span className="form-check-label">Option 2</span>
                        </label>
                        {/* <!--end::Options--> */}
                    </div>
                    {/* <!--end::Options--> */}
                </div>
                {/* <!--end::Input group--> */}
                {/* <!--begin::Input group--> */}
                <div className="mb-10">
                    {/* <!--begin::Label--> */}
                    <label className="form-label fw-bold">Buttons</label>
                    {/* <!--end::Label--> */}
                    {/* <!--begin::Switch--> */}
                    <div className="form-check form-switch form-switch-sm form-check-custom form-check-solid">
                        <input className="form-check-input" type="checkbox" value="" name="notifications" checked={true} />
                        <label className="form-check-label">Enabled</label>
                    </div>
                    {/* <!--end::Switch--> */}
                </div>
                {/* <!--end::Input group--> */}
                {/* <!--begin::Actions--> */}
                <div className="d-flex justify-content-end">
                    <button type="reset" className="btn btn-sm btn-light btn-active-light-primary me-2" data-kt-menu-dismiss="true">Reset</button>
                    <button type="submit" className="btn btn-sm btn-primary" data-kt-menu-dismiss="true">Apply</button>
                </div>
                {/* <!--end::Actions--> */}
            </div>
            {/* <!--end::Form--> */}
        </div>
    )
}
