/**
 * 
 * See: https://redux-toolkit.js.org/tutorials/quick-start
 * See: https://redux-toolkit.js.org/usage/usage-with-typescript
 */

import { configureStore } from '@reduxjs/toolkit';
import { TypeOf } from 'yup';

// import reducers
import albumReducer from './slices/albumSlice';
import authReducer from './slices/authSlice';
import categoryReducer from './slices/categorySlice';

import categoryFormReducer from './slices/categoryFormSlice';

import brandReducer from './slices/brandSlice';
import productReducer from './slices/productSlice';
import shopReducer from './slices/shopSlice';
import shopBranchReducer from './slices/shopBranchSlice';

import shopOrderStatusReducer from './slices/shopOrderStatusSlice';

import productStockAlertReducer from './slices/productStockAlertSlice';

import deliveryAgencyReducer from './slices/deliveryAgencySlice';
import userRoleReducer from './slices/userRoleSlice';

// app, ui, control specific reducers
import uiReducer from './slices/uiSlice';
import modalReducer from './slices/modalSlice';


const store = configureStore({
    reducer: {
        album: albumReducer,
        auth: authReducer,
        brand: brandReducer,

        category: categoryReducer,
        categoryForm: categoryFormReducer,

        product: productReducer,
        shop: shopReducer,
        shopBranch: shopBranchReducer,

        shopOrderStatus: shopOrderStatusReducer,
        
        productStockAlert: productStockAlertReducer,

        deliveryAgency: deliveryAgencyReducer,
        userRole: userRoleReducer,

        // app, ui, control specific reducers
        uiState: uiReducer,
        modal: modalReducer,
    },

    // see: https://github.com/reduxjs/redux-toolkit/issues/820
    // only enable when node env is not production
    devTools: process.env.NODE_ENV !== "production",
})

export default store;

// see: https://redux-toolkit.js.org/usage/usage-with-typescript#type-safety-with-extrareducers
export type AppState = ReturnType<typeof store.getState>
