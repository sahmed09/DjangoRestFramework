/**
 * 
 * See: https://redux-toolkit.js.org/usage/usage-guide#simplifying-slices-with-createslice
 * See: https://redux-toolkit.js.org/usage/usage-with-typescript#type-safety-with-extrareducers
 * See: https://www.youtube.com/watch?v=eFh2Kr9hfyo
 * 
 */

import { createAsyncThunk, createSlice } from '@reduxjs/toolkit'
import { IProductState } from '../../../interfaces';
import { getShops as fetchData } from '../../api/shopAPI';


// async operations
// See: https://redux-toolkit.js.org/usage/usage-guide#async-requests-with-createasyncthunk

export const getShops = createAsyncThunk(
    'shop/getShops',

    async (page: number = 1) => {
        const data = await fetchData(page);

        // console.log('album fetch data: ');
        // console.log(data);

        return data;
    }
);

const initialState: IProductState = {
    page: 1,
    shops: [],
    error: null,
    hasNext: false,
    hasPrevious: false,
}


const shopSlice = createSlice({
    name: 'shop',

    initialState,

    reducers: {
        // normal reducers

        // add categories (array) to state
        addShops(state, action) {
            state.shops = action.payload.data?.results || [];
            state.hasNext = !!action.payload.data?.next || false;
            state.hasPrevious = !!action.payload.data?.previous || false;
        },

        // append categories (array) to state
        appendShops(state, action) {
            state.shops.push(...action.payload.data?.results || []);
            state.hasNext = !!action.payload.data?.next || false;
            state.hasPrevious = !!action.payload.data?.previous || false;
        },

        // reset category state
        resetShops(state) {

            state = initialState;
        },

        // increment/decrement category page number
        setShopPage(state, action) {
            // todo: check validity
            state.page = action.payload;
        }
    },

    // reducers with async operation
    extraReducers: {
        // see: https://github.com/reduxjs/redux-toolkit/issues/478
        [getShops.fulfilled.toString()]: (state, action) => {

            // console.log('fulfilled action: ');
            // console.log(action);

            if (!action.payload) return;

            state.shops = action.payload.data?.results || [];

            state.hasNext = !!action.payload.data?.next || false;
            state.hasPrevious = !!action.payload.data?.previous || false;

            state.error = action.payload.errorMessage || null;

        },

        // error handler
        [getShops.rejected.toString()]: (state, action) => {
            console.log('rejected => action: ', action);

            state.error = action.error?.message || null;
        },
    }

});


// Extract the action creators object and the reducer
const { actions, reducer } = shopSlice;

// Extract and export each action creator by name
export const { addShops, appendShops, resetShops, setShopPage } = actions;

// Export the reducer, either as a default or named export
export default reducer;