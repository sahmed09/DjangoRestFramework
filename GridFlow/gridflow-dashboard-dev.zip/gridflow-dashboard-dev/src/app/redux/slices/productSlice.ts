/**
 * 
 * See: https://redux-toolkit.js.org/usage/usage-guide#simplifying-slices-with-createslice
 * See: https://redux-toolkit.js.org/usage/usage-with-typescript#type-safety-with-extrareducers
 * See: https://www.youtube.com/watch?v=eFh2Kr9hfyo
 * 
 */

import { createAsyncThunk, createSlice, PayloadAction } from '@reduxjs/toolkit'
import { IBrand, ICategory } from '../../../interfaces';
import { getProducts as fetchData } from '../../api/productAPI';
// import { Brand } from './brandSlice';
// import { Category } from './categorySlice';

export interface Product {
    id: number,
    name: string,
    brand: IBrand,
    category: ICategory,
    album: number,
    slug: string,
    //  todo: create interface for product variation
    variations: any
}


export interface productState {
    page: number
    products: Product[]
    error?: string | null
    hasNext?: boolean
    hasPrevious?: boolean
}


// async operations
// See: https://redux-toolkit.js.org/usage/usage-guide#async-requests-with-createasyncthunk

export const getProducts = createAsyncThunk(
    'product/getProducts',

    async (page: number = 1) => {
        const data = await fetchData(page);

        console.log('album fetch data: ');
        console.log(data);

        return data;
    }
);

const initialState: productState = {
    page: 1,
    products: [],
    error: null,
    hasNext: false,
    hasPrevious: false,
}


const brandSlice = createSlice({
    name: 'product',

    initialState,

    reducers: {
        // normal reducers

        // add categories (array) to state
        addProducts(state, action) {
            state.products = action.payload.data?.results || [];
            state.hasNext = !!action.payload.data?.next || false;
            state.hasPrevious = !!action.payload.data?.previous || false;
        },

        // append categories (array) to state
        appendProducts(state, action) {
            state.products.push(...action.payload.data?.results || []);
            state.hasNext = !!action.payload.data?.next || false;
            state.hasPrevious = !!action.payload.data?.previous || false;
        },

        // reset category state
        resetProducts(state) {

            state = initialState;
        },

        // increment/decrement category page number
        setProductPage(state, action) {
            // todo: check validity
            state.page = action.payload;
        }
    },

    // reducers with async operation
    extraReducers: {
        // see: https://github.com/reduxjs/redux-toolkit/issues/478
        [getProducts.fulfilled.toString()]: (state, action) => {

            console.log('fulfilled action: ');
            console.log(action);

            if (!action.payload) return;

            state.products = action.payload.data?.results || [];

            state.hasNext = !!action.payload.data?.next || false;
            state.hasPrevious = !!action.payload.data?.previous || false;

            state.error = action.payload.errorMessage || null;

        },

        // error handler
        [getProducts.rejected.toString()]: (state, action) => {
            console.log('rejected => action: ', action);

            state.error = action.error?.message || null;
        },
    }

});


// Extract the action creators object and the reducer
const { actions, reducer } = brandSlice;

// Extract and export each action creator by name
export const { addProducts, appendProducts, resetProducts, setProductPage } = actions;

// Export the reducer, either as a default or named export
export default reducer;