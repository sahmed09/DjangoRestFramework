import { createAsyncThunk, createSlice } from '@reduxjs/toolkit'
import { getProductStockAlerts } from '../../api/stockAlertAPI';

interface IProduct {
    name: string
    slug: string
}

export interface IStockAlert {
    id: number
    product: IProduct
    name: string
    description: string
    stockBelow: number
    stockAbove: number
    shopID: number
    branchID: number | null
}


interface IShopOrderStatusState {
    alerts: IStockAlert[]
    error?: string | null
}

const initialState: IShopOrderStatusState = {
    alerts: [],
    error: null
}


interface IParams {
    productSlug: string
    shopSlug: string
    branchSlug?: string
}

export const getStockAlertList = createAsyncThunk(
    'shopOrderStatus/getStockAlertList',

    async (params: IParams) => {
        const { productSlug, shopSlug, branchSlug = null } = params;
        const data = await getProductStockAlerts(productSlug, shopSlug, branchSlug);

        console.log('getStockAlertList fetch data: ');
        console.log(data);

        return data;
    }
);



const productStockAlertSlice = createSlice({
    name: 'productStockAlert',
    initialState,

    reducers: {
        reset(state) {
            return initialState;
        },
    },

    extraReducers: {
        [getStockAlertList.fulfilled.toString()]: (state, action) => {
            if (!action.payload) return;

            // map data

            /*
            id: number
            shopOrderStatus: string
            message?: string
            timestamp?: string
            */

            // @ts-ignore
            const mappedAlertList = action.payload.data?.results.map(({ id, product, name, description, stock_below, stock_above, shop, branch }) => ({
                id,
                product,
                name,
                description,
                stockBelow: stock_below,
                stockAbove: stock_above,
                shopID: shop,
                branchID: branch,

            }))

            console.log({ mappedAlertList });


            // save mapped data to state
            // state.statusList = action.payload.data?.results || [];
            state.alerts = mappedAlertList;
        },

        // error
        [getStockAlertList.rejected.toString()]: (state, action) => {
            console.log('rejected => action: ', action);
            state.error = action.error?.message || null;
        },
    }
});


// Extract the action creators object and the reducer
const { actions, reducer } = productStockAlertSlice;

// Extract and export each action creator by name
export const { reset } = actions;

// Export the reducer, either as a default or named export
export default reducer;
