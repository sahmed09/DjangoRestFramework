/**
 * 
 * See: https://redux-toolkit.js.org/usage/usage-guide#simplifying-slices-with-createslice
 * See: https://redux-toolkit.js.org/usage/usage-with-typescript#type-safety-with-extrareducers
 * See: https://www.youtube.com/watch?v=eFh2Kr9hfyo
 * 
 */

import { createAsyncThunk, createSlice } from '@reduxjs/toolkit'
import { IProductState } from '../../../interfaces';
import { getShopUserRoles } from '../../api/shopUserRoleAPI';
//  import { getShops as fetchData } from '../../api/shopAPI';


// async operations
// See: https://redux-toolkit.js.org/usage/usage-guide#async-requests-with-createasyncthunk


export interface IShopRoleParams {
    shopSlug: string
    page: number
}


interface IShop {
    name: string,
    slug: string
}

interface IUser {
    username: string
}

export interface IShopRole {
    id: number
    shop: IShop
    user: IUser
    role: string
}

export interface IShopRoleState {
    page: number
    roles: IShopRole[]
    error?: string | null
    hasNext?: boolean
    hasPrevious?: boolean
}


export const getShopUsers = createAsyncThunk(
    'userRole/getShopUsers',

    async (shopInfo: IShopRoleParams) => {
        const { shopSlug, page } = shopInfo;

        const data = await getShopUserRoles(shopSlug, page);
        return data;
    }
);

const initialState: IShopRoleState = {
    page: 1,
    roles: [],
    error: null,
    hasNext: false,
    hasPrevious: false,
}


const userRoleSlice = createSlice({
    name: 'userRole',

    initialState,

    reducers: {
        // normal reducers


        // reset category state
        resetRoleState(state) {
            return initialState;
        },

        // increment/decrement category page number
        setShopRolePage(state, action) {
            // todo: check validity
            state.page = action.payload;
        }
    },

    // reducers with async operation
    extraReducers: {
        // see: https://github.com/reduxjs/redux-toolkit/issues/478
        [getShopUsers.fulfilled.toString()]: (state, action) => {

            // console.log('fulfilled action: ');
            // console.log(action);

            if (!action.payload) return;

            state.roles = action.payload.data?.results || [];

            state.hasNext = !!action.payload.data?.next || false;
            state.hasPrevious = !!action.payload.data?.previous || false;

            state.error = action.payload.errorMessage || null;

        },

        // error handler
        [getShopUsers.rejected.toString()]: (state, action) => {
            console.log('rejected => action: ', action);

            state.error = action.error?.message || null;
        },
    }

});


// Extract the action creators object and the reducer
const { actions, reducer } = userRoleSlice;

// Extract and export each action creator by name
export const { resetRoleState, setShopRolePage } = actions;

// Export the reducer, either as a default or named export
export default reducer;