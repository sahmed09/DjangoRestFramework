/**
 * 
 * See: https://redux-toolkit.js.org/usage/usage-guide#simplifying-slices-with-createslice
 * See: https://redux-toolkit.js.org/usage/usage-with-typescript#type-safety-with-extrareducers
 * See: https://www.youtube.com/watch?v=eFh2Kr9hfyo
 * 
 */

import { createSlice } from '@reduxjs/toolkit'
import { IModalState } from '../../../interfaces';


// export interface IModalState {
//     visible: boolean
//     modalData?: any
// }

const initialState: IModalState = {
    visible: false,
    modalData: null,
}


const modalSlice = createSlice({
    name: 'modal',

    initialState,

    reducers: {

        showModal(state) {
            state.visible = true;
        },

        hideModal(state) {
            state.visible = false;
        },

        setModalData(state, action) {
            state.modalData = action.payload;
        },

        resetModalData(state) {
            state.modalData = null;
        },

        resetModal(state) {
            return initialState;
        },

    },


});


// Extract the action creators object and the reducer
const { actions, reducer } = modalSlice;

// Extract and export each action creator by name
export const { showModal, hideModal, setModalData, resetModalData, resetModal } = actions;

// Export the reducer, either as a default or named export
export default reducer;
