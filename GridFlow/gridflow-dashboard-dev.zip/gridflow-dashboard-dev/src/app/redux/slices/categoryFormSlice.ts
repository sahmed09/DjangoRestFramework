import { createSlice } from '@reduxjs/toolkit'
// @ts-ignore
import { v4 as uuidv4 } from 'uuid'
import { IAttribute, IAttributeValue, ICategoryFormState } from '../../../interfaces';


// export interface IAttributeValue {
//     id: string | number
//     value: string
//     slug: string
//     isSaved?: boolean
// }

// export interface IAttribute {
//     id: string | number
//     name: string
//     slug: string
//     values: IAttributeValue[]
//     isSaved?: boolean

// }

// export interface ICreateCategoryState {
//     id?: string | number
//     name: string
//     slug: string
//     attributes: IAttribute[]
//     isSaved?: boolean

// }



const _demoState: ICategoryFormState = {
    // id: uuidv4(),
    id: 'id-smartphone',
    name: 'Smartphone',
    slug: 'smartphone',
    isSaved: false,
    update: false,
    attributes: [
        {
            // id: uuidv4(),
            id: "id-ram",
            name: 'RAM',
            slug: 'ram',
            isSaved: false,
            update: false,
            values: [
                {
                    // id: uuidv4(),
                    id: '4gb',
                    value: '4 GB',
                    slug: '4gb',
                    isSaved: false,
                    update: false,
                },
                {
                    // id: uuidv4(),
                    id: '6gb',
                    value: '6 GB',
                    slug: '6gb',
                    isSaved: false,
                    update: false,
                },
            ]
        },

        // another attribute
        {
            // id: uuidv4(),
            id: "id-battery",
            name: 'Battery',
            slug: 'battery',
            isSaved: false,
            update: false,
            values: [
                {
                    // id: uuidv4(),
                    id: '4000mah',
                    value: '4000 mAh',
                    slug: '4000mah',
                    isSaved: false,
                    update: false,
                },
                {
                    // id: uuidv4(),
                    id: '5000mah',
                    value: '5000 mAh',
                    slug: '5000mah',
                    isSaved: false,
                    update: false,
                },
            ]
        },
    ]
}



// const initialState: ICreateCategoryState = {
const initialState: ICategoryFormState = {
    name: '',
    slug: '',
    isSaved: false,
    update: false,
    attributes: [
        {
            id: uuidv4(),
            name: '',
            slug: '',
            isSaved: false,
            update: false,
            values: [
                {
                    id: uuidv4(),
                    value: '',
                    slug: '',
                    isSaved: false,
                    update: false,
                },
            ]
        }
    ],
}





const categoryFormSlice = createSlice({
    name: 'categoryForm',

    initialState,

    reducers: {

        setCategoryName(state, action) {
            state.name = action.payload;
        },

        setCategorySlug(state, action) {
            state.slug = action.payload;
        },

        setCategorySaved(state) {
            state.isSaved = true;
        },


        // create empty attribute
        createNewAttribute(state) {
            // create new attribute object with an empty value object
            const _attr: IAttribute = {
                id: uuidv4(),
                name: '',
                slug: '',
                isSaved: false,
                values: [
                    {
                        id: uuidv4(),
                        value: '',
                        slug: '',
                        isSaved: false,
                    },
                ],
            };

            // push new attribute to attributes array
            state.attributes.push(_attr);

        },

        // create operation
        setCategoryAttributeName(state, action) {

            // noob error handling
            // if (!action.payload.id || !action.payload.value) {
            if (action.payload.id === undefined || action.payload.value === undefined) {
                console.log('setCategoryAttributeName() :: missing action.payload.id or action.payload.value');
                return;
            }

            // find attr by id (first item of search result)
            const _attr = state.attributes.filter(attr => attr.id === action.payload.id)[0];

            const _index = state.attributes.findIndex(item => item.id === action.payload.id);

            // update attr name
            const updatedItem: IAttribute = {
                ...state.attributes[_index],
                // updated name
                name: action.payload.value,
            }

            const _beforeItems = state.attributes.slice(0, _index);
            const _afterItems = state.attributes.slice(_index + 1);

            // new array containg updated attribute name
            const newArray: IAttribute[] = [
                ..._beforeItems,
                updatedItem,
                ..._afterItems,
            ];

            // set new array as attributes value
            state.attributes = newArray;
        },


        // create operation
        setCategoryAttributeSlug(state, action) {

            // noob error handling
            // if (!action.payload.id || !action.payload.value) {
            if (action.payload.id === undefined || action.payload.value === undefined) {
                console.log('setCategoryAttributeSlug() :: missing action.payload.id or action.payload.value');
                return;
            }

            // find attr by id (first item of search result)
            const _attr = state.attributes.filter(attr => attr.id === action.payload.id)[0];

            const _index = state.attributes.findIndex(item => item.id === action.payload.id);

            // update attr name
            const updatedItem: IAttribute = {
                ...state.attributes[_index],
                // updated name
                slug: action.payload.value,
            }

            const _beforeItems = state.attributes.slice(0, _index);
            const _afterItems = state.attributes.slice(_index + 1);


            // create new attrs array
            const newArray: IAttribute[] = [
                ..._beforeItems,
                updatedItem,
                ..._afterItems,
            ];

            // set new array as attributes value
            state.attributes = newArray;
        },

        // category attribute isSaved update operation
        setCategoryAttributeNameSaved(state, action) {

            console.log('setCategoryAttributeNameSaved()');


            // noob error handling
            if (action.payload === undefined) {
                console.log('setCategoryAttributeNameSaved() :: missing action.payload [attribute id]');
                return;
            }

            // find attr by id (first item of search result)

            const _index = state.attributes.findIndex(item => item.id === action.payload);
            // const _attr = state.attributes.filter(attr => attr.id === action.payload.id)[0];
            const _attr = state.attributes[_index];

            // update attr name
            const updatedItem: IAttribute = {
                ...state.attributes[_index],
                // updated isSaved status
                isSaved: true,
            }

            const _beforeItems = state.attributes.slice(0, _index);
            const _afterItems = state.attributes.slice(_index + 1);

            // new array containg updated attribute name
            const newArray: IAttribute[] = [
                ..._beforeItems,
                updatedItem,
                ..._afterItems,
            ];

            // set new array as attributes value
            state.attributes = newArray;
        },


        createAttributeValue(state, action) {
            // noob error handling
            // if (!action.payload.id) {
            if (action.payload.id === undefined) {
                console.log('createAttributeValue() :: missing action.payload.id [attribute id]');
                return;
            }

            // create empty value object
            const newValue: IAttributeValue = {
                id: uuidv4(),
                value: '',
                slug: '',
                isSaved: false,
            }

            // find target attribute index and get the attribute object from array (ie. RAM)
            const _attrIndex = state.attributes.findIndex(item => item.id === action.payload.id);
            const _attribute = state.attributes[_attrIndex];

            // get target attribute values array (ie: ["4 GB", "6 GB"])
            const _attributeValues = _attribute.values;

            // create new attribute values array and append newValue to the array (ie. ["4 GB", "6 GB", <new empty value>])
            const updatedAttributeValues: IAttributeValue[] = [
                ..._attributeValues,
                newValue,
            ];


            // set arrtibute values to attribute
            const updatedAttribute: IAttribute = {
                ..._attribute,

                //update new value
                values: updatedAttributeValues,
            }

            // update attribute array without changing existing items position
            // slice state attribute array
            const _beforeAttributes = state.attributes.slice(0, _attrIndex);
            const _afterAttributes = state.attributes.slice(_attrIndex + 1);

            // create new attribute array
            const updatedAttributesArray: IAttribute[] = [
                ..._beforeAttributes,
                updatedAttribute,
                ..._afterAttributes,
            ];

            // update state
            state.attributes = updatedAttributesArray

        },


        // add new value to attribute
        setAttributeValue(state, action) {

            // required fields attribute id, attr value id, attr value

            // noob error handling
            // if (!action.payload.attrId || !action.payload.valueId || !action.payload.value) {
            if (action.payload.attrId === undefined || action.payload.valueId === undefined || action.payload.value === undefined) {
                console.log('setAttributeValue() :: missing action.payload.attrId or action.payload.valueId or action.payload.value');
                return;
            }


            // find target attribute by id (first item of search result), also find the index
            const _attrIndex = state.attributes.findIndex(item => item.id === action.payload.attrId);
            // const _attr = state.attributes.filter(attr => attr.id === action.payload.id)[0];
            const _attr = state.attributes[_attrIndex];

            const _attrValues = _attr.values;

            // find target attribute value index and item
            const _valueIndex = _attrValues.findIndex(item => item.id === action.payload.valueId);
            const _value = _attrValues[_valueIndex];

            // update attr value
            const updatedItem: IAttributeValue = {
                ..._value,
                // updated name
                value: action.payload.value,
            }

            const _beforeItems = _attrValues.slice(0, _valueIndex);
            const _afterItems = _attrValues.slice(_valueIndex + 1);

            // create new attrs array
            const newArray: IAttributeValue[] = [
                ..._beforeItems,
                updatedItem,
                ..._afterItems,
            ];

            console.log('new updated attr values: ');
            console.log(newArray);

            // update attribute with new 'value' (not attributes)
            const updatedAttribute: IAttribute = {
                ..._attr,
                // updated value
                values: newArray,
            }

            // update attributes array
            const _beforeAttributeItems = state.attributes.slice(0, _attrIndex);
            const _afterAttributeItems = state.attributes.slice(_attrIndex + 1);

            const updatedAttributesArray: IAttribute[] = [
                ..._beforeAttributeItems,
                updatedAttribute,
                ..._afterAttributeItems,
            ];

            // update state
            state.attributes = updatedAttributesArray;
        },

        // set slug to attribute value
        setAttributeValueSlug(state, action) {
            // required fields: attribute id, attr value id, attr slug
            // noob error handling
            // if (!action.payload.attrId || !action.payload.valueId || !action.payload.slug) {
            if (action.payload.attrId === undefined || action.payload.valueId === undefined || action.payload.slug === undefined) {
                console.log('setAttributeValue() :: missing action.payload.attrId or action.payload.valueId or action.payload.slug');
                return;
            }


            // find target attribute by id (first item of search result), also find the index
            const _attrIndex = state.attributes.findIndex(item => item.id === action.payload.attrId);
            // const _attr = state.attributes.filter(attr => attr.id === action.payload.id)[0];
            const _attr = state.attributes[_attrIndex];

            const _attrValues = _attr.values;

            // find target attribute value index and item
            const _valueIndex = _attrValues.findIndex(item => item.id === action.payload.valueId);
            const _value = _attrValues[_valueIndex];

            // update attr value
            const updatedItem: IAttributeValue = {
                ..._value,
                // updated slug
                slug: action.payload.slug,
            }

            const _beforeItems = _attrValues.slice(0, _valueIndex);
            const _afterItems = _attrValues.slice(_valueIndex + 1);

            // create new attrs array
            const newArray: IAttributeValue[] = [
                ..._beforeItems,
                updatedItem,
                ..._afterItems,
            ];

            // update attribute with new 'values' (not attributes)
            const updatedAttribute: IAttribute = {
                ..._attr,
                // updated value
                values: newArray,
            }

            // update attributes array
            const _beforeAttributeItems = state.attributes.slice(0, _attrIndex);
            const _afterAttributeItems = state.attributes.slice(_attrIndex + 1);

            const updatedAttributesArray: IAttribute[] = [
                ..._beforeAttributeItems,
                updatedAttribute,
                ..._afterAttributeItems,
            ];

            // update state
            state.attributes = updatedAttributesArray;
        },


        // set attribute value saved
        setAttributeValueSaved(state, action) {

            console.log('setAttributeValueSaved()');
            

            // required fields attribute id, attr value id, attr value

            // noob error handling
            // if (!action.payload.attrId || !action.payload.valueId || !action.payload.value) {
            if (action.payload.attrId === undefined || action.payload.valueId === undefined) {
                console.log('setAttributeValueSaved() :: missing action.payload.attrId or action.payload.valueId');
                return;
            }


            // find target attribute by id (first item of search result), also find the index
            const _attrIndex = state.attributes.findIndex(item => item.id === action.payload.attrId);
            // const _attr = state.attributes.filter(attr => attr.id === action.payload.id)[0];
            const _attr = state.attributes[_attrIndex];

            const _attrValues = _attr.values;

            // find target attribute value index and item
            const _valueIndex = _attrValues.findIndex(item => item.id === action.payload.valueId);
            const _value = _attrValues[_valueIndex];

            // update attr value
            const updatedItem: IAttributeValue = {
                ..._value,
                // updated flag
                isSaved: true,
            }

            const _beforeItems = _attrValues.slice(0, _valueIndex);
            const _afterItems = _attrValues.slice(_valueIndex + 1);

            // create new attrs array
            const newArray: IAttributeValue[] = [
                ..._beforeItems,
                updatedItem,
                ..._afterItems,
            ];

            // update attribute with new 'value' (not attributes)
            const updatedAttribute: IAttribute = {
                ..._attr,
                // updated value
                values: newArray,
            }

            // update attributes array
            const _beforeAttributeItems = state.attributes.slice(0, _attrIndex);
            const _afterAttributeItems = state.attributes.slice(_attrIndex + 1);

            const updatedAttributesArray: IAttribute[] = [
                ..._beforeAttributeItems,
                updatedAttribute,
                ..._afterAttributeItems,
            ];

            // update state
            state.attributes = updatedAttributesArray;
        },


        // directly replace whole form state with passed one
        replaceCategoryFormState(state, action) {
            console.log('replaceCategoryFormState()');

            // todo: check if action payload is ICreateCategoryState type
            // state = action.payload;
            return action.payload;
        },

        resetCategoryForm(state) {
            return initialState;
        },

    },

});


// Extract the action creators object and the reducer
const { actions, reducer } = categoryFormSlice;

// Extract and export each action creator by name
// export const { setCategoryName, setCategoryAttributes, setCategoryAttributeName, setCategoryAttributeValues, resetCreatedCategory } = actions;
export const {
    setCategoryName,
    setCategorySlug,
    setCategorySaved,

    createNewAttribute,
    setCategoryAttributeName,
    setCategoryAttributeSlug,
    setCategoryAttributeNameSaved,

    createAttributeValue,
    setAttributeValue,
    setAttributeValueSlug,
    setAttributeValueSaved,

    replaceCategoryFormState,
    resetCategoryForm,

} = actions;

// Export the reducer, either as a default or named export
export default reducer;
