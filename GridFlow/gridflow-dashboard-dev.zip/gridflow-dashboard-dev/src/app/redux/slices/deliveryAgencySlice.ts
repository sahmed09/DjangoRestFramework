/**
 * 
 * See: https://redux-toolkit.js.org/usage/usage-guide#simplifying-slices-with-createslice
 * See: https://redux-toolkit.js.org/usage/usage-with-typescript#type-safety-with-extrareducers
 * See: https://www.youtube.com/watch?v=eFh2Kr9hfyo
 * 
 */

import { createAsyncThunk, createSlice } from '@reduxjs/toolkit'
import { getDeliveryAgencyList } from '../../api/deliveryAgencyAPI';

export interface IDeliveryAgency {
    id: number,
    name: string,
    address: string,
    mobile: string,
    email: string,
    logo?: string,
}

export interface IDeliveryAgencyState {
    page: number
    agencies: IDeliveryAgency[]
    error?: string | null
    hasNext?: boolean
    hasPrevious?: boolean
}


// async operations
// See: https://redux-toolkit.js.org/usage/usage-guide#async-requests-with-createasyncthunk

export const getDeliveryAgencies = createAsyncThunk(
    'deliveryAgency/getDeliveryAgencies',

    async (page: number = 1) => {
        const data = await getDeliveryAgencyList(page);
        return data;
    }
);

const initialState: IDeliveryAgencyState = {
    page: 1,
    agencies: [],
    error: null,
    hasNext: false,
    hasPrevious: false,
}


const deliveryAgencySlice = createSlice({
    name: 'deliveryAgency',

    initialState,

    reducers: {
        // normal reducers

        // reset category state
        resetDeliveryAgencies(state) {
            return initialState;
        },

        // increment/decrement category page number
        setDeliveryAgencyPage(state, action) {
            // todo: check validity
            state.page = action.payload;
        }
    },

    // reducers with async operation
    extraReducers: {
        // see: https://github.com/reduxjs/redux-toolkit/issues/478
        [getDeliveryAgencies.fulfilled.toString()]: (state, action) => {

            if (!action.payload) return;

            state.agencies = action.payload.data?.results || [];

            state.hasNext = !!action.payload.data?.next || false;
            state.hasPrevious = !!action.payload.data?.previous || false;

            state.error = action.payload.errorMessage || null;

        },

        // error handler
        [getDeliveryAgencies.rejected.toString()]: (state, action) => {
            console.log('rejected => action: ', action);

            state.error = action.error?.message || null;
        },
    }

});


// Extract the action creators object and the reducer
const { actions, reducer } = deliveryAgencySlice;

// Extract and export each action creator by name
export const { resetDeliveryAgencies, setDeliveryAgencyPage } = actions;

// Export the reducer, either as a default or named export
export default reducer;