import { createAsyncThunk, createSlice } from '@reduxjs/toolkit'
import { getShopOrderStatusList } from '../../api/orderAPI';

export interface IShopOrderStatus {
    id: number
    shopOrderStatus: string
    message?: string
    timestamp?: string
}


interface IShopOrderStatusState {
    statusList: IShopOrderStatus[]
    error?: string | null
}

const initialState: IShopOrderStatusState = {
    statusList: [],
    error: null
}


interface IParams {
    slug: string
    page?: number
}

export const getShopStatusList = createAsyncThunk(
    'shopOrderStatus/getShopStatusList',

    async (params: IParams) => {
        const { slug, page = 1 } = params;
        const data = await getShopOrderStatusList(slug, page);

        console.log('algetShopStatusListbum fetch data: ');
        console.log(data);

        return data;
    }
);



const shopOrderStatusSlice = createSlice({
    name: 'shopOrderStatus',
    initialState,

    reducers: {
        reset(state) {
            return initialState;
        },
    },

    extraReducers: {
        [getShopStatusList.fulfilled.toString()]: (state, action) => {
            if (!action.payload) return;

            // map data

            /*
            id: number
            shopOrderStatus: string
            message?: string
            timestamp?: string
            */

            // @ts-ignore
            const mappedStatusList = action.payload.data?.results.map(status => ({
                id: status.id,
                shopOrderStatus: status.shop_order_status.status,
                message: status.msg,
                timestamp: status.timestamp,
            }))

            console.log({ mappedStatusList });


            // save mapped data to state
            // state.statusList = action.payload.data?.results || [];
            state.statusList = mappedStatusList;
        },

        // error
        [getShopStatusList.rejected.toString()]: (state, action) => {
            console.log('rejected => action: ', action);
            state.error = action.error?.message || null;
        },
    }
});


// Extract the action creators object and the reducer
const { actions, reducer } = shopOrderStatusSlice;

// Extract and export each action creator by name
export const { reset } = actions;

// Export the reducer, either as a default or named export
export default reducer;
