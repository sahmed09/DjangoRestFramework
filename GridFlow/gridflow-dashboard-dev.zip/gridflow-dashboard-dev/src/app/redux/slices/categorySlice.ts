/**
 * 
 * See: https://redux-toolkit.js.org/usage/usage-guide#simplifying-slices-with-createslice
 * See: https://redux-toolkit.js.org/usage/usage-with-typescript#type-safety-with-extrareducers
 * See: https://www.youtube.com/watch?v=eFh2Kr9hfyo
 * 
 */

import { createAsyncThunk, createSlice, PayloadAction } from '@reduxjs/toolkit'
import { ICategoryState } from '../../../interfaces';
import { getCategories as fetchCategories } from '../../api/categoryAPI';

// export interface ICategory {
//     id: number,
//     name: string,
//     slug: string,
// }


// export interface ICategoryState {
//     page: number
//     categories: ICategory[]
//     error?: string | null
//     hasNext?: boolean
//     hasPrevious?: boolean
// }


// async operations
// See: https://redux-toolkit.js.org/usage/usage-guide#async-requests-with-createasyncthunk

export const getCategories = createAsyncThunk(
    'category/getCategories',

    async (page: number = 1) => {
        // const { data } = await fetchCategories(page);
        // return data;
        const data = await fetchCategories(page);
        return data;
    }
);

const initialState: ICategoryState = {
    page: 1,
    categories: [],
    error: null,
    hasNext: false,
    hasPrevious: false,
}


const categorySlice = createSlice({
    name: 'category',

    initialState,

    reducers: {
        // normal reducers

        // add categories (array) to state
        addCategories(state, action) {
            state.categories = action.payload.data?.results || [];
            state.hasNext = !!action.payload.data?.next || false;
            state.hasPrevious = !!action.payload.data?.previous || false;
        },

        // append categories (array) to state
        appendCategories(state, action) {
            state.categories.push(...action.payload.data?.results || []);
            state.hasNext = !!action.payload.data?.next || false;
            state.hasPrevious = !!action.payload.data?.previous || false;
        },

        // reset category state
        resetCategories(state) {
            state.page = 0;
            state.categories = [];
            state.error = null;
            state.hasNext = false;
            state.hasPrevious = false;
        },

        // increment/decrement category page number
        setCategoryPage(state, action) {
            // todo: check validity
            state.page = action.payload;
        }
    },

    // reducers with async operation
    extraReducers: {
        // see: https://github.com/reduxjs/redux-toolkit/issues/478
        [getCategories.fulfilled.toString()]: (state, action) => {

            console.log('fulfilled action: ');
            console.log(action);

            if (!action.payload) return;

            // set categories
            state.categories = action.payload.data?.results || [];

            // append categories
            // state.categories.push(...action.payload.data?.results || []);
            
            state.hasNext = !!action.payload.data?.next || false;
            state.hasPrevious = !!action.payload.data?.previous || false;

            state.error = action.payload.errorMessage || null;

        },

        // error handler
        [getCategories.rejected.toString()]: (state, action) => {
            console.log('rejected => action: ', action);

            state.error = action.error?.message || null;
        },
    }

});


// Extract the action creators object and the reducer
const { actions, reducer } = categorySlice;

// Extract and export each action creator by name
export const { addCategories,appendCategories, resetCategories, setCategoryPage } = actions;

// Export the reducer, either as a default or named export
export default reducer;