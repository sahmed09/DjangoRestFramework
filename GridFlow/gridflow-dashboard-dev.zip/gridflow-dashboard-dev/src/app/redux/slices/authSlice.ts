/**
 * 
 * See: https://redux-toolkit.js.org/usage/usage-guide#simplifying-slices-with-createslice
 * See: https://redux-toolkit.js.org/usage/usage-with-typescript#type-safety-with-extrareducers
 * See: https://www.youtube.com/watch?v=eFh2Kr9hfyo
 * 
 */

import { createAsyncThunk, createSlice } from '@reduxjs/toolkit'
import { IAuthCredentials, ITokenString } from '../../../interfaces';
import { getAccessToken } from '../../api/authAPI';



// async operations
// See: https://redux-toolkit.js.org/usage/usage-guide#async-requests-with-createasyncthunk

export const getToken = createAsyncThunk(
    'auth/getToken',

    async (authCreds: IAuthCredentials) => {
        const { username, password } = authCreds;

        const data = await getAccessToken(username, password);
        return data;
    }
);

const initialState: ITokenString = {
    token: null,
    error: null,
}


const authSlice = createSlice({
    name: 'auth',

    initialState,

    reducers: {
        // normal reducers
        setToken(state, action) {
            state.token = action.payload;
        },

        resetToken(state) {
            state.token = null;
            state.error = null;
        },
    },

    // extra reducers with async operation
    extraReducers: {
        // see: https://github.com/reduxjs/redux-toolkit/issues/478
        [getToken.fulfilled.toString()]: (state, action) => {

            if (!action.payload) return;

            // const { data, errorMessage } = action.payload;
            const { data } = action.payload;

            if (data) {
                state.token = action.payload.data.access;
                state.error = null;
            }
            else state.error = action.payload.errorMessage;
        },

        // error handler
        [getToken.rejected.toString()]: (state, action) => {
            console.log('rejected => action: ', action);

            state.token = null;
            state.error = action.payload.errorMessage || null;
        },
    }

});


// Extract the action creators object and the reducer
const { actions, reducer } = authSlice;

// Extract and export each action creator by name
export const { setToken, resetToken } = actions;

// Export the reducer, either as a default or named export
export default reducer;
