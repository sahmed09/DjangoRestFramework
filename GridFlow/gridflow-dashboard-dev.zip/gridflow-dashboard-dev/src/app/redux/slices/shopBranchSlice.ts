/**
 * 
 * See: https://redux-toolkit.js.org/usage/usage-guide#simplifying-slices-with-createslice
 * See: https://redux-toolkit.js.org/usage/usage-with-typescript#type-safety-with-extrareducers
 * See: https://www.youtube.com/watch?v=eFh2Kr9hfyo
 * 
 */

import { createAsyncThunk, createSlice } from '@reduxjs/toolkit'
import { IShopBranchState } from '../../../interfaces';
import { getShopBranches as fetchData } from '../../api/shopBranchAPI';



// export interface IShopBranch {
//     id: number
//     name: string
//     slug: string
//     shop: number
//     album?: number
// }


// export interface IShopBranchState {
//     shopID?: number | null
//     shopName?: string
//     shopSlug?: string
//     page: number
//     branches: IShopBranch[]
//     error?: string | null
//     hasNext?: boolean
//     hasPrevious?: boolean
// }


// async operations
// See: https://redux-toolkit.js.org/usage/usage-guide#async-requests-with-createasyncthunk

export const getShopBranches = createAsyncThunk(
    'shopBranch/getShopBranches',

    async (shopSlug: string) => {
        const data = await fetchData(shopSlug);
        return data;
    }
);

const initialState: IShopBranchState = {
    shopID: null,
    shopName: '',
    shopSlug: '',

    page: 1,
    branches: [],
    error: null,
    hasNext: false,
    hasPrevious: false,
}


const shopBranchSlice = createSlice({
    name: 'shopBranch',

    initialState,

    reducers: {
        // normal reducers

        // add categories (array) to state
        addShopBranches(state, action) {
            state.branches = action.payload.data?.results || [];
            state.hasNext = !!action.payload.data?.next || false;
            state.hasPrevious = !!action.payload.data?.previous || false;
        },

        setShopID(state, action) {
            state.shopID = action.payload
        },

        setShopName(state, action) {
            state.shopName = action.payload
        },

        setShopSlug(state, action) {
            state.shopSlug = action.payload
        },

        // reset category state
        resetShopBranchState(state) {

            return initialState;
        },

        // increment/decrement category page number
        setShopBranchPage(state, action) {
            // todo: check validity
            state.page = action.payload;
        }
    },

    // reducers with async operation
    extraReducers: {
        // see: https://github.com/reduxjs/redux-toolkit/issues/478
        [getShopBranches.fulfilled.toString()]: (state, action) => {
            if (!action.payload) return;

            state.branches = action.payload.data?.results || [];
            state.hasNext = !!action.payload.data?.next || false;
            state.hasPrevious = !!action.payload.data?.previous || false;
            state.error = action.payload.errorMessage || null;
        },

        // error handler
        [getShopBranches.rejected.toString()]: (state, action) => {
            console.log('rejected => action: ', action);
            state.error = action.error?.message || null;
        },
    }

});


// Extract the action creators object and the reducer
const { actions, reducer } = shopBranchSlice;

// Extract and export each action creator by name
export const {
    addShopBranches,

    setShopID,
    setShopName,
    setShopSlug,

    resetShopBranchState,
    setShopBranchPage } = actions;

// Export the reducer, either as a default or named export
export default reducer;