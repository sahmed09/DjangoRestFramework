import { createSlice } from '@reduxjs/toolkit'
import { IUiState } from '../../../interfaces';


const initialState: IUiState = {
    //  toolbar buttons
    createButtonAsLink: false,
    createButtonLinkHref: '#',
    createButtonEnabled: true,
    filterButtonEnabled: false,
    // todo: add event handlers
}


const uiSlice = createSlice({
    name: 'ui',

    initialState,

    reducers: {

        // create Button as link
        enableCreateButtonLink(state, action) {
            state.createButtonAsLink = true;
            state.createButtonLinkHref = action.payload;
        },

        disableCreateButtonLink(state) {
            state.createButtonAsLink = false;
        },

        // toolbar create button
        enableCreateButton(state) {
            state.createButtonEnabled = true;
        },

        disableCreateButton(state) {
            state.createButtonEnabled = false;
        },
        // end: toolbar create button


        // toolbar filter button
        enableFilterButton(state) {
            state.filterButtonEnabled = true;
        },

        disableFilterButton(state) {
            state.filterButtonEnabled = false;
        },
        // end: toolbar filter button

        resetUiState(state) {
            return initialState;
        },

    },
    // end: reducers

});


// Extract the action creators object and the reducer
const { actions, reducer } = uiSlice;

// Extract and export each action creator by name
export const {
    enableCreateButtonLink,
    disableCreateButtonLink,

    enableCreateButton,
    disableCreateButton,

    enableFilterButton,
    disableFilterButton,

} = actions;

// Export the reducer, either as a default or named export
export default reducer;
