/**
 * 
 * See: https://redux-toolkit.js.org/usage/usage-guide#simplifying-slices-with-createslice
 * See: https://redux-toolkit.js.org/usage/usage-with-typescript#type-safety-with-extrareducers
 * See: https://www.youtube.com/watch?v=eFh2Kr9hfyo
 * 
 */

import { createAsyncThunk, createSlice, PayloadAction } from '@reduxjs/toolkit'
import { IAlbumState } from '../../../interfaces';
import { getAlbums as fetchAlbums } from '../../api/albumAPI';

// async operations
// See: https://redux-toolkit.js.org/usage/usage-guide#async-requests-with-createasyncthunk

export const getAlbums = createAsyncThunk(
    'album/getAlbums',

    async (page: number = 1) => {
        const data = await fetchAlbums(page);
        return data;
    }
);

const initialState: IAlbumState = {
    page: 1,
    albums: [],
    error: null,
    hasNext: false,
    hasPrevious: false,
}


const brandSlice = createSlice({
    name: 'brand',

    initialState,

    reducers: {
        // normal reducers

        // add categories (array) to state
        addAlbums(state, action) {
            state.albums = action.payload.data?.results || [];
            state.hasNext = !!action.payload.data?.next || false;
            state.hasPrevious = !!action.payload.data?.previous || false;
        },

        // append categories (array) to state
        appendAlbums(state, action) {
            state.albums.push(...action.payload.data?.results || []);
            state.hasNext = !!action.payload.data?.next || false;
            state.hasPrevious = !!action.payload.data?.previous || false;
        },

        // reset category state
        resetAlbums(state) {
            state = initialState;
        },

        // increment/decrement category page number
        setAlbumPage(state, action) {
            // todo: check validity
            state.page = action.payload;
        }
    },

    // reducers with async operation
    extraReducers: {
        // see: https://github.com/reduxjs/redux-toolkit/issues/478
        [getAlbums.fulfilled.toString()]: (state, action) => {

            console.log('fulfilled action: ');
            console.log(action);

            if (!action.payload) return;

            state.albums = action.payload.data?.results || [];

            state.hasNext = !!action.payload.data?.next || false;
            state.hasPrevious = !!action.payload.data?.previous || false;

            state.error = action.payload.errorMessage || null;

        },

        // error handler
        [getAlbums.rejected.toString()]: (state, action) => {
            console.log('rejected => action: ', action);
            state.error = action.error?.message || null;
        },
    }

});


// Extract the action creators object and the reducer
const { actions, reducer } = brandSlice;

// Extract and export each action creator by name
export const { addAlbums, appendAlbums, resetAlbums, setAlbumPage } = actions;

// Export the reducer, either as a default or named export
export default reducer;