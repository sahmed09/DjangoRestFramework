export type ResponseData = {
    status: number;
    statusText: string;
    message: string | null;
    errorMessage: string | null;
    data: any;
}