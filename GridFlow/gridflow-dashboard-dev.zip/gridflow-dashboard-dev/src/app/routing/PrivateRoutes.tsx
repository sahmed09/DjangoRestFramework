import React, { Suspense, lazy } from 'react'
import { Redirect, Route, Switch } from 'react-router-dom'
import { FallbackView } from '../../_metronic/partials'
import { DashboardWrapper } from '../pages/dashboard/DashboardWrapper'
import { MenuTestPage } from '../pages/MenuTestPage'

export function PrivateRoutes() {
  // const BuilderPageWrapper = lazy(() => import('../pages/layout-builder/BuilderPageWrapper'))
  // const ProfilePage = lazy(() => import('../modules/profile/ProfilePage'))
  // const WizardsPage = lazy(() => import('../modules/wizards/WizardsPage'))
  // const AccountPage = lazy(() => import('../modules/accounts/AccountPage'))
  // const WidgetsPage = lazy(() => import('../modules/widgets/WidgetsPage'))
  // const ChatPage = lazy(() => import('../modules/apps/chat/ChatPage'))

  // custom
  // const CategoryPage = lazy(() => import('../modules/categories/CaegoryPage'))
  // const CategoryPage = lazy(() => import('../modules/categories/CatPage'))

  const BrandPage = lazy(() => import('../modules/brands/BrandsPage'))

  const CategoryPage = lazy(() => import('../modules/categories/CategoryPage'))
  const CustomersPage = lazy(() => import('../modules/customers/CustomersPage'))

  // const ProductsPage = lazy(() => import('../pages/products/ProductsPage'))
  const ProductsPage = lazy(() => import('../modules/products/ProductsPage'))
  const ShopsPage = lazy(() => import('../modules/shops/ShopsPage'))
  const OrdersPage = lazy(() => import('../modules/orders/OrdersPage'))
  
  const DeliveryAgencyPage = lazy(() => import('../modules/deliveryAgencies/DEPage'))
  
  
  const ChatPage = lazy(() => import('../modules/chat/ChatPage'))

  // const ProductEnlistPage = lazy(() => import('../modules/shops/sections/ProductEnlist'))


  // const ExperimentalPage = lazy(() => import('../modules/experimental/SearchableSelectPage'))


  // const BoilerplatePage = lazy(() => import('../modules/boilerplate/BoilerplatePage'))

  return (
    <Suspense fallback={<FallbackView />}>
      <Switch>

        {/* <Route path='/category' component={DashboardWrapper} /> */}
        <Route path='/brands' component={BrandPage} />
        <Route path='/categories' component={CategoryPage} />
        <Route path='/customers' component={CustomersPage} />
        <Route path='/products' component={ProductsPage} />
        <Route path='/shops' component={ShopsPage} />
        <Route path='/orders' component={OrdersPage} />
        <Route path='/delivery-agencies' component={DeliveryAgencyPage} />
        
        <Route path='/chats' component={ChatPage} />


        {/* <Route path='/product-enlist' component={ProductEnlistPage} /> */}



        {/* experimental routes */}
        {/* <Route path='/experimental' component={ExperimentalPage} /> */}
        {/* end: experimental routes */}



        {/* boilerplate for creating new page */}
        {/* <Route path='/boilerplate' component={BoilerplatePage} /> */}



        {/* other routes */}
        <Route path='/dashboard' component={DashboardWrapper} />
        {/* <Route path='/builder' component={BuilderPageWrapper} />
        <Route path='/crafted/pages/profile' component={ProfilePage} />
        <Route path='/crafted/pages/wizards' component={WizardsPage} />
        <Route path='/crafted/widgets' component={WidgetsPage} />
        <Route path='/crafted/account' component={AccountPage} />
        <Route path='/apps/chat' component={ChatPage} />
        <Route path='/menu-test' component={MenuTestPage} /> */}
        <Redirect from='/auth' to='/dashboard' />
        {/* <Redirect exact from='/' to='/dashboard' /> */}
        <Redirect exact from='/' to='/categories' />
        <Redirect to='error/404' />
      </Switch>
    </Suspense>
  )
}
