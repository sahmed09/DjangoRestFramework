/* eslint-disable react/jsx-no-target-blank */
import React from 'react'
import { useIntl } from 'react-intl'
import { KTSVG } from '../../../helpers'
import { AsideMenuItemWithSub } from './AsideMenuItemWithSub'
import { AsideMenuItem } from './AsideMenuItem'

export function AsideMenuMain() {
  const intl = useIntl()

  return (
    <>

      {/* menu section title */}
      <div className='menu-item'>
        <div className='menu-content pt-8 pb-2'>
          <span className='menu-section text-muted text-uppercase fs-8 ls-1'>Menu</span>
        </div>
      </div>
      {/* end: menu section title */}


      {/* Brands section - nested */}
      {/* <AsideMenuItemWithSub to='/brands' title='Brands' icon='/media/icons/duotune/art/art002.svg'>
        <AsideMenuItem to='/brands/list' title='Overview' hasBullet={true} />
        <AsideMenuItem to='/brands/add' title='Add Brand' hasBullet={true} />
      </AsideMenuItemWithSub> */}
      {/* Brands section - nested */}

      {/* Brands page */}
      <AsideMenuItem
        icon='/media/icons/duotune/art/art002.svg'
        to='/brands'
        title='Brands' />


      {/* Shop page */}
      <AsideMenuItem
        icon='/media/icons/duotune/art/art002.svg'
        to='/shops'
        title='Shops' />

      {/* orders page */}
      <AsideMenuItem
        icon='/media/icons/duotune/art/art002.svg'
        to='/orders'
        title='Orders' />

      {/* categories page */}
      <AsideMenuItem
        icon='/media/icons/duotune/art/art002.svg'
        to='/categories'
        title='Categories' />

      {/* customers page */}
      <AsideMenuItem
        icon='/media/icons/duotune/art/art002.svg'
        to='/customers'
        title='Customers' />

      {/* products page */}
      <AsideMenuItem
        icon='/media/icons/duotune/art/art002.svg'
        to='/products'
        title='Products' />


      {/* delivery agency page */}
      <AsideMenuItem
        icon='/media/icons/duotune/art/art002.svg'
        to='/delivery-agencies'
        title='Delivery Agencies' />


      {/* chat page */}
      <AsideMenuItem
        icon='/media/icons/duotune/art/art002.svg'
        to='/chats'
        title='Chats' />


      {/* <AsideMenuItem
        icon='/media/icons/duotune/art/art002.svg'
        to='/product-enlist'
        title='Product Enlist' /> */}


      {/* single section title */}
      {/* <AsideMenuItem
        to='/category'
        icon='/media/icons/duotune/art/art002.svg'
        // title={intl.formatMessage({ id: 'MENU.DASHBOARD' })}
        title="Category"
        fontIcon='bi-app-indicator'
      /> */}
      {/* end: single section title */}

      {/* nested category page links */}
      {/* <AsideMenuItemWithSub to='/categories' title='Categories' icon='/media/icons/duotune/art/art002.svg'>
        <AsideMenuItem to='/categories/overview' title='Overview' hasBullet={true} />
        <AsideMenuItem to='/categories/add' title='Add Category' hasBullet={true} />
      </AsideMenuItemWithSub> */}
      {/* end: nested category page links */}


      {/* products menu */}
      {/* <AsideMenuItem
        to='/products'
        icon='/media/icons/duotune/art/art002.svg'
        // title={intl.formatMessage({ id: 'MENU.DASHBOARD' })}
        title="Products"
        fontIcon='bi-app-indicator'
      /> */}

      {/* <AsideMenuItemWithSub to='/products' title='Products' icon='/media/icons/duotune/art/art002.svg'>
        <AsideMenuItem to='/products/overview' title='Overview' hasBullet={true} />
        <AsideMenuItem to='/products/add' title='Add Product' hasBullet={true} />
      </AsideMenuItemWithSub> */}
      {/* end: products menu */}


      {/* separator */}
      <div className='menu-item'>
        <div className='menu-content'>
          <div className='separator mx-1 my-4'></div>
        </div>
      </div>


      {/* end of menu */}






      {/* boilerplate item */}

      {/* nested menu item */}

      {/* <AsideMenuItemWithSub to='/crafted/pages/profile' title='Profile' hasBullet={true}>
        <AsideMenuItem to='/crafted/pages/profile/overview' title='Overview' hasBullet={true} />
        <AsideMenuItem to='/crafted/pages/profile/projects' title='Projects' hasBullet={true} />
        <AsideMenuItem to='/crafted/pages/profile/campaigns' title='Campaigns' hasBullet={true} />
        <AsideMenuItem to='/crafted/pages/profile/documents' title='Documents' hasBullet={true} />
        <AsideMenuItem to='/crafted/pages/profile/connections' title='Connections' hasBullet={true} />
      </AsideMenuItemWithSub> */}

      {/* <AsideMenuItemWithSub to='/boilerplate' title='Page Boilerplate' icon='/media/icons/duotune/art/art002.svg'>
        <AsideMenuItem to='/boilerplate/overview' title='Overview' hasBullet={true} />
        <AsideMenuItem to='/boilerplate/projects' title='Projects' hasBullet={true} />
        <AsideMenuItem to='/boilerplate/campaigns' title='Campaigns' hasBullet={true} />
        <AsideMenuItem to='/boilerplate/documents' title='Documents' hasBullet={true} />
        <AsideMenuItem to='/boilerplate/connections' title='Connections' hasBullet={true} />
      </AsideMenuItemWithSub> */}


      {/* end: nested menu item */}

      {/* end: boilerplate item */}

      {/* separator */}
      {/* <div className='menu-item'>
        <div className='menu-content'>
          <div className='separator mx-1 my-4'></div>
        </div>
      </div> */}




      {/* existing template items */}

      {/* single section title */}
      <AsideMenuItem
        to='/dashboard'
        icon='/media/icons/duotune/art/art002.svg'
        title={intl.formatMessage({ id: 'MENU.DASHBOARD' })}
        fontIcon='bi-app-indicator'
      />
      {/* end: single section title */}


      {/* single section title */}
      {/* <AsideMenuItem
        to='/builder'
        icon='/media/icons/duotune/general/gen019.svg'
        title='Layout Builder'
        fontIcon='bi-layers'
      /> */}
      {/* end: single section title */}


      {/* menu section title */}
      {/* <div className='menu-item'>
        <div className='menu-content pt-8 pb-2'>
          <span className='menu-section text-muted text-uppercase fs-8 ls-1'>Crafted</span>
        </div>
      </div> */}
      {/* end: menu section title */}

      {/* nested menu item */}
      {/* <AsideMenuItemWithSub
        to='/crafted/pages'
        title='Pages'
        fontIcon='bi-archive'
        icon='/media/icons/duotune/general/gen022.svg'
      >
        <AsideMenuItemWithSub to='/crafted/pages/profile' title='Profile' hasBullet={true}>
          <AsideMenuItem to='/crafted/pages/profile/overview' title='Overview' hasBullet={true} />
          <AsideMenuItem to='/crafted/pages/profile/projects' title='Projects' hasBullet={true} />
          <AsideMenuItem to='/crafted/pages/profile/campaigns' title='Campaigns' hasBullet={true} />
          <AsideMenuItem to='/crafted/pages/profile/documents' title='Documents' hasBullet={true} />
          <AsideMenuItem
            to='/crafted/pages/profile/connections'
            title='Connections'
            hasBullet={true}
          />
        </AsideMenuItemWithSub>

        <AsideMenuItemWithSub to='/crafted/pages/wizards' title='Wizards' hasBullet={true}>
          <AsideMenuItem
            to='/crafted/pages/wizards/horizontal'
            title='Horizontal'
            hasBullet={true}
          />
          <AsideMenuItem to='/crafted/pages/wizards/vertical' title='Vertical' hasBullet={true} />
        </AsideMenuItemWithSub>
      </AsideMenuItemWithSub> */}

      {/* end: nested menu item */}


      {/* nested menu item */}
      {/* <AsideMenuItemWithSub
        to='/crafted/accounts'
        title='Accounts'
        icon='/media/icons/duotune/communication/com006.svg'
        fontIcon='bi-person'
      >
        <AsideMenuItem to='/crafted/account/overview' title='Overview' hasBullet={true} />
        <AsideMenuItem to='/crafted/account/settings' title='Settings' hasBullet={true} />
      </AsideMenuItemWithSub> */}
      {/* end: nested menu item */}


      {/* nested menu item */}
      {/* <AsideMenuItemWithSub
        to='/error'
        title='Errors'
        fontIcon='bi-sticky'
        icon='/media/icons/duotune/general/gen040.svg'
      >
        <AsideMenuItem to='/error/404' title='Error 404' hasBullet={true} />
        <AsideMenuItem to='/error/500' title='Error 500' hasBullet={true} />
      </AsideMenuItemWithSub> */}
      {/* end: nested menu item */}


      {/* nested menu item */}
      {/* <AsideMenuItemWithSub
        to='/crafted/widgets'
        title='Widgets'
        icon='/media/icons/duotune/general/gen025.svg'
        fontIcon='bi-layers'
      >
        <AsideMenuItem to='/crafted/widgets/lists' title='Lists' hasBullet={true} />
        <AsideMenuItem to='/crafted/widgets/statistics' title='Statistics' hasBullet={true} />
        <AsideMenuItem to='/crafted/widgets/charts' title='Charts' hasBullet={true} />
        <AsideMenuItem to='/crafted/widgets/mixed' title='Mixed' hasBullet={true} />
        <AsideMenuItem to='/crafted/widgets/tables' title='Tables' hasBullet={true} />
        <AsideMenuItem to='/crafted/widgets/feeds' title='Feeds' hasBullet={true} />
      </AsideMenuItemWithSub> */}
      {/* end: nested menu item */}


      {/* menu section */}
      {/* section name */}
      {/* <div className='menu-item'>
        <div className='menu-content pt-8 pb-2'>
          <span className='menu-section text-muted text-uppercase fs-8 ls-1'>Apps</span>
        </div>
      </div> */}

      {/* nested menu item */}
      {/* <AsideMenuItemWithSub
        to='/apps/chat'
        title='Chat'
        fontIcon='bi-chat-left'
        icon='/media/icons/duotune/communication/com012.svg'
      >
        <AsideMenuItem to='/apps/chat/private-chat' title='Private Chat' hasBullet={true} />
        <AsideMenuItem to='/apps/chat/group-chat' title='Group Chart' hasBullet={true} />
        <AsideMenuItem to='/apps/chat/drawer-chat' title='Drawer Chart' hasBullet={true} />
      </AsideMenuItemWithSub> */}
      {/* end: nested menu item */}

      {/* separator */}
      {/* <div className='menu-item'>
        <div className='menu-content'>
          <div className='separator mx-1 my-4'></div>
        </div>
      </div> */}

      {/* changelog */}
      {/* <div className='menu-item'>
        <a
          target='_blank'
          className='menu-link'
          href={process.env.REACT_APP_PREVIEW_DOCS_URL + '/docs/changelog'}
        >
          <span className='menu-icon'>
            <KTSVG path='/media/icons/duotune/general/gen005.svg' className='svg-icon-2' />
          </span>
          <span className='menu-title'>Changelog {process.env.REACT_APP_VERSION}</span>
        </a>
      </div> */}
      {/* end: changelog */}
    </>
  )
}
