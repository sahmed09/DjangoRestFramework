/* eslint-disable jsx-a11y/anchor-is-valid */
import clsx from 'clsx'
import React, { FC } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Link } from 'react-router-dom'
import { showModal } from '../../../../app/redux/slices/modalSlice'
import { AppState } from '../../../../app/redux/store'
import { KTSVG } from '../../../helpers'
import { useLayout } from '../../core'
import { DefaultTitle } from '../header/page-title/DefaultTitle'




const Toolbar1: FC = () => {
  const { classes } = useLayout()


  // redux dispatch and state
  const { createButtonAsLink, createButtonLinkHref, createButtonEnabled, filterButtonEnabled } = useSelector((state: AppState) => state.uiState)
  const dispatch = useDispatch();


  const createButtonHandler = (e: React.FormEvent<HTMLButtonElement>) => {
    e.preventDefault();
    console.log('create button clicked');

    dispatch(showModal());

  };

  return (
    <div className='toolbar' id='kt_toolbar'>
      {/* begin::Container */}
      <div
        id='kt_toolbar_container'
        className={clsx(classes.toolbarContainer.join(' '), 'd-flex flex-stack')}
      >
        <DefaultTitle />

        {/* begin::Actions */}
        <div className='d-flex align-items-center py-1'>
          {/* begin::Wrapper */}
          <div className='me-4'>
            {/* begin::Menu */}
            {/* <a
              href='#'
              className='btn btn-sm btn-flex btn-light btn-active-primary fw-bolder'
              data-kt-menu-trigger='click'
              data-kt-menu-placement='bottom-end'
              data-kt-menu-flip='top-end'
            >
              <KTSVG
                path='/media/icons/duotune/general/gen031.svg'
                className='svg-icon-5 svg-icon-gray-500 me-1'
              />
              Filter
            </a> */}

            <button
              // className='btn btn-sm btn-flex btn-light btn-active-primary fw-bolder'>
              className={clsx(
                'btn btn-sm btn-flex btn-light btn-active-primary fw-bolder',
                !filterButtonEnabled && 'disabled'
              )}>
              <KTSVG
                path='/media/icons/duotune/general/gen031.svg'
                className='svg-icon-5 svg-icon-gray-500 me-1' />
              Filter
            </button>

            {/* end::Menu */}
          </div>
          {/* end::Wrapper */}

          {/* begin::Button */}

          {createButtonAsLink && createButtonLinkHref && (
            <Link
              to={createButtonLinkHref}
              className='btn btn-sm btn-primary'
            // data-bs-toggle='modal'
            // show-hide modal
            // data-bs-target='#kt_modal_create_app'
            // id='kt_toolbar_primary_button'
            >
              Create
            </Link>
          )}
          {/* end::Button */}

          {/* dynamic create button */}
          {!createButtonAsLink && (<button
            // todo: get event handler for this button from global (redux) store
            onClick={createButtonHandler}
            // className='btn btn-sm btn-primary'>
            className={clsx('btn btn-sm btn-primary', !createButtonEnabled && 'disabled')}>
            Create
          </button>)}


          {/* end: dynamic create button */}

        </div>
        {/* end::Actions */}
      </div>
      {/* end::Container */}
    </div>
  )
}

export { Toolbar1 }
