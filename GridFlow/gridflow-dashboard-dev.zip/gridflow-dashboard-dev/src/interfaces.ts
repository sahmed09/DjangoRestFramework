// album

export interface IAlbum {
    id: number,
    name: string,
}


export interface IAlbumState {
    page: number
    albums: IAlbum[]
    error?: string | null
    hasNext?: boolean
    hasPrevious?: boolean
}






// auth

export interface ITokenString {
    token: string | null
    error: string | null
}

export interface IAuthCredentials {
    username: string
    password: string
}


export interface IAuthToken {
    token: string | null
    error: string | null
}


export interface IBrand {
    id: number,
    name: string,
    slug: string,
    album: number,
}

export interface IBrandState {
    page: number
    brands: IBrand[]
    error?: string | null
    hasNext?: boolean
    hasPrevious?: boolean
}





// export interface ICurrentUser {
//     id: string
//     display_name: string
//     email: string
//     photo_url: string
// }

// export interface IAuthError {
//     message: string
// }


// export interface IAuthState {
//     isAuth: boolean
//     currentUser?: ICurrentUser
//     isLoading: boolean
//     error: IAuthError
// }


// category slice

export interface ICategory {
    id: number,
    name: string,
    slug: string,
}


export interface ICategoryState {
    page: number
    categories: ICategory[]
    error?: string | null
    hasNext?: boolean
    hasPrevious?: boolean
}



// modal slice

export interface IModalState {
    visible: boolean
    modalData?: any
}


// category form slice

export interface IAttributeValue {
    id: string | number
    value: string
    slug: string
    isSaved?: boolean
    update?: boolean
}

export interface IAttribute {
    id: string | number
    name: string
    slug: string
    values: IAttributeValue[]
    isSaved?: boolean
    update?: boolean
}

// export interface ICreateCategoryState {
export interface ICategoryFormState {
    id?: string | number
    name: string
    slug: string
    attributes: IAttribute[]
    isSaved?: boolean
    update?: boolean

}


// shop slice

export interface IShop {
    id: number,
    name: string,
    album?: number | null,
    slug: string,
    //  todo: create interface for product variation
}


export interface IProductState {
    page: number
    shops: IShop[]
    error?: string | null
    hasNext?: boolean
    hasPrevious?: boolean
}


// ui slice

export interface IUiState {
    //  toolbar buttons
    createButtonAsLink: boolean
    createButtonLinkHref?: string
    createButtonEnabled: boolean
    // todo: add button click action / target attribute
    // todo: use string const & swtich statement to select different types of events 

    filterButtonEnabled: boolean
    // filterButtonClickHandler:


}


// API response data
// export interface ResponseData {
//     status: number
//     statusText: string
//     message: string | null
//     errorMessage: string | null
//     data: any
// }


// react search select

export interface ISelectOptions {
    name: string
    value: string
}




// shop branch slice

export interface IShopBranch {
    id: number
    name: string
    slug: string
    shop: number
    album?: number
}


export interface IShopBranchState {
    shopID?: number | null
    shopName?: string
    shopSlug?: string
    page: number
    branches: IShopBranch[]
    error?: string | null
    hasNext?: boolean
    hasPrevious?: boolean
}



// product

export interface IProduct {
    id: number
    name: string
    slug: string
    category?: ICategory
    brand?: IBrand
    album?: number
    // todo: add variations interface
    variations?: any
}

export interface IShopBranchProduct {
    id: number
    product: IProduct
    price: string
    shop: number
    branch?: number

    // utilities

    // available in shop/branch 
    added?: boolean

}









